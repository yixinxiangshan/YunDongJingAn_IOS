//
//  ECPopViewUtil.h
//  ECFramework
//
//  Created by EC on 2/27/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
//#import "ECLoadingView.h"

@interface ECPopViewUtil : NSObject

/**
 * 显示弹出框
 */
+ (void)showLoading:(NSString*)message;
+ (void)showLoading:(NSString*)message view:(UIView*)view;
+ (void)removeLoading;

+ (void)showAlertView:(NSString*)title massage:(NSString*)msg;
+ (void)toast:(NSString *)msg;
+ (void)toast:(NSString *)msg position:(id)position;
+ (UIViewController *) currentViewController;
@end
