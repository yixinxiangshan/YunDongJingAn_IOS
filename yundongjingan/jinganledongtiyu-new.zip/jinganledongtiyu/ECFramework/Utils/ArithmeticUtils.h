//
//  ArithmeticUtils.h
//  Roading
//
//  Created by cheng on 13-11-28.
//  Copyright (c) 2013年 OR. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ArithmeticUtils : NSObject

/**
 *  执行四则运算表达式
 *  表达式中不能包含字符“〜“
 *  @param formula
 */
+ (NSNumber *) executeFormula:(id)formula;

/**
 *  格式化表达式
 */
+ (NSArray *) formatFormula:(id)formulaString;
@end
