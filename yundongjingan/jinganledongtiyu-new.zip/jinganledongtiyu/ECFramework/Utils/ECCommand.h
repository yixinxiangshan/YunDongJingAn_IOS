//
//  ECCommand.h
//  jinganledongtiyu
//
//  Created by cheng on 14-2-19.
//  Copyright (c) 2014年 eCloud. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ECCommand : NSObject
- (void) excute:(NSDictionary *)noti;
@end
