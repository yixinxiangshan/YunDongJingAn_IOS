//
//  ECCommand.m
//  jinganledongtiyu
//
//  Created by cheng on 14-2-19.
//  Copyright (c) 2014年 eCloud. All rights reserved.
//

#import "ECCommand.h"
#import "ECAlertControl.h"

@implementation ECCommand

- (id) init
{
    static ECCommand *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super init];
    });
    return instance;
}

- (void) excute:(NSDictionary *)noti
{
    NSDictionary *params = noti[@"urlParams"];
    NSString *method = [params objectForKey:@"method"];
    if ([method isEqualToString:@"shownotice"]) {
        [ECCommand showNotice:params];
    }
}


+ (void) showNotice:(NSDictionary *)params
{
    [ECAlertControl showAlertViewWithXIBName:[params objectForKey:@"noticeview"]];
}
@end
