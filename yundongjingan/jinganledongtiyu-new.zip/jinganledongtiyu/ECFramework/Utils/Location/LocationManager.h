//
//  LocationManager.h
//  QCRL
//
//  Created by Guanglu Kang on 5/22/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>


/**
 * 地理位置更新设置
 */

@interface LocationManager : NSObject

/**
 * 开始更新位置
 */
+(void)startUpdateLocationWithDelegate:(id)delegate;
/**
 * 取消更新位置
 */
+(void)cancelUpdateLocation;
@end
