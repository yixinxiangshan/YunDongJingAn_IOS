//
//  LocationManager.m
//  QCRL
//
//  Created by Guanglu Kang on 5/22/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "LocationManager.h"
#import <MapKit/MapKit.h>
@interface LocationManager ()
/**
 * 这个方法尽量不要调用
 */
+(CLLocationManager*)sharedLocationManager;
@end
@implementation LocationManager
static CLLocationManager* locationmanager = nil;
+(CLLocationManager*)sharedLocationManager{
    @synchronized(locationmanager){
        if (nil == locationmanager) {
            locationmanager = [[CLLocationManager alloc] init];//创建位置管理器 x
        }
        
        //locationManager.delegate = self;//设置代理 
        locationmanager.desiredAccuracy = kCLLocationAccuracyHundredMeters;//指定需要的精度级别 
        locationmanager.distanceFilter = 1000.0f;   //设置距离筛选器 
    }
    return locationmanager;
}
+(void)startUpdateLocationWithDelegate:(id)delegate{
    [LocationManager cancelUpdateLocation];
    [LocationManager sharedLocationManager];
    [locationmanager setDelegate:delegate];
    [locationmanager startUpdatingLocation];
}
+(void)cancelUpdateLocation{
    if (nil !=locationmanager) {
        [locationmanager setDelegate:nil];
        [locationmanager stopUpdatingLocation];
//        [locationmanager release];
        locationmanager = nil;
    }
}

@end
