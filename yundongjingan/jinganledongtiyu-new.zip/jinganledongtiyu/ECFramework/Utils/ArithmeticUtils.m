//
//  ArithmeticUtils.m
//  Roading
//
//  Created by cheng on 13-11-28.
//  Copyright (c) 2013年 OR. All rights reserved.
//

#import "ArithmeticUtils.h"

@implementation ArithmeticUtils
+ (NSArray *) formatFormula:(id )formula
{
    NSString* formulaString = [NSString new];
    if ([formula isKindOfClass:[NSArray class]]) {
        for (id item in formula)
        {
            formulaString = [formulaString stringByAppendingString:[NSString stringWithFormat:@"%@",item]];
        }
    }else if ([formulaString isKindOfClass:[NSString class]]){
        formulaString = [NSString stringWithFormat:@"%@",formula];
    }
    formulaString = [formulaString stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    
    
    formulaString = [formulaString stringByReplacingOccurrencesOfString:@"+-" withString:@"+~"];
    formulaString = [formulaString stringByReplacingOccurrencesOfString:@"--" withString:@"-~"];
    formulaString = [formulaString stringByReplacingOccurrencesOfString:@"*-" withString:@"*~"];
    formulaString = [formulaString stringByReplacingOccurrencesOfString:@"/-" withString:@"/~"];
    formulaString = [formulaString stringByReplacingOccurrencesOfString:@"(-" withString:@"(~"];
    
    formulaString = [formulaString stringByReplacingOccurrencesOfString:@"+" withString:@" + "];
    formulaString = [formulaString stringByReplacingOccurrencesOfString:@"－" withString:@" - "];
    formulaString = [formulaString stringByReplacingOccurrencesOfString:@"*" withString:@" * "];
    formulaString = [formulaString stringByReplacingOccurrencesOfString:@"/" withString:@" / "];
    formulaString = [formulaString stringByReplacingOccurrencesOfString:@"(" withString:@" ( "];
    formulaString = [formulaString stringByReplacingOccurrencesOfString:@")" withString:@" ) "];
    
    formulaString = [formulaString stringByReplacingOccurrencesOfString:@"  " withString:@" "];
    
    if ([[formulaString substringToIndex:1] isEqualToString:@" "]) {
        formulaString = [formulaString substringFromIndex:1];
    }
    if ([[formulaString substringFromIndex:formulaString.length-1] isEqualToString:@" "]) {
        formulaString = [formulaString substringToIndex:formulaString.length-1];
    }
    
    formulaString = [formulaString stringByReplacingOccurrencesOfString:@"〜" withString:@"-"];
    
    if ([[formulaString substringToIndex:1] isEqualToString:@"-"] || [[formulaString substringToIndex:1] isEqualToString:@"+"]) {
        formulaString = [NSString stringWithFormat:@"0 %@",formulaString];
    }
    if ([[formulaString substringToIndex:1] isEqualToString:@"*"] || [[formulaString substringToIndex:1] isEqualToString:@"/"]) {
        formulaString = [NSString stringWithFormat:@"1 %@",formulaString];
    }
    formulaString = formulaString = [formulaString stringByReplacingOccurrencesOfString:@"--" withString:@""];
    
    return [formulaString componentsSeparatedByString:@" "];
}

+ (NSNumber *) executeFormula:(id)formulaDes
{
    NSArray* formula = [[self class] formatFormula:formulaDes];
    
    int from = 0;
    for (from = 0 ; from < formula.count; from ++ )
    {
        if ([[NSString stringWithFormat:@"%@",[formula objectAtIndex:from]] isEqualToString:@"("]) {
            break;
        }
    }
    int to = 0;
    int countofarea = 0;
    for (to = from; to < formula.count; to ++)
    {
        id object = [formula objectAtIndex:to];
        if ([object isEqualToString:@"("]) {
            countofarea ++;
        }
        if ([object isEqualToString:@")"]) {
            countofarea --;
        }
        
        if (!countofarea) {
            break;
        }
    }
    
    NSMutableArray* formula_new = [NSMutableArray new];
    NSMutableArray* subFormula = [NSMutableArray new];
    
    if (from+1 < to) {
        
        
        for (int i = 0 ; i < formula.count; i++)
        {
            if (i < from || i > to) {
                [formula_new addObject:[formula objectAtIndex:i]];
            }
            if (i > from && i < to) {
                [subFormula addObject:[formula objectAtIndex:i]];
            }
        }
        
        [formula_new insertObject:[[self class] executeFormula:subFormula] atIndex:from];
    }else{
        [formula_new addObjectsFromArray:formula];
    }
    
    for (id item in formula_new)
    {
        if ([[NSString stringWithFormat:@"%@",item] isEqualToString:@"("]) {
            return [[self class] executeFormula:formula_new];
        }
    }
    NSNumber* result = [[self class] calFormula:formula_new];
    return result;
}

+ (NSNumber *) calFormula:(NSArray *)formula
{
    NSMutableArray* formula_new = [NSMutableArray new];
    
    BOOL flag = NO;
    for (int i = 0; i < formula.count; i ++)
    {
        NSString* item = [NSString stringWithFormat:@"%@",[formula objectAtIndex:i]];
        
        if (flag || (![item isEqualToString:@"*"] && ![item isEqualToString:@"/"])) {
            [formula_new addObject:item];
        }else if ([item isEqualToString:@"*"]){
            [formula_new setObject:[NSNumber numberWithFloat:[[formula objectAtIndex:i-1] floatValue]*[[formula objectAtIndex:i+1] floatValue]] atIndexedSubscript:formula_new.count-1];
            i++;
            flag = YES;
        }else if ([item isEqualToString:@"/"]){
            [formula_new setObject:[NSNumber numberWithFloat:[[formula objectAtIndex:i-1] floatValue]/[[formula objectAtIndex:i+1] floatValue]] atIndexedSubscript:formula_new.count-1];
            i++;
            flag = YES;
        }
    }
    for (id item in formula_new)
    {
        if ([[NSString stringWithFormat:@"%@",item] isEqualToString:@"*"] || [[NSString stringWithFormat:@"%@",item] isEqualToString:@"/"]) {
            return [[self class] calFormula:formula_new];
        }
    }
    
    CGFloat result = [[formula_new objectAtIndex:0] floatValue];
    if (formula_new.count == 1) {
        return [NSNumber numberWithFloat:result];
    }
    
    for (int i = 1; i < formula_new.count; i+=2)
    {
        NSString* diot = [formula_new objectAtIndex:i];
        
        if ([diot isEqualToString:@"+"]) {
            result += [[formula_new objectAtIndex:i+1] floatValue];
        }else if ([diot isEqualToString:@"-"]){
            result -= [[formula_new objectAtIndex:i+1] floatValue];
        }
    }
    
    return [NSNumber numberWithFloat:result];
}

@end
