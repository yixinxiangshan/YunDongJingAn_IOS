//
//  ECPopViewUtil.m
//  ECFramework
//
//  Created by EC on 2/27/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECPopViewUtil.h"
#import "ECLoadingView.h"
#import "Toast+UIView.h"


@implementation ECPopViewUtil


#pragma mark - 显示弹出框
+ (void)showLoading:(NSString*)message{
    [self showLoading:message view:nil];
}
+ (void)showLoading:(NSString*)message view:(UIView*)view{
    UIView* _view = nil;
    if (nil == view) {
        _view = [UIApplication sharedApplication].keyWindow.rootViewController.view;
    }else{
        _view = view;
    }
    if (nil==message || [@"" isEqualToString:message]) {
        message = @"处理中...";
    }
    
    [ECLoadingBezelActivityView activityViewForView:_view withLabel:message];

}
+ (void)removeLoading{
    [ECLoadingBezelActivityView removeViewAnimated:YES];
}


+ (void)showAlertView:(NSString*)title massage:(NSString*)msg{
    UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:title message:msg delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertView show];
}

+ (void)toast:(NSString *)msg
{
    [[self class] toast:msg position:@"bottom"];
}
+ (void)toast:(NSString *)msg position:(id)position
{
    [[[ECPopViewUtil currentViewController] view] makeToast:msg duration:2.0 position:position];
}
+ (UIViewController *) currentViewController
{
    return [[[[[UIApplication sharedApplication] keyWindow] rootViewController] childViewControllers] lastObject];
}
@end