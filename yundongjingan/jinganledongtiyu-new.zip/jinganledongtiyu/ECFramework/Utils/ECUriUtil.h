//
//  ECUriUtil.h
//  JingAnWeekly
//
//  Created by EC on 4/7/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ECUriUtil : NSObject
/**
 * 获取图片完整地址
 */
+ (NSString*)getWholeImageUrl:(NSString*)imageName;
/**
 * 获取图片完整地址—小尺寸的图片（200）
 */
+ (NSString*)getSmallImageUrl:(NSString*)imageName;
/**
 * 获取图片完整地址—适合屏幕宽度的图片（200）
 */
+(NSString *)getDefaultImageUrl:(NSString *)imageName;

@end
