//
//  ECUriUtil.m
//  JingAnWeekly
//
//  Created by EC on 4/7/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECUriUtil.h"
#import "ECNetRequest.h"
#import "DisplayUtil.h"

@implementation ECUriUtil


+ (NSString*)getWholeImageUrl:(NSString*)imageName{
    return [NSString stringWithFormat:@"%@%@",imageURI(),imageName];
}
+ (NSString*)getSmallImageUrl:(NSString*)imageName{
    NSArray* splitString = [imageName componentsSeparatedByString:@"."];
    NSString* smallImageName ;
    if (splitString.count > 1) {
        smallImageName = [NSString stringWithFormat:@"%@_200.%@",splitString[0],splitString[1]];
    }else
        return nil;
    return [self getWholeImageUrl:smallImageName];
}
+(NSString *)getDefaultImageUrl:(NSString *)imageName
{
    NSString* screenWidth = [NSString stringWithFormat:@"%i",(int)validWidth()];
    
    NSArray* splitString = [imageName componentsSeparatedByString:@"."];
    NSString* defaultImageName ;
    if (splitString.count > 1) {
        defaultImageName = [NSString stringWithFormat:@"%@_%@.%@",splitString[0],screenWidth,splitString[1]];
    }else
        return nil;
    return [self getWholeImageUrl:defaultImageName];
}
@end
