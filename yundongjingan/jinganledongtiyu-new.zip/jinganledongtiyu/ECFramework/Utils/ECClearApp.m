 //
//  ECClearApp.m
//  HealthyClub
//
//  Created by EC on 2/21/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECClearApp.h"
#import "ECKeyChain.h"
#import "ECWebImageDownloader.h"
#import "CoreData.h"
#import "SDImageCache.h"
#import "NSStringExtends.h"

@implementation ExitDelegate 

// 退出程序
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    exit(0);
}
@end

@interface ECClearApp ()

@property (nonatomic, strong) ExitDelegate* exitDelegate;

@end

@implementation ECClearApp
+ (ECClearApp*)shareInstance{
    static ECClearApp* singleInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        singleInstance = [self new];
    });
    return singleInstance;
}

#pragma mark - 清空token/enterpriseid/apikey/sonSortList
+ (void)clearApp{
    [ECKeyChain saveUserName:@"" password:@"" deviceID:[UIDevice UDID] accessToken:nil];
    [ECKeyChain saveApiKey:nil];
    [ECKeyChain saveEnterpriseId:nil];
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:@"sonSortList"];
    [ECClearApp clearCache:NO];
}

#pragma mark - 清空缓存
+ (void)clearCache:(BOOL)isAlert{
    
    //清除图片
    [[SDImageCache sharedImageCache] clearMemory];
    NSString* title = @"";
    if([[ECWebImageDownloader sharedInstance] clearAllImages]){
        title = @"缓存已清除";
    } else {
        title = @"清除缓存过程中发生了错误,请稍后再试";
    }
    if (isAlert) {
        UIAlertView* av = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [av show];
    }
    
}

#pragma mark - 退出程序
- (void)exitAppForNet{
    [self exitApp:@"网络不给力" message:@"请在网络打开的情况下使用此程序;点击确定退出程序"];
}

- (void)exitApp:(NSString*)title message:(NSString*)msg{
    
    NSLog(@"退出程序：参数传递错误！");
    _exitDelegate = [ExitDelegate new];
    UIAlertView* av = [[UIAlertView alloc] initWithTitle:title
                                                 message:msg
                                                delegate:_exitDelegate
                                       cancelButtonTitle:@"确定"
                                       otherButtonTitles:nil, nil];
    [av show];
}

@end
