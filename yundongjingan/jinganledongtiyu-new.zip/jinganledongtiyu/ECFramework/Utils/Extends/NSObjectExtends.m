//
//  NSObjectExtends.m
//  Extends
//
//  Created by Alix on 9/24/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "NSObjectExtends.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@implementation NSObject (Extends)
#pragma mark - 
- (id)performSelector:(SEL)aSelector
           withObject:(id)object1
           withObject:(id)object2
           withObject:(id)object3{
    
    NSMethodSignature *sig = [self methodSignatureForSelector:aSelector];
    if (sig) {
        NSInvocation* invo = [NSInvocation invocationWithMethodSignature:sig];
        [invo setTarget:self];
        [invo setSelector:aSelector];
        [invo setArgument:&object1 atIndex:2];
        [invo setArgument:&object2 atIndex:3];
        [invo setArgument:&object3 atIndex:4];
        [invo invoke];
        if (sig.methodReturnLength) {
            id anObject;
            [invo getReturnValue:&anObject];
            return anObject;
            
        } else {
            return nil;
        }
        
    } else {
        return nil;
    }

}
#pragma mark - 
- (id)performSelector:(SEL)aSelector
           withObject:(id)object1
           withObject:(id)object2
           withObject:(id)object3
           withObject:(id)object4{
    
    NSMethodSignature *sig = [self methodSignatureForSelector:aSelector];
    if (sig) {
        NSInvocation* invo = [NSInvocation invocationWithMethodSignature:sig];
        [invo setTarget:self];
        [invo setSelector:aSelector];
        [invo setArgument:&object1 atIndex:2];
        [invo setArgument:&object2 atIndex:3];
        [invo setArgument:&object3 atIndex:4];
        [invo setArgument:&object4 atIndex:5];
        [invo invoke];
        if (sig.methodReturnLength) {
            id anObject;
            [invo getReturnValue:&anObject];
            return anObject;
            
        } else {
            return nil;
        }
        
    } else {
        return nil;
    }
}

#pragma mark - 
- (BOOL)isEmpty{
    if (self && NO == [self isMemberOfClass:[NSNull class]]) {
        return NO;
    }
    return YES;
}

#pragma mark - 
- (void)performBlockAfterDelay:(NSTimeInterval)delay block:(void (^)(void))block{
    [self performBlockAfterDelay:delay inQueue:dispatch_get_main_queue() block:block];
}
- (void)performBlockAfterDelay:(NSTimeInterval)delay inQueue:(dispatch_queue_t)queue block:(void(^)(void))block{
    dispatch_time_t poptime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay*NSEC_PER_SEC));
    dispatch_after(poptime, queue, block);
}

#pragma mark - 
- (void)performSelector:(SEL)selector returnTo:(void *)returnData withArguments:(void **)args{
    NSMethodSignature* methodSignature = [self methodSignatureForSelector:selector];
    NSInvocation* invocation = [NSInvocation invocationWithMethodSignature:methodSignature];
    [invocation setSelector:selector];
    
    NSUInteger argsCount = [methodSignature numberOfArguments];
    for (int i=2; i<argsCount; i++) {
        void* arg = args[i-2];
        [invocation setArgument:arg atIndex:i];
    }
    
    [invocation invokeWithTarget:self];
    
    if (NULL != returnData) {
        [invocation getReturnValue:returnData];
    }
}
- (void)performSelector:(SEL)selector withArguments:(void **)args{
    [self performSelector:selector returnTo:NULL withArguments:args];
}

- (void)performSelectorIfSelectorWasExist:(SEL)selector returnTo:(void *)returnData withArguments:(void **)args{
    if ([self respondsToSelector:selector]) {
        [self performSelector:selector returnTo:returnData withArguments:args];
    }
}
- (void)performSelectorIfSelectorWasExist:(SEL)selector withArguments:(void **)args{
    if ([self respondsToSelector:selector]) {
        [self performSelector:selector returnTo:NULL withArguments:args];
    }
}
- (BOOL)isNSxxxClass:(Class)className{
    NSString* str = NSStringFromClass([self class]);
    NSString* classStr = NSStringFromClass(className);
    if (([str hasPrefix:@"NS"]||[str hasPrefix:@"__NS"]) && [classStr hasPrefix:@"NS"] && [str hasSuffix:[classStr substringWithRange:NSMakeRange(2, [classStr length]-2)]]) {
        return YES;
    }
    return NO;
}
#pragma mark -
+ (id) replaceObjectForKey:(NSString *)keyString withObject:(id)object inObject:(id)sourceObject
{
    id temp ;
    if ([sourceObject isKindOfClass:[NSDictionary class]]) {
        temp = [NSMutableDictionary dictionaryWithDictionary:sourceObject];
    }else if ([sourceObject isKindOfClass:[NSArray class]]){
        temp = [NSMutableArray arrayWithArray:sourceObject];
    }else{
        NSLog(@"replaceObjectForKey:(NSString *)keyString withObject:(id)object inObject:(id)sourceObject  error ...");
        return nil;
    }
    id sourceObjectItem;
    int location = [keyString rangeOfString:@"."].location;
    NSString* key0;
    NSString* key1;
    if (location != NSNotFound) {
        key0 = [keyString substringToIndex:location];
        key1 = [keyString substringFromIndex:location+1];
    }else{
        key0 = keyString;
    }
    sourceObjectItem = [NSObject objectForKey:key0 inObject:temp];
    if (!key1) {
        [NSObject addObject:object forKey:key0 inObject:temp];
    }else{
        [NSObject addObject:[NSObject replaceObjectForKey:key1 withObject:object inObject:sourceObjectItem] forKey:key0 inObject:temp];
    }
    
    sourceObject = temp;
    return sourceObject;
}
+ (id) objectForKey:(NSString *)keyString inObject:(id)sourceObject
{
    if ([sourceObject isKindOfClass:[NSDictionary class]]) {
        return [sourceObject objectForKey:keyString];
    }
    if ([sourceObject isKindOfClass:[NSArray class]]) {
        if ([keyString integerValue] < ((NSArray *)sourceObject).count) {
            return [sourceObject objectAtIndex:[keyString integerValue]];
        }
    }
    return nil;
}
+ (id) addObject:(id)object forKey:(NSString *)keyString inObject:(id)sourceObject
{
    if ([sourceObject isKindOfClass:[NSMutableDictionary class]]) {
        [(NSMutableDictionary *)sourceObject setObject:object forKey:keyString];
        return sourceObject;
    }
    if ([sourceObject isKindOfClass:[NSArray class]]) {
        if ([keyString integerValue] < ((NSArray *)sourceObject).count) {
            [((NSMutableArray *)sourceObject) setObject:object atIndexedSubscript:[keyString integerValue]];
            return sourceObject;
        }
    }
    return nil;
}

@end
