//
//  NSDictionaryExtends.m
//  Extends
//
//  Created by Alix on 9/24/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "NSDictionaryExtends.h"
#import "DataConfigs.h"
#import "ECKeyChain.h"
#import "NSStringExtends.h"
#import "Utils.h"

@implementation NSDictionary (Extends)
#pragma mark - 
- (NSInteger)integerForKey:(NSString *)key{
    id obj = [self valueForKey:key];
    if (obj) {
        return [obj integerValue];
    }
    return 0;
}
#pragma mark - 
- (float)floatForKey:(NSString *)key{
    id obj = [self valueForKey:key];
    if (obj) {
        return [obj floatValue];
    }
    return 0.;
}
#pragma mark - 
- (double)doubleForKey:(NSString *)key{
    id obj = [self valueForKey:key];
    if (obj) {
        return [obj doubleValue];
    }
    return 0.;
}
#pragma mark -
- (BOOL)boolForKey:(NSString *)key{
    id obj = [self valueForKey:key];
    if (obj) {
        return [obj boolValue];
    }
    return NO;
}

#pragma mark - 将网络请求参数，转换成htmlBody格式
- (NSString*)toHtmlBody{
    NSArray* keys = [self.allKeys sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
    NSMutableString* tempString = [[NSMutableString alloc] init];
    for(id key in keys){
        [tempString appendFormat:@"%@=%@&",key,[self objectForKey:key ]];
    }
    NSString* returnString = [tempString substringToIndex:([tempString length]-1)];
//    ECLog(@"request params:%@",returnString);
    return returnString;
}


#pragma mark -添加必要参数

- (NSDictionary* )newParams{
    NSMutableDictionary* terminalParams = [NSMutableDictionary dictionaryWithDictionary:self];
    // 添加 callid
    if (nil == [terminalParams valueForKey:@"call_id"]) {
        [terminalParams setValue:[NSString randomCallID] forKey:@"call_id"];
    }
    // 没有 method 设置默认method
    if (nil == [terminalParams valueForKey:@"method"]) {
        ECLog(@"params error: no method!!");
        return nil;
    }
    // 设置 api_key
    if (nil == [terminalParams valueForKey:@"api_key"]) {
        [terminalParams setValue:[ECKeyChain apiKey] forKey:@"api_key"];
    }
    // 设置 返回格式
    [terminalParams setValue:@"json" forKey:@"format"];
    // 设置 sig
    if (nil == [terminalParams valueForKey:@"sig"]) {
        NSString* sig = [NSString calcSigHashWithMehtodName:[terminalParams valueForKey:@"method"]
                                                     callID:[terminalParams valueForKey:@"call_id"]
                                                     apiKey:[terminalParams valueForKey:@"api_key"]
                                                     secret:[ECKeyChain clientSecret]];
        
        [terminalParams setValue:sig forKey:@"sig"];
    }
    // 设置 apiversion
    if (nil == [terminalParams valueForKey:@"apiversion"]) {
        [terminalParams setValue:API_VERSION forKey:@"apiversion"];
    }
    // 添加 udid 参数
    if (nil == [terminalParams valueForKey:@"devicenumber"]) {
        [terminalParams setValue:[UIDevice UDID] forKey:@"devicenumber"];
    }
    
    // 设置 token
    if (nil == [terminalParams valueForKey:@"access_token"] && ![[terminalParams valueForKey:@"method"] isEqualToString:@"token"]) {
        if ([ECKeyChain accessToken] == nil || [ECKeyChain accessToken] == NULL || [[ECKeyChain accessToken] isEqualToString:@""]) {
            UIAlertView* alert = [[UIAlertView alloc] initWithTitle:nil message:@"网络不给力，请稍后重试！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alert show];
            
            [[ECSpecRequest shareInstance] getAccessToken];
            return nil;
        }
        [terminalParams setValue:[ECKeyChain accessToken] forKey:@"access_token"];
    }
   
    return  terminalParams;

}

@end
