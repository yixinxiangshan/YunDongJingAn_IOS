//
//  ECIndexPath.m
//  HealthyClub
//
//  Created by EC on 2/1/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECIndexPath.h"

@implementation ECIndexPath

@end
