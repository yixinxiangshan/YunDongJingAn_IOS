//
//  NSDateExtends.m
//  IOSExtends
//
//  Created by Alix on 9/24/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "NSDateExtends.h"

@implementation NSDate (Extends)
#pragma mark -
- (NSString*)stringWithFormat:(NSString *)fmt{
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    if (fmt && [fmt length] < 1) {
        fmt = @"yyyy-MM-dd-HH-mm";
    }
    [dateFormatter setLocale:[NSLocale currentLocale]];
    [dateFormatter setDateFormat:fmt];
    return [dateFormatter stringFromDate:self];
}

#pragma mark -
+ (NSDate*)dateFromString:(NSString *)dateDesc formate:(NSString *)fmt{
    NSDateFormatter *dateFormatter =[[NSDateFormatter alloc] init];
    if (fmt == nil || [fmt isEqualToString:@""]) {
        fmt = @"yyyy-MM-dd HH:mm";
    }
    [dateFormatter setLocale:[NSLocale currentLocale]];
    [dateFormatter setDateFormat:fmt];
    return [dateFormatter dateFromString:dateDesc];
}

#pragma mark - 
+ (NSDate*)dateWithToday{
    return [[NSDate date] dateAtMidnight];
}

#pragma mark - 
- (NSDate*)dateAtMidnight{
    NSCalendar* calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents* dateComponents = [calendar components:(NSYearCalendarUnit|NSMonthCalendarUnit|NSDayCalendarUnit) fromDate:[NSDate date]];
    
    NSDate* midnight = [calendar dateFromComponents:dateComponents];
    return midnight;
}

#pragma mark -
- (NSUInteger)getYear{
    return [[[self stringWithFormat:@"yyyyMMddHHmmss"] substringWithRange:NSMakeRange(0, 4)] integerValue];
}

#pragma mark - 
- (NSUInteger)getMonth{
    return [[[self stringWithFormat:@"yyyyMMddHHmmss"] substringWithRange:NSMakeRange(4, 2)] integerValue];
}

#pragma mark - 
- (NSUInteger)getDay{
    return [[[self stringWithFormat:@"yyyyMMddHHmmss"] substringWithRange:NSMakeRange(6, 2)] integerValue];;
}

#pragma mark - 
- (NSUInteger)getHours{
   return [[[self stringWithFormat:@"yyyyMMddHHmmss"] substringWithRange:NSMakeRange(8, 2)] integerValue];;
}

#pragma mark - 
- (NSUInteger)getMinutes{
    return [[[self stringWithFormat:@"yyyyMMddHHmmss"] substringWithRange:NSMakeRange(10, 2)] integerValue];;
}

#pragma mark - 
- (NSUInteger)getSeconds{
    return [[[self stringWithFormat:@"yyyyMMddHHmmss"] substringWithRange:NSMakeRange(12, 2)] integerValue];;
}
#pragma mark-
- (BOOL) isEarlierWithDate:(NSDate *)otherDate
{
    return [self timeIntervalSince1970] < [otherDate timeIntervalSince1970] ? YES : NO;
}
@end
