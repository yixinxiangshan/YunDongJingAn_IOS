//
//  NSStringExtends.m
//  Extends
//
//  Created by Alix on 9/24/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "NSStringExtends.h"
#import "NSDataExtends.h"
#import "ECKeyChain.h"
#import "UIColorExtends.h"
#import "NSAttributedString+DDHTML.h"


@implementation NSString (Extends)
#pragma mark - 
- (BOOL)isWhitespaceOrNewLine{
    NSCharacterSet* whitespaces = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    for (NSUInteger index=0; index < self.length; index++) {
        unichar c = [self characterAtIndex:index];
        if (NO == [whitespaces characterIsMember:c]) {
            return NO;
        }
    }
    return YES;
}

#pragma mark - 
- (BOOL)isEmpty{
    return ([self length] > 0 ? NO : YES);
}

#pragma mark -
- (NSString *) upperFirstCharString
{
    NSString* first = [self substringToIndex:1];
    return [NSString stringWithFormat:@"%@%@",[first uppercaseString],[self substringFromIndex:1]];
}
#pragma mark- encodeWithEncoding
- (NSString *) encodeWithUTF8
{
    return [self encodeWithEncoding:NSUTF8StringEncoding];
}
- (NSString *) encodeWithEncoding:(NSStringEncoding)NSStringEncoding
{
    return [NSString stringWithCString:[self UTF8String] encoding:NSStringEncoding];
}
#pragma mark -
- (NSString*)md5Hash{
    return [[self dataUsingEncoding:NSUTF8StringEncoding] md5Hash];
}

#pragma mark - 
- (NSString*)sha1Hash{
    return [[self dataUsingEncoding:NSUTF8StringEncoding] sha1Hash];
}
#pragma mark - random string
+ (NSString *) randomString:(CGFloat)withUpper maxLength:(NSInteger)maxLength minLength:(NSInteger)minLength
{
    NSMutableString* result = [NSMutableString new];
    NSInteger length = arc4random()%(maxLength - minLength) + minLength;
    CGFloat upper = 0;
    for (int i = 0; i < length; i ++) {
        char c = withUpper && (arc4random() & 0x3ff) < withUpper * 1024 ? arc4random()%25+65 : arc4random()%25+97 ;
        [result appendString:[NSString stringWithFormat:@"%c",c]];
        upper += c < 91;
    }
    return result;
}
#pragma mark - 
+ (NSString*)appDoucmentsPath{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
    return basePath;
}

#pragma mark -
+ (NSString*)appLibraryPath{
    NSArray* paths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
    NSString* basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
    return basePath;
}

#pragma mark - 
+ (NSString*)appCachesPath{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
    return basePath;
}

#pragma mark - 
+ (NSString*)appTmpPath{
    return NSTemporaryDirectory();
}

#pragma mark - 
+ (NSString*)filepathWithRootDirectory:(NSString *)rootDir fileName:(NSString *)fileName{
    if (nil != rootDir && nil != fileName && [rootDir length] > 0 && [fileName length] > 0) {
        return [rootDir stringByAppendingPathComponent:fileName];
    }
    return nil;
}

#pragma mark -
- (NSString*)urlEncodedStringWithCFStringEncoding:(CFStringEncoding)encoding{
    return ((__bridge  NSString *)CFURLCreateStringByAddingPercentEscapes(NULL, (CFStringRef)self, NULL, CFSTR("￼=,!$&'()*+;@?\n\"<>#\t :/"), encoding));
}

#pragma mark - 
- (NSString*)urlEncodedString{
    return [self urlEncodedStringWithCFStringEncoding:kCFStringEncodingUTF8];
}
#pragma mark - 
- (NSString*)urlString{
    return [self stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
}
#pragma mark - 
- (NSDictionary*)queryContentsUsingEncoding:(NSStringEncoding)encoding{
    NSCharacterSet* delimiterSet = [NSCharacterSet characterSetWithCharactersInString:@"&;"];
    NSMutableDictionary* pairs = [NSMutableDictionary dictionary];
    NSScanner* scanner = [[NSScanner alloc] initWithString:self];
    while (![scanner isAtEnd]) {
        NSString* pairString = nil;
        [scanner scanUpToCharactersFromSet:delimiterSet intoString:&pairString];
        [scanner scanCharactersFromSet:delimiterSet intoString:NULL];
        NSArray* kvPair = [pairString componentsSeparatedByString:@"="];
        if (kvPair.count == 1 || kvPair.count == 2) {
            NSString* key = [[kvPair objectAtIndex:0]
                             stringByReplacingPercentEscapesUsingEncoding:encoding];
            NSMutableArray* values = [pairs objectForKey:key];
            if (nil == values) {
                values = [NSMutableArray array];
                [pairs setObject:values forKey:key];
            }
            if (kvPair.count == 1) {
                [values addObject:[NSNull null]];
                
            } else if (kvPair.count == 2) {
                NSString* value = [[kvPair objectAtIndex:1]
                                   stringByReplacingPercentEscapesUsingEncoding:encoding];
                [values addObject:value];
            }
        }
    }
    return [NSDictionary dictionaryWithDictionary:pairs];
}

#pragma mark - 网络请求参数聚合
+ (NSString*)polymerizeRequestParams:(NSDictionary*)params{
    if (nil == params) {
        return nil;
    }
    
	NSArray* keys = [params.allKeys sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
    if ([keys count] == 0) {
        return nil;
    }
    NSMutableString* joined = [[NSMutableString alloc] init];
	for (id obj in [keys objectEnumerator]) {
		id value = [params valueForKey:obj];
		if ([value isKindOfClass:[NSString class]]) {
			[joined appendString:obj];
			[joined appendString:@"="];
			[joined appendString:value];
            [joined appendString:@"&"];
		} else if ([value isKindOfClass:[NSNumber class]]) {
            [joined appendString:obj];
			[joined appendString:@"="];
			[joined appendString:[NSString stringWithFormat:@"%d", [value intValue]]];
            [joined appendString:@"&"];
        }
	}
    
    if ([joined hasSuffix:@"&"]) {
        NSString* retStr = [joined substringToIndex:[joined length]-1];
        return retStr;
    }
    if ([joined isEmpty]) {
        return nil;
    }
    return joined;
}

#pragma mark -
- (NSString*)addingPercentEscapesUsingEncoding:(NSStringEncoding)encoding{
    return [self stringByAddingPercentEscapesUsingEncoding:encoding];
}

#pragma mark - 
- (NSString*)addingPercentEscapes{
    return [self stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
}

#pragma mark - 
+ (NSString*)UDID{
    NSString* uuid = [ECKeyChain deviceUDID];
    if (uuid && uuid.length) {
        return uuid;
    }
    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    if ([userDefaults objectForKey:@"com.ecloudiot.ios.applications.deviceudid"]) {
        return [userDefaults objectForKey:@"com.ecloudiot.ios.applications.deviceudid"];
    }
    CFUUIDRef uuidRef = CFUUIDCreate(NULL);
    CFStringRef strRef = CFUUIDCreateString(NULL, uuidRef);
    CFRelease(uuidRef);
    [userDefaults setObject:((__bridge NSString*)strRef) forKey:@"com.ecloudiot.ios.applications.deviceudid"];
    return ((__bridge  NSString*)strRef);
}


#pragma mark - 根据时间和随机值创建calllID
+(NSString*)randomCallID{
    NSDateFormatter* format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"ssyyyyMMmmHHdd"];
    return [NSString stringWithFormat:@"%@%ld",[format stringFromDate:[NSDate date]], random() & 0xFFFF];
}
#pragma mark - 根据参数生成sig
+ (NSString*)calcSigHashWithMehtodName:(NSString*)method
                                callID:(NSString*)callID
                                apiKey:(NSString*)apiKey
                                secret:(NSString*)secret{
    //    NSString* aduexStr = [NSString stringWithFormat:@"api_key=%@call_id=%@method=%@%@",apiKey, callID, method, secret];
    NSString* aduexStr = [NSString stringWithFormat:@"api_key=%@call_id=%@method=%@%@",apiKey, callID, method, secret];
    return [aduexStr md5Hash];
}
#pragma mark - 获取查询课程时间参数
+ (NSString*)YearAndMouth{
    NSDateFormatter* format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy-MM"];
    return [NSString stringWithFormat:@"%@",[format stringFromDate:[NSDate date]]];
}

/**
 *  转化为驼峰式
 */
- (instancetype) toCamel:(BOOL)isWithFirstWord
{
    char c;
    unichar temp[self.length];
    int count = 0;
    for (int i = 0 ; i < self.length; i ++) {
        c = [self characterAtIndex:i];
        if (c == '_' && ++i < self.length) {
            c = [self characterAtIndex:i];
            if (c > 90) {
                c -= 32;
            }
        }
        temp[count++] = c;
    }
    if (temp[0] > 90 && isWithFirstWord) {
        temp[0] -= 32;
    }
    return [NSString stringWithCharacters:temp length:count];
}

/**
 *  转化为蛇底式
 */
- (instancetype) toSnake
{
    char c = [self characterAtIndex:0];
    unichar temp[self.length * 2];
    int count = 0;
    temp[count++] = c + 32;
    for (int i = 1; i < self.length; i ++) {
        c = [self characterAtIndex:i];
        if (c < 91) {
            temp[count ++] = '_';
            c += 32;
        }
        temp[count++] = c;
    }
    return [NSString stringWithCharacters:temp length:count];
}

@end




#pragma mark - 获取设备号
@implementation UIDevice (UDID)
+ (NSString*)UDID{
    NSString* uuid = [ECKeyChain deviceUDID];
    if (uuid && uuid.length) {
        return uuid;
    }
    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    if ([userDefaults objectForKey:@"com.ecloudiot.ios.applications.deviceudid"]) {
        return [userDefaults objectForKey:@"com.ecloudiot.ios.applications.deviceudid"];
    }
    CFUUIDRef uuidRef = CFUUIDCreate(NULL);
    CFStringRef strRef = CFUUIDCreateString(NULL, uuidRef);
    CFRelease(uuidRef);
    [userDefaults setObject:((__bridge NSString*)strRef) forKey:@"com.ecloudiot.ios.applications.deviceudid"];
    return ((__bridge  NSString*)strRef);
}
@end
@implementation NSAttributedString (html)

+ (NSAttributedString *) attributedStringWithHtmlString:(NSString *)nsstring defaultFont:(UIFont *)font
{
    NSString* string = [nsstring stringByReplacingOccurrencesOfString:@"<br/>" withString:@"\n"];
    return [NSAttributedString attributedStringFromHTML:string boldFont:font];
}

@end
