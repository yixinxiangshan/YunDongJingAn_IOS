//
//  ECClearApp.h
//  HealthyClub
//
//  Created by EC on 2/21/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ExitDelegate : NSObject <UIAlertViewDelegate>
@end

@interface ECClearApp : NSObject

+ (ECClearApp*)shareInstance;
/**
 * 清空token/enterpriseid/apikey/sonSortList
 */
+ (void)clearApp;

/**
 * 清空缓存
 */
+ (void)clearCache:(BOOL)isAlert;

/**
 * 退出程序
 */
- (void)exitAppForNet;
- (void)exitApp:(NSString*)title message:(NSString*)msg;

@end
