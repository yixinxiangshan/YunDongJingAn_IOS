//
//  IIViewDeckConfig.h
//  ECFramework
//
//  Created by EC on 2/28/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#ifndef ECFramework_IIViewDeckConfig_h
#define ECFramework_IIViewDeckConfig_h

#import "IISideController.h"
#import "IIViewDeckController.h"
#import "IIWrapController.h"


#endif
