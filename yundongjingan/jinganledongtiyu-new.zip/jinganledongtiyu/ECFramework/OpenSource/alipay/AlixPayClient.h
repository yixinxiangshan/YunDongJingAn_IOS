//
//  AlixPayClient.h
//  ECDemoFrameWork
//
//  Created by EC on 10/15/13.
//  Copyright (c) 2013 EC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AlixPayResult.h"
@protocol AlixPayResultDelegate <NSObject>

@required
-(void)paymentSuccess:(AlixPayResult*)result;
-(void)paymentFailed:(AlixPayResult*)result;

@end

@class PaymentModel;

@interface AlixPayClient : NSObject

@property (nonatomic,strong)id<AlixPayResultDelegate> resultDelegate;

-(void) submitPayment:(PaymentModel*) payModel;

@end
/*
 out_trade_no;
 subject;
 body;
 total_fee;
 notify_url;
 */

@interface PaymentModel : NSObject

@property (nonatomic,strong) NSString* out_trade_no;
@property (nonatomic,strong) NSString* subject;
@property (nonatomic,strong) NSString* body;
@property (nonatomic,assign) float total_fee;
@property (nonatomic,strong) NSString* notify_url;
@property (nonatomic,strong) NSString* appScheme;

-(id)initWithTradeNum:(NSString*)out_trade_no subject:(NSString*)subject total_fee:(float)total_fee;
-(id)initWithTradeNum:(NSString*)out_trade_no subject:(NSString*)subject total_fee:(float)total_fee notify_url:(NSString*)notify_url;

@end