//
//  AlixPayClient.m
//  ECDemoFrameWork
//
//  Created by EC on 10/15/13.
//  Copyright (c) 2013 EC. All rights reserved.
//

#import "AlixPayClient.h"
#import "ECPopViewUtil.h"
#import "DataVerifier.h"
#import "DataSigner.h"
#import "DataConfigs.h"
#import "AlixPayOrder.h"
#import "AlixLibService.h"
#import "ECAppDelegate.h"

@interface AlixPayClient ()

@end

@implementation AlixPayClient

/*
 out_trade_no;
 subject;
 body;
 total_fee;
 notify_url;
 */
-(void) submitPayment:(PaymentModel*) payModel{
    AlixPayOrder *order = [[AlixPayOrder alloc] init];
    order.partner = PartnerID;
    order.seller = SellerID;
    
    order.tradeNO = payModel.out_trade_no; //订单ID
    order.productName = payModel.subject; //商品标题
	order.productDescription = payModel.body; //商品描述
    order.amount = [NSString stringWithFormat:@"%.2f",payModel.total_fee];//商品价格
    order.notifyURL =  payModel.notify_url; //回调URL
    
    NSString *orderInfo = [order description];
    
    NSString* signedStr = [self sign:orderInfo];
    
    NSString *orderString = [NSString stringWithFormat:@"%@&sign=\"%@\"&sign_type=\"%@\"",
                             orderInfo, signedStr, @"RSA"];
    
    NSLog(@"orderString : %@",orderString);
    [AlixLibService payOrder:orderString AndScheme:payModel.appScheme seletor:@selector(paymentResult:) target:self];
}


-(void)paymentResult:(NSString*)results{
    AlixPayResult* result = [[AlixPayResult alloc] initWithString:results];
    if (result) {
        if (result.statusCode == 9000)
        {
			/*
			 * 用公钥验证签名 严格验证请使用result.resultString与result.signString验签
			 */
            
            //交易成功
//			id<DataVerifier> verifier;
//            verifier = CreateRSADataVerifier(AlipayPubKey);
            
//			if ([verifier verifyString:result.resultString withSign:result.signString])
//            {
//                //验证签名成功，交易结果无篡改
//                
//                [ECPopViewUtil toast:[NSString stringWithFormat:@"交易成功!"]];
//                if (_resultDelegate) {
//                    [_resultDelegate paymentSuccess:result];
//                }
//			}
            [ECPopViewUtil toast:[NSString stringWithFormat:@"交易成功!"]];
            if (_resultDelegate) {
                [_resultDelegate paymentSuccess:result];
            }
        }
        else
        {
            [ECPopViewUtil toast:[NSString stringWithFormat:@"交易失败：%@",[result statusMessage]]];
            if (_resultDelegate) {
                [_resultDelegate paymentFailed:result];
            }
//            NSLog(@"交易失败：%@",result.statusMessage);
        }

    }
    else
    {
        [ECPopViewUtil toast:[NSString stringWithFormat:@"未知失败！"]];
        if (_resultDelegate) {
            [_resultDelegate paymentFailed:result];
        }
    }
}

-(NSString*)sign:(NSString*)orderInfo{
    id<DataSigner> signer;
    signer = CreateRSADataSigner(PartnerPrivKey);
    NSString *signedString = [signer signString:orderInfo];
    return signedString;
}

-(void)setResultDelegate:(id<AlixPayResultDelegate>)resultDelegate{
    _resultDelegate = resultDelegate;
    [[ECAppDelegate appDelegate] setPayResultDelegate:resultDelegate];
}
@end


@implementation PaymentModel

-(id)initWithTradeNum:(NSString*)out_trade_no subject:(NSString*)subject total_fee:(float)total_fee{
    return [self initWithTradeNum:out_trade_no subject:subject total_fee:total_fee notify_url:nil];
}
-(id)initWithTradeNum:(NSString*)out_trade_no subject:(NSString*)subject total_fee:(float)total_fee notify_url:(NSString*)notify_url{
    self = [super init];
    if (self) {
        _out_trade_no = out_trade_no;
        _subject = subject;
        _total_fee = total_fee;
        _notify_url = (notify_url == nil)?NotifyUrl:notify_url;
    }
    return self;
}

@end