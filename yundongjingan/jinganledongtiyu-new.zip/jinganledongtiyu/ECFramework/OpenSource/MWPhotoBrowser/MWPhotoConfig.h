//
//  MWPhotoConfig.h
//  ECFramework
//
//  Created by EC on 2/28/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#ifndef ECFramework_MWPhotoConfig_h
#define ECFramework_MWPhotoConfig_h

#import "MBProgressHUD.h"
#import "MWCaptionView.h"
#import "MWPhoto.h"
#import "MWPhotoBrowser.h"

#import "MWTapDetectingImageView.h"
#import "MWTapDetectingView.h"
#import "MWZoomingScrollView.h"

#endif
