//
//  ECWebImageDownloader.h
//  ECMuse
//
//  Created by Alix on 10/22/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UIImageView+WebCache.h"

/**
 * SDWebImage 封装
 */
@interface ECWebImageDownloader : NSObject <SDWebImageManagerDelegate>

/**
 * 单例
 */
+ (id)sharedInstance;

/**
 * 下载图片
 */
-(void)downloadImageWithURI:(NSString*)uri;
-(void)downloadImageWithURL:(NSURL*)url;

/**
 * 获取图片
 */
-(UIImage*)getImageWithURI:(NSString*)uri;
-(UIImage*)getImageWithURL:(NSURL*)url;

/**
 * 清除图片
 */
-(void)removeImageWithURI:(NSString*)uri;
-(void)removeImageWithURL:(NSURL*)url;
-(void)removeAllImages; // 清除过期的
-(BOOL)clearAllImages;  // 从硬盘上删除
@end
