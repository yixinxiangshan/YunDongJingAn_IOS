//
//  ECKeyChain.h
//  QCRL_NEW
//
//  Created by Guanglu Kang on 8/20/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import <Foundation/Foundation.h>  
#import <Security/Security.h>  


/**
 * 保存用户名和密码
 */

@interface ECKeyChain : NSObject

/**
 * 存用户名,  密码, 设备id, accessToken
 */
+ (void)saveUserName:(NSString*)userName
            password:(NSString*)passwd
            deviceID:(NSString*)uuid
         accessToken:(NSString*)token;

/**
 * 取
 */
+(NSString*)userName;
+(NSString*)password;
+(NSString*)deviceUDID;
+(NSString*)accessToken;

/**
 * 删除
 */
+(void)deleteUsernameAndPasswd;

#pragma mark - 企业编号
+(void)saveEnterpriseId:(NSString*)enterpriseId;
+(NSString*)enterpriseId;
#pragma mark - apiKey
+(void)saveApiKey:(NSString*)apiKey;
+(NSString*)apiKey;

#pragma mark - clientSecret
+(void)saveClientSecret:(NSString*)clientSecret;
+(NSString*)clientSecret;

@end 
