//
//  ECJsonParser.h
//  ECMuse
//
//  Created by Alix on 10/22/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 * json解析
 * iOS 5.0 & Later 用系统的
 * iOS 5.0 以下用SBJSON
 */
@interface ECJsonParser : NSObject{
    
}
/**
 * 解析
 * @return 返回解析对象
 * @param   jsonString  未解析前的json字符串
 * @param   jsonData    未解析前的json字节流
 */
+ (id)objectWithJsonString:(NSString*)jsonString;
+ (id)objectWithJsonData:(NSData*)jsonData;
+ (NSString*)stringWithDic:(NSDictionary*)dic;

@end
