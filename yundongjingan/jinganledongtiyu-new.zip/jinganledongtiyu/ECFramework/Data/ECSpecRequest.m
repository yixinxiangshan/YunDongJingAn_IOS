//
//  ECSpecRequest.m
//  HealthyClub
//
//  Created by EC on 1/28/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECSpecRequest.h"
#import "ECNetRequest.h"
#import "ECKeyChain.h"
#import "NSObjectExtends.h"
#import "Extends.h"
#import "ECPopViewUtil.h"
#import "ECClearApp.h"
#import "Utils.h"

@implementation ECSpecRequest

+ (ECSpecRequest*)shareInstance{
    static ECSpecRequest* specRequest = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        specRequest = [[ECSpecRequest alloc] init];
    });
    return specRequest;
}

#pragma mark - 检查服务器端版本号
- (void)checkOriginVersion:(BOOL)isForce{
    // 发送请求
    NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:appInfo(), @"method", nil];
    if (isForce) {
         [[NetRequestManager sharedInstances] addOperation:[FormDataRequest requestNetURI:API_URL params:params delegate:self finishedSelector:@selector(getVersionFinishedWithForce:) failSelector:@selector(webRequestFailed:)]];
    }else{
        [[NetRequestManager sharedInstances] addOperation:[FormDataRequest requestNetURI:API_URL params:params delegate:self finishedSelector:@selector(getVersionsFinished:) failSelector:@selector(webRequestFailed:)]];
    }
    [ECPopViewUtil showLoading:nil];
    
}
//强制检查
- (void)getVersionFinishedWithForce:(ASIHTTPRequest*)request{
    [ECPopViewUtil removeLoading];
    id obj = [ECJsonParser objectWithJsonString:[request responseString]];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        ECLog(@"%@", [obj description]);
        id data = [obj valueForKey:@"data"];
        if (data && [data isNSxxxClass:[NSDictionary class]]) {
            id versions = [data objectForKey:@"NewEdition"];
            if (versions && [versions isNSxxxClass:[NSDictionary class]]) {
                _appInfoModel = [[AppInfo alloc] initWithDictionary:versions];
                ECLog(@"服务器版本：%@",_appInfoModel.VersionNum);
                if ([_appInfoModel.VersionNum floatValue] >[[[[NSBundle mainBundle] infoDictionary] valueForKey:@"CFBundleVersion"] floatValue]) {
                    UIAlertView* av = [[UIAlertView alloc] initWithTitle:@"发现新版本" message:@"是否更新" delegate:self cancelButtonTitle:@"下次再说" otherButtonTitles:nil, nil];
                    [av addButtonWithTitle:@"更新"];
                    [av show];
                    return;
                }
            }
        }
    }
    
    UIAlertView* av = [[UIAlertView alloc] initWithTitle:@"当前版本已是最新版本" message:@"" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [av show];
}

- (void)getVersionsFinished:(ASIHTTPRequest*)request{
    [ECPopViewUtil removeLoading];
    id obj = [ECJsonParser objectWithJsonString:[request responseString]];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        ECLog(@"%@", [obj description]);
        id data = [obj valueForKey:@"data"];
        if (data && [data isNSxxxClass:[NSDictionary class]]) {
            id versions = [data objectForKey:@"NewEdition"];
            if (versions && [versions isNSxxxClass:[NSDictionary class]]) {
                _appInfoModel = [[AppInfo alloc] initWithDictionary:versions];
                ECLog(@"服务器版本：%@",_appInfoModel.VersionNum);
                if ([_appInfoModel.VersionNum floatValue] >[[[[NSBundle mainBundle] infoDictionary] valueForKey:@"CFBundleVersion"] floatValue]) {
                    UIAlertView* av = [[UIAlertView alloc] initWithTitle:@"发现新版本" message:@"是否更新" delegate:self cancelButtonTitle:@"下次再说" otherButtonTitles:nil, nil];
                    [av addButtonWithTitle:@"更新"];
                    [av show];
                    return;
                }
            }
        }
    }
    
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    ECLog(@"%@ %d", NSStringFromSelector(_cmd), buttonIndex);
    switch (buttonIndex) {
        case 0:
            break;
        case 1:
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:_appInfoModel.DownloadUrl]];
            break;
        default:
            break;
    }
}

#pragma mark - 获取默认token
- (void)getDefaultAccessToken{
    NSLog(@"start getDefaultToken");
    if (![NetRequestManager networdEnabled]) {
        // 没有网络退出程序
        [[ECClearApp shareInstance] exitAppForNet];
        return;
    }
    NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"device", @"grant_type",[UIDevice UDID], @"devicenumber",tokenMethod(),@"method", API_KEY,@"client_id",API_KEY,@"api_key", nil];
    
    FormDataRequest* request = [FormDataRequest requestNetURI:TOKEN_URL
                                                       params:params
                                                     delegate:self
                                             finishedSelector:@selector(defaultTokenFinished:)
                                                 failSelector:@selector(tokenRequestFailed:)];
    if (request) {
        [[NetRequestManager sharedInstances] addOperation:request];
    }
    
}
#pragma mark - 默认token获取成功 及失败
- (void)defaultTokenFinished:(FormDataRequest*)request{
    NSLog(@" getDefaultToken Finised");
    NSString* responseString = request.responseString;
    NSLog(@"token response: %@", responseString);
    if ([responseString rangeOfString:@"\"error\""].location != NSNotFound || [responseString rangeOfString:@"\"Error\""].location != NSNotFound) {
        [self showError:responseString];
        return;
    }
    id obj = [ECJsonParser objectWithJsonString:[request responseString]];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        if ([obj valueForKey:@"access_token"]) {
            [ECKeyChain saveUserName:[ECKeyChain userName] password:[ECKeyChain password] deviceID:[UIDevice UDID]
                         accessToken:[obj valueForKey:@"access_token"]];
            return;
        }
    }
    // 拿不到后面就没法继续了
    [[ECClearApp shareInstance] exitAppForNet];
}

#pragma mark - 获取token
- (void)getAccessToken{
    if (![NetRequestManager networdEnabled]) {
        // 没有网络退出程序
        [[ECClearApp shareInstance] exitAppForNet];
        return;
    }
    
    NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"new_user", @"grant_type",[UIDevice UDID], @"devicenumber",tokenMethod(),@"method",[ECKeyChain apiKey],@"client_id", nil];
    
    FormDataRequest* request = [FormDataRequest requestNetURI:TOKEN_URL
                                                       params:params
                                                     delegate:self
                                             finishedSelector:@selector(tokenReuestFinished:)
                                                 failSelector:@selector(tokenRequestFailed:)];
    if (request) {
        [[NetRequestManager sharedInstances] addOperation:request];
    }
    
}

#pragma mark - token获取成功 及失败
- (void)tokenReuestFinished:(FormDataRequest*)request{
    NSString* responseString = request.responseString;
    ECLog(@"token response: %@", responseString);
    if ([responseString rangeOfString:@"\"error\""].location != NSNotFound || [responseString rangeOfString:@"\"Error\""].location != NSNotFound) {
        [self showError:responseString];
        return;
    }
    id obj = [ECJsonParser objectWithJsonString:[request responseString]];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        if ([obj valueForKey:@"access_token"]) {
            [ECKeyChain saveUserName:[ECKeyChain userName] password:[ECKeyChain password] deviceID:[UIDevice UDID]
                         accessToken:[obj valueForKey:@"access_token"]];
            [self getSonsortList];
            return;
        }
    }
    // 拿不到后面就没法继续了
    [[ECClearApp shareInstance] exitAppForNet];
}
- (void) tokenRequestFailed:(FormDataRequest*)request{
    ECLog(@"获取token失败!!!");
    // 没有网络退出程序
    [[ECClearApp shareInstance] exitAppForNet];
}

#pragma mark - 获取sonSortList
- (void)getSonsortList{
    NSDictionary* params = [NSDictionary dictionaryWithObjectsAndKeys:@"0",@"sortid",sonSortList(),@"method", nil];
    
    FormDataRequest* request = [FormDataRequest requestNetURI:API_URL
                                                       params:params
                                                     delegate:self
                                             finishedSelector:@selector(sonSortListFinished:)
                                                 failSelector:@selector(sonSortListFailed:)];
    if (request) {
        [[NetRequestManager sharedInstances] addOperation:request];
        [ECPopViewUtil showLoading:nil];
    }
}
- (void)sonSortListFinished:(FormDataRequest*)request{
    NSString* responseString = request.responseString;
    ECLog(@"token response: %@", responseString);
    if ([responseString rangeOfString:@"\"error\""].location != NSNotFound || [responseString rangeOfString:@"\"Error\""].location != NSNotFound) {
        [self showError:responseString];
        return;
    }
    id obj = [ECJsonParser objectWithJsonString:[request responseString]];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        id tempData = [obj valueForKey:@"data"];
        if (tempData && [tempData isNSxxxClass:[NSDictionary class]]) {
            SonList* ss = [[SonList alloc] initWithDictionary:tempData];
            if (ss) {
                NSData *ssData = [NSKeyedArchiver archivedDataWithRootObject:ss];//打包为nsdata型
                [[NSUserDefaults standardUserDefaults] setObject:ssData forKey:@"sonSortList"];
                [[NSUserDefaults standardUserDefaults] synchronize];
            }else{
                //拿不到后面就没法继续了
                [[ECClearApp shareInstance] exitAppForNet];
            }
        }
    }
    [ECPopViewUtil removeLoading];
}
- (void) sonSortListFailed:(FormDataRequest*)request{
    ECLog(@"获取sonSortList失败!!!");
    [ECPopViewUtil removeLoading];
    [[ECClearApp shareInstance] exitAppForNet];
}
- (void)showError:(NSString*)responseString{
    id obj = [ECJsonParser objectWithJsonString:responseString];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        id tempData = [obj valueForKey:@"data"];
        NSString* showError = @"";
        if ([tempData objectForKey:@"error"]) {
            
            showError =[[tempData objectForKey:@"error"] objectForKey:@"errordes"];
        }
        if ([tempData objectForKey:@"Error"]) {
            showError =[tempData objectForKey:@"Error"];
        }
        UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:nil
                                                            message:showError
                                                           delegate:nil
                                                  cancelButtonTitle:@"确定"
                                                  otherButtonTitles:nil, nil];
        [alertView show];
    }
    
}
@end
