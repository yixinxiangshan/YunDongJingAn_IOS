//
//  ECJsonParser.m
//  ECMuse
//
//  Created by Alix on 10/22/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import "ECJsonParser.h"
#import "Extends.h"
#import "SBJSON.h"

@interface ECJsonParser ()

/**
 * 解析
 * @return  解析后的objective-c 对象
 * @param   jsonString  未解析前的json字串
 * @param   jsonData    未解析前的json字节流
 */
+ (id)objectWithSBJsonString:(NSString*)jsonString NS_AVAILABLE_IOS(4_0);
+ (id)objectWithSBJsonData:(NSData*)jsonData NS_AVAILABLE_IOS(4_0);


+ (float)systemVersion;

@end

@implementation ECJsonParser

+ (float)systemVersion{
    return [[UIDevice currentDevice].systemVersion floatValue];
}
#pragma mark - 解系统提供方法解析
+ (id)objectWithJsonString:(NSString *)jsonString{
    if ([ECJsonParser systemVersion] >= 5.0) {
        return [ECJsonParser objectWithJsonData:[jsonString dataUsingEncoding:NSUTF8StringEncoding]];
    }
    return [ECJsonParser objectWithSBJsonString:jsonString];
} 
+ (id)objectWithJsonData:(NSData *)jsonData{
    
    if (jsonData && ![jsonData isMemberOfClass:[NSNull class]] && [jsonData length]) {
        if ([ECJsonParser systemVersion] >= 5.0) {
            NSError *jsonParsingError = nil;
            id object = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&jsonParsingError];
            if (jsonParsingError) {
                return nil;
            }
            return object;
        }
        return [ECJsonParser objectWithSBJsonString:[NSString stringWithCString:[jsonData bytes] encoding:NSUTF8StringEncoding]];
    }
    return nil;
}

#pragma mark - 用SBJSON解析 
+ (id)objectWithSBJsonData:(NSData *)jsonData{
    if (jsonData && ![jsonData isMemberOfClass:[NSNull class]] && [jsonData length]) {
        return [ECJsonParser objectWithSBJsonString:[NSString stringWithCString:[jsonData bytes] encoding:NSUTF8StringEncoding]];
    }
    return nil;
}
+ (id)objectWithSBJsonString:(NSString *)jsonString{
    if ([jsonString isEmpty]) {
        return nil;
    }
    SBJSON* sbjson = [[SBJSON alloc] init];
    id obj = [sbjson objectWithString:jsonString];
    sbjson = nil;
    if (obj) {
        return obj;
    }
    return nil;
}

+ (NSString*)stringWithDic:(NSDictionary*)dic{
    NSError *err;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&err];
    if (!jsonData) {
//        NSLog(@"stringWithDic : NSJSONSerialization nsdictionary to nsdata error ...  %@",err.localizedDescription);
        return nil;
    }else{
        return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
}
+ (NSData *)dataWithDic:(NSDictionary *)dic
{
    NSError *err;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&err];
    if (!jsonData) {
        NSLog(@"NSJSONSerialization nsdictionary to nsdata error ...");
        return nil;
    }else{
        return jsonData;
    }
    
}
@end
