//
//  ECSpecRequest.h
//  HealthyClub
//
//  Created by EC on 1/28/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Models.h"


@interface ECSpecRequest : NSObject

@property (nonatomic, strong) AppInfo* appInfoModel;

+ (ECSpecRequest*)shareInstance;
/**
 *检查服务器端版本号
 */
- (void)checkOriginVersion:(BOOL)isForce;

/**
 * 获取默认token
 */
- (void)getDefaultAccessToken;

/**
 * 获取token
 */
- (void)getAccessToken;
/**
 * 获取sonSortList
 */
- (void)getSonsortList;
/**
 * 弹出错误框
 */
- (void)showError:(NSString*)responseString;
@end
