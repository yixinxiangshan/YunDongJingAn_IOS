//
//  MSCoreData.h
//  DeliciousCake
//
//  Created by Alix on 1/3/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ECCoreDataSupport.h"

@interface ECCoreDataSupport (MSSPA)
/**
 * 缓存数据
 * @return @YES 保存成功 @NO保存失败
 * @param   data    要保存的数据
 * @param   time    数据在何时保存的
 * @param   md5Hash 网络请求的hash值
 */
- (BOOL)saveCachesWithData:(NSData*)data
                      time:(NSDate*)time
                   md5Hash:(NSString*)md5Hash;

/**
 * 同上
 * @param time 省略则默认使用系统当前时间
 */
- (BOOL)saveCachesWithData:(NSData *)data
                   md5Hash:(NSString *)md5Hash;

/**
 * 获取缓存中的数据
 * @return  缓存中的数据
 * @param   md5Hash 根据md5Hash值查询缓存数据
 */
- (NSData*)cachesWithMd5Hash:(NSString*)md5Hash;
/**
 * 清除所有
 */
- (void) deleteAllCaches;
@end
