//
//  MSCoreData.m
//  DeliciousCake
//
//  Created by Alix on 1/3/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "CoreData.h"
#import "Caches.h"
#import "Extends.h"
#import "Utils.h"

// 缓存保存15分钟
#define kCachesLife     900

@implementation ECCoreDataSupport (MSSPA)
- (BOOL)saveCachesWithData:(NSData*)data
                      time:(NSDate*)time
                   md5Hash:(NSString*)md5Hash{
    if (data && [data length] && md5Hash && [md5Hash length] ) {
        if (time == nil) {
            time = [NSDate date];
        }
        // 先执行删除
        NSManagedObjectContext *moc =  self.managedObjectContext;
        NSEntityDescription *entityDescription = [NSEntityDescription
                                                  entityForName:NSStringFromClass([Caches class]) inManagedObjectContext:moc];
        NSFetchRequest *request = [[NSFetchRequest alloc] init];
        [request setEntity:entityDescription];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:
                                  @"(md5Hash == %@)",  md5Hash];
        
        [request setPredicate:predicate];
        NSError *error = nil;
        NSArray *array = [moc executeFetchRequest:request error:&error];
        if (error == nil) {
            if (array != nil) {
                // 删除
                for (Caches* cache in array) {
                    [moc deleteObject:cache];
                }
                if( ![[ECCoreDataSupport sharedInstance] saveContext]) {
                    return NO;
                }
            }
            
            // 添加、保存
            Caches* cache = [NSEntityDescription insertNewObjectForEntityForName:NSStringFromClass([Caches class]) inManagedObjectContext:moc];
            cache.md5Hash = md5Hash;
            cache.time = time;
            cache.data = data;
            return [[ECCoreDataSupport sharedInstance] saveContext];
        }
    }
    return NO;
}
#pragma mark -
- (BOOL)saveCachesWithData:(NSData *)data
                   md5Hash:(NSString *)md5Hash{
    return [self saveCachesWithData:data time:[NSDate date] md5Hash:md5Hash];
}

#pragma mark - 
- (NSData*)cachesWithMd5Hash:(NSString*)md5Hash{
    NSManagedObjectContext *moc =  self.managedObjectContext;
    NSEntityDescription *entityDescription = [NSEntityDescription
                                              entityForName:NSStringFromClass([Caches class])
                                              inManagedObjectContext:moc];
    NSFetchRequest *request = [[NSFetchRequest alloc] init] ;
    [request setEntity:entityDescription];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:
                              @"(md5Hash == %@)", md5Hash];
    
    [request setPredicate:predicate];
    NSError *error = nil;
    NSArray *array = [moc executeFetchRequest:request error:&error];
    if (error == nil) {
        if (array != nil) {
            if ([array count] != 1) {
                return nil;
            } else if([array count] == 1) {
                Caches* cache =  [array objectAtIndex:0];
                NSTimeInterval deltaTime = [cache.time timeIntervalSinceDate:[NSDate date]];
                ECLog(@"缓存时间:@%@ %@ %f %f", cache.time, [NSDate date], deltaTime, fabs(deltaTime));
                if (fabs(deltaTime) > kCachesLife) {
                    return nil;
                }
                return cache.data;
            }
        }
    } else {
        ECLog(@"CoreDataError:%@", [error localizedDescription]);
    }
    

    return nil;
}

- (void) deleteAllCaches{
    [self.managedObjectContext deletedObjects];
}
@end
