//
//  Caches.h
//  DeliciousCake
//
//  Created by Alix on 1/3/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Caches : NSManagedObject

@property (nonatomic, retain) NSString * md5Hash;
@property (nonatomic, retain) NSDate * time;
@property (nonatomic, retain) NSData * data;

@end
