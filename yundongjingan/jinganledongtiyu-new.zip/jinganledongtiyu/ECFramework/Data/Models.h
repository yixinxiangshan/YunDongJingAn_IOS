//
//  Models.h
//  DeliciousCake
//
//  Created by Alix on 12/3/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Jastor.h"

#pragma mark - 子分类 listitem

@interface SonListItem : Jastor

@property (strong, nonatomic) NSString* cms_sort_type_id;
@property (strong, nonatomic) NSString* cnname;
@property (strong, nonatomic) NSString* content_count;
@property (strong, nonatomic) NSString* description;
@property (strong, nonatomic) NSString* father_id;
@property (strong, nonatomic) NSString* id;
@property (strong, nonatomic) NSString* level;
@property (strong, nonatomic) NSString* name;
@property (strong, nonatomic) NSString* project_info_id;
@property (strong, nonatomic) NSString* sort_img;
@property (strong, nonatomic) NSString* top_sort_id;

@end

@interface SonList :Jastor
@property (strong, nonatomic) NSArray* SonSorList;
@end

#pragma mark - 评论 
@interface CommentItem : Jastor

@property (strong, nonatomic) NSString* cms_content_id;
@property (strong, nonatomic) NSString* cms_sort_type_id;
@property (strong, nonatomic) NSString* content;
@property (strong, nonatomic) NSString* created_at;
@property (strong, nonatomic) NSString* id;
@property (strong, nonatomic) NSString* image_cover;
@property (strong, nonatomic) NSString* latitude;
@property (strong, nonatomic) NSString* longitude;
@property (strong, nonatomic) NSString* project_info_id;
@property (strong, nonatomic) NSString* title;
@property (strong, nonatomic) NSString* typenum;
@property (strong, nonatomic) NSString* updated_at;
@property (strong, nonatomic) NSString* user_info_id;
@property (strong, nonatomic) NSString* vote_star;

@end

#pragma mark - 通用listitem
@interface TypeListItem : Jastor

@property (strong, nonatomic) NSString* abstracts;
@property (strong, nonatomic) NSString* cms_content_info_id;
@property (strong, nonatomic) NSString* cms_sort_id;
@property (strong, nonatomic) NSString* cms_sort_type_id;
@property (strong, nonatomic) NSString* comment_count;
@property (strong, nonatomic) NSString* content;
@property (strong, nonatomic) NSString* couponOrderNum;
@property (strong, nonatomic) NSString* created_at;
@property (strong, nonatomic) NSString* down_count;
@property (strong, nonatomic) NSString* id;
@property (strong, nonatomic) NSString* image_cover;
@property (strong, nonatomic) NSString* images_count;
@property (strong, nonatomic) NSString* is_bigimage;
@property (strong, nonatomic) NSString* is_push;
@property (strong, nonatomic) NSString* order_level;
@property (strong, nonatomic) NSString* project_info_id;
@property (strong, nonatomic) NSString* title;
@property (strong, nonatomic) NSString* type;
@property (strong, nonatomic) NSString* up_count;
@property (strong, nonatomic) NSString* updated_at;
@property (strong, nonatomic) NSString* user_info_id;
@property (strong, nonatomic) NSString* view_count;
@property (strong, nonatomic) NSString* vote_all;
@property (strong, nonatomic) NSString* vote_count;
@property (strong, nonatomic) NSString* address;
@property (strong, nonatomic) NSString* latitude;
@property (strong, nonatomic) NSString* longitude;

@end

@interface TypeList : Jastor

@property (strong, nonatomic) NSArray* ListByType;

@end

#pragma mark - 优惠详细 数据模型
@interface PrivilegeDetailItem : Jastor

@property (strong, nonatomic) NSString* Abstract;
@property (strong, nonatomic) NSString* CmsContentInfoId;
@property (strong, nonatomic) NSString* CmsSortypeId;
@property (strong, nonatomic) NSString* CommentCount;
@property (strong, nonatomic) NSString* Content;
@property (strong, nonatomic) NSString* DownCount;
@property (strong, nonatomic) NSString* Id;
@property (strong, nonatomic) NSString* ImageCover;
@property (strong, nonatomic) NSString* ImagesCount;
@property (strong, nonatomic) NSString* OrderLevel;
@property (strong, nonatomic) NSString* ProjectId;
@property (strong, nonatomic) NSString* Title;
@property (strong, nonatomic) NSString* UpCount;
@property (strong, nonatomic) NSString* UserInfoId;
@property (strong, nonatomic) NSString* ViewCount;
@property (strong, nonatomic) NSString* VoteCount;
@property (strong, nonatomic) NSString* address;
@property (strong, nonatomic) NSString* apply_end_time;
@property (strong, nonatomic) NSString* apply_money;
@property (strong, nonatomic) NSString* apply_point;
@property (strong, nonatomic) NSString* apply_start_time;
@property (strong, nonatomic) NSString* apply_type;
@property (strong, nonatomic) NSString* cms_content_id;
@property (strong, nonatomic) NSString* cms_info_shop_id;
@property (strong, nonatomic) NSArray* commentList;
@property (strong, nonatomic) NSString* couponOrderNum;

@end

#pragma mark - 优惠详细 数据模型-衔接模型
@interface PrivilegeDetailLink : Jastor
@property (strong, nonatomic) PrivilegeDetailItem* ContentInfo;
@end

#pragma mark - 图说
@interface ImageDetailItem :Jastor

@property (strong, nonatomic) NSString* Abstract;
@property (strong, nonatomic) NSString* CmsContentInfoId;
@property (strong, nonatomic) NSString* CmsSortypeId;
@property (strong, nonatomic) NSString* CommentCount;
@property (strong, nonatomic) NSString* Content;
@property (strong, nonatomic) NSString* DownCount;
@property (strong, nonatomic) NSString* Id;
@property (strong, nonatomic) NSString* ImageCover;
@property (strong, nonatomic) NSString* ImagesCount;
@property (strong, nonatomic) NSString* IsBigimage;
@property (strong, nonatomic) NSString* OrderLevel;
@property (strong, nonatomic) NSString* ProjectId;
@property (strong, nonatomic) NSString* Title;
@property (strong, nonatomic) NSString* UpCount;
@property (strong, nonatomic) NSString* UserInfoId;
@property (strong, nonatomic) NSString* ViewCount;
@property (strong, nonatomic) NSString* VoteCount;
@property (strong, nonatomic) NSString* address;
@property (strong, nonatomic) NSString* couponOrderNum;
@property (strong, nonatomic) NSArray*  imgList;
@property (strong, nonatomic) NSString* cms_content_id;
@property (strong, nonatomic) NSString* created_at;
@property (strong, nonatomic) NSString* description;
@property (strong, nonatomic) NSString* id;
@property (strong, nonatomic) NSString* image;
@property (strong, nonatomic) NSString* project_info_id;
@property (strong, nonatomic) NSString* updated_at;

@end


@interface  ImageDetailLink: Jastor
@property (strong, nonatomic) ImageDetailItem* ContentInfo;
@end

#pragma mark - 场地

#pragma mark - 场地
@interface StoreDetailItem : Jastor

@property (strong, nonatomic) NSString* Abstract;
@property (strong, nonatomic) NSString* CmsContentInfoId;
@property (strong, nonatomic) NSString* CmsSortypeId;
@property (strong, nonatomic) NSString* CommentCount;
@property (strong, nonatomic) NSString* Content;
@property (strong, nonatomic) NSString* DownCount;
@property (strong, nonatomic) NSString* Id;
@property (strong, nonatomic) NSString* ImageCover;
@property (strong, nonatomic) NSString* ImagesCount;
@property (strong, nonatomic) NSString* IsBigimage;
@property (strong, nonatomic) NSString* OrderLevel;
@property (strong, nonatomic) NSString* ProjectId;
@property (strong, nonatomic) NSString* Title;
@property (strong, nonatomic) NSString* UserInfoId;
@property (strong, nonatomic) NSString* ViewCount;
@property (strong, nonatomic) NSString* VoteAll;

@property (strong, nonatomic) NSString* cms_content_id;
@property (strong, nonatomic) NSString* address;
@property (strong, nonatomic) NSString* latitude;
@property (strong, nonatomic) NSString* longitude;
@property (strong, nonatomic) NSString* phone_num;
@property (strong, nonatomic) NSString* shop_num;

@end

@interface StoreDetailLink : Jastor
@property (strong, nonatomic) StoreDetailItem* ContentInfo;
@end


#pragma mark - 教练
@interface Teacher :Jastor
@property (strong, nonatomic) NSString* Abstract;
@property (strong, nonatomic) NSString* CmsContentInfoId;
@property (strong, nonatomic) NSString* CmsSortypeId;
@property (strong, nonatomic) NSString* CommentCount;
@property (strong, nonatomic) NSString* Content;
@property (strong, nonatomic) NSString* DownCount;
@property (strong, nonatomic) NSString* Id;
@property (strong, nonatomic) NSString* ImageCover;
@property (strong, nonatomic) NSString* ImagesCount;
@property (strong, nonatomic) NSString* IsBigimage;
@property (strong, nonatomic) NSString* OrderLevel;
@property (strong, nonatomic) NSString* ProjectId;
@property (strong, nonatomic) NSString* Title;
@property (strong, nonatomic) NSString* UserInfoId;
@property (strong, nonatomic) NSString* ViewCount;
@property (strong, nonatomic) NSString* VoteAll;

@property (nonatomic, strong) NSString* cms_content_id;
@property (nonatomic, strong) NSString* name;
@property (nonatomic, strong) NSString* detail;
@property (nonatomic, strong) NSString* nickname;
@property (nonatomic, strong) NSString* picture;
@property (nonatomic, strong) NSString* sex;
@property (nonatomic, strong) NSString* birthday;
@end

@interface TeacherLink : Jastor
@property (nonatomic, strong) Teacher* ContentInfo;
@end

#pragma mark - 课程
@interface Course : Jastor
@property (strong, nonatomic) NSString* Abstract;
@property (strong, nonatomic) NSString* CmsContentInfoId;
@property (strong, nonatomic) NSString* CmsSortypeId;
@property (strong, nonatomic) NSString* CommentCount;
@property (strong, nonatomic) NSString* Content;
@property (strong, nonatomic) NSString* DownCount;
@property (strong, nonatomic) NSString* Id;
@property (strong, nonatomic) NSString* ImageCover;
@property (strong, nonatomic) NSString* ImagesCount;
@property (strong, nonatomic) NSString* IsBigimage;
@property (strong, nonatomic) NSString* OrderLevel;
@property (strong, nonatomic) NSString* ProjectId;
@property (strong, nonatomic) NSString* Title;
@property (strong, nonatomic) NSString* UserInfoId;
@property (strong, nonatomic) NSString* ViewCount;
@property (strong, nonatomic) NSString* VoteAll;
@end

@interface CourseLink : Jastor
@property (nonatomic, strong) Course* ContentInfo;
@end

#pragma maek - 课表
@interface ClassScheduel :Jastor
@property (nonatomic, strong) TypeListItem* cms_content;
@property (nonatomic, strong) StoreDetailItem* cms_info_shop;
@property (nonatomic, strong) TypeListItem* cms_info_teacher;
@property (nonatomic, strong) NSString* date_ym;
@property (nonatomic, strong) NSString* duration;
@property (nonatomic, strong) NSString* id;
@property (nonatomic, strong) NSString* picture;
@property (nonatomic, strong) NSString* start_time;
@property (nonatomic, strong) NSString* title;
@property (nonatomic, strong) NSString* week_day;
@property (nonatomic, strong) NSString* cms_content_id;
@property (nonatomic, strong) NSString* course_content_id;
@property (nonatomic, strong) NSString* shop_content_id;
@property (nonatomic, strong) NSString* teacher_content_id;
@end

@interface ListClassScheduel : Jastor
@property (strong, nonatomic) NSArray* schedulelist;
@end

#pragma mark - AppInfo 
@interface AppInfo : Jastor
@property (nonatomic, strong) NSString* ActiveCount;
@property (nonatomic, strong) NSString* ApiKey;
@property (nonatomic, strong) NSString* Cnname;
@property (nonatomic, strong) NSString* Content;
@property (nonatomic, strong) NSString* Description;
@property (nonatomic, strong) NSString* DownloadCount;
@property (nonatomic, strong) NSString* DownloadUrl;
@property (nonatomic, strong) NSString* Id;
@property (nonatomic, strong) NSString* ImageI1;
@property (nonatomic, strong) NSString* ImageI2;
@property (nonatomic, strong) NSString* ImageI3;
@property (nonatomic, strong) NSString* ImageI4;
@property (nonatomic, strong) NSString* ImageI5;
@property (nonatomic, strong) NSString* ImageIcon;
@property (nonatomic, strong) NSString* LastPushTime;
@property (nonatomic, strong) NSString* Name;
@property (nonatomic, strong) NSString* NewupdateDescription;
@property (nonatomic, strong) NSString* Phonetype;
@property (nonatomic, strong) NSString* ProjectInfoId;
@property (nonatomic, strong) NSString* PushCount;
@property (nonatomic, strong) NSString* Slogan;
@property (nonatomic, strong) NSString* Type;
@property (nonatomic, strong) NSString* VersionNum;
@end



