//
//  ECNetRequest.h
//  ECMuse
//
//  Created by Alix on 10/23/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequest.h"
#import "ASICacheDelegate.h"
#import "ASINetworkQueue.h"
#import "ASIFormDataRequest.h"
#import "ECJsonParser.h"
#import "DataConfigs.h"
#import "ASIDownloadCache.h"

@class FormDataRequest;

@interface NetRequestManager : NSObject{
@private
    ASINetworkQueue* _operationQueue;  // 事物队列
}


/**
 * 单例
 */
+(id)sharedInstances;

/**
 * 添加一个请求
 */
- (void)addOperation:(NSOperation*)_operation;

/**
 * 取消一个请求
 */
- (void)cancelOperationWithGUID:(NSString*)_guid;
/**
 * 取消某个请求
 */
- (void)cancelOperationsWithDelegate:(id)delegate;

/**
 * 获取某一个operation
 */
- (FormDataRequest*)operationWithGUID:(NSString*)_guid;

/**
 * 取消所有请求
 */
- (void)cancelAllOperationsAndNotClean;


/**
 * 可在wifi下联接上互联网
 */
+(BOOL)netEnabledWithWifi;
/**
 * 可联网,但是在3G/E网的情况
 */
+(BOOL)networdEnabledWithWWAN;

/**
 * 是否有网络联接
 */
+(BOOL)networdEnabled;

@end
#pragma mark - 
@interface FormDataRequest : ASIFormDataRequest

@property (nonatomic, retain) __block NSString*  md5Hash; // 用于标识符

/**
 * 只是生成了一个请求,没有发送,只有添加到队列后才发送。
 * @param url 访问api
 * @param params  请求参数
 * @param delegate 委托
 * @param finishedSelector 成功的函数
 * @param failSelector 失败的函数
 */
+ (FormDataRequest*)requestNetURI:(NSString*)url
                           params:(NSDictionary*)params
                         delegate:(id)delegate
                 finishedSelector:(SEL)finishedSelector
                     failSelector:(SEL)failSelector
                    cacheSelector:(SEL)cacheSelector;

+ (FormDataRequest*)requestNetURI:(NSString*)url
                           params:(NSDictionary*)params
                         delegate:(id)delegate
                 finishedSelector:(SEL)finishedSelector
                     failSelector:(SEL)failSelector;

+ (NSString*)MD5HashWithParams:(NSDictionary*)params;

@end


/**
 * api接口method
 */
//获取token
NSString* tokenMethod();
//获取app信息
NSString* appInfo();
//获取子分类
NSString* sonSortList();
//获取分类中 内容列表
NSString* listByType();
//获取详细内容
NSString* contentInfo();
// 图片地址
NSString* imageURI();
// 申请宜码
NSString* addApplyMethod();
// 反聩
NSString* addComment();
// 教练
NSString* teacherList();
// 课程显示课表
NSString* scheduleByCourse();
// 教练显示课表
NSString* scheduleByTeacher();
// 场馆显示课表
NSString* scheduleByVenue();
// 时间显示课表
NSString* scheduleByWeekday();


