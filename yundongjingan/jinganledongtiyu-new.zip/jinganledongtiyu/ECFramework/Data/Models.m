//
//  Models.m
//  DeliciousCake
//
//  Created by Alix on 12/3/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "Models.h"


#pragma mark - 子分类 listitem

@implementation SonListItem
@end

@implementation SonList

+ (Class)SonSorList_class{
    return [SonListItem class];
}
@end

#pragma mark - 评论
@implementation CommentItem
@end

#pragma mark - 通用listitem
@implementation TypeListItem
@end

@implementation TypeList

+ (Class)ListByType_class{
    return [TypeListItem class];
}

@end

#pragma mark - 优惠
@implementation PrivilegeDetailItem

+ (Class)commentList_class{
    return [CommentItem class];
}
@end


@implementation PrivilegeDetailLink
@end


#pragma mark - 图说

@implementation ImageDetailItem
+(Class)imgList_class{
    return [ImageDetailItem class];
}
@end

@implementation ImageDetailLink
@end


#pragma mark - 场地
@implementation StoreDetailItem
@end

@implementation StoreDetailLink
@end

#pragma mark - 教练
@implementation Teacher
@end

@implementation TeacherLink
@end

#pragma mark - 课程
@implementation Course : Jastor
@end

@implementation CourseLink : Jastor
@end


#pragma maek - 课表
@implementation ClassScheduel 

@end

@implementation ListClassScheduel
+ (Class)schedulelist_class{
    return [ClassScheduel class];
}
@end
#pragma mark - AppInfo
@implementation AppInfo
@end