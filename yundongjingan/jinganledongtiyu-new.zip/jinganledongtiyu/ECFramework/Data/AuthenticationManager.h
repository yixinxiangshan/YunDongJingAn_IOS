//
//  AuthenticationManager.h
//  jinganledongtiyu
//
//  Created by cheng on 13-11-18.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Authentication;

#define AUTHENTICATION @"authentication"
#define AUTHENTICATIONSTATUS @[@"未邦定",@"已邦定",@"正在审核",@"正在更新信息"]

@interface AuthenticationManager : NSObject
@property (strong,nonatomic) NSMutableArray* authentications;

+ (id) shareInstance;

- (Authentication *) queryAuthenticationWithType:(NSString *)authenticationType;

- (void) updateAuthentication;

- (void) deleteAuthentication;

/**
 *  根据认证类型查询是否已认证
 */
+ (BOOL) queryAuthenticateStatusWithType:(NSString *)authenticationType;
@end

@interface Authentication : NSObject
/**
 *      {
 * "char_value_0" = 1234570;
 * "char_value_1" = "\U662f\U6cd5\U56fd";
 * "char_value_2" = "<null>";
 * "char_value_3" = "<null>";
 * "char_value_4" = "<null>";
 * id = 44;
 * "img_0" =             {
 * url = "/uploads/user_sort_info/img_0/44/3006153.png";
 * };
 * "img_0_file" = "3006153.png";
 * "img_1" =             {
 * url = "<null>";
 * };
 * "img_1_file" = "<null>";
 * "img_2" =             {
 * url = "<null>";
 * };
 * "img_2_file" = "<null>";
 * "img_3" =             {
 * url = "<null>";
 * };
 *  "img_3_file" = "<null>";
 * "img_4" =             {
 * url = "<null>";
 * };
 * "project_info_id" = 78;
 * "sort_type" = "id_card_number";
 * "user_info_id" = 30423;
 * "user_sort_type_id" = 4;
 * "valid_status" = 2;
 * }
 */


/**
 *  邦定状态    authenticationType
 *  未邦定         0
 *  已邦定         1
 *  正在验正         2
 *  正在更新信息    3
 */
@property (nonatomic, getter = getAuthenticationType) NSString* authenticationType;
@property (nonatomic, getter = getStatus) NSInteger status;
@property (nonatomic, strong) NSDictionary* instance;
+ (id) initWithDic:(NSDictionary *)dic;

- (id) objectForKey:(NSString *)key;

/**
 *  序列化为 NSString
 */
- (NSString *) getInitializedString;
/**
 *  由序列化的 NSString 生成实列
 */
+ (Authentication *) initFromInitializedString:(NSString *)initializedString;
@end
