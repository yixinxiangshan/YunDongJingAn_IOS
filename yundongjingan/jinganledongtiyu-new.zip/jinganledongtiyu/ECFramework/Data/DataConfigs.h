//
//  NetConfigs.h
//  HealthyClub
//
//  Created by EC on 1/24/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#ifndef HealthyClub_NetConfigs_h
#define HealthyClub_NetConfigs_h
#import "ECKeyChain.h"
#import "ECJsonParser.h"
#import "ECNetRequest.h"
#import "ECSpecRequest.h"
#import "ECWebImageDownloader.h"
#import "Models.h"
#import "Caches.h"
#import "CoreData.h"
#import "ECCoreDataSupport.h"


#define API_VERSION     @"1.0"

//#define API_KEY         @"df1f0ade70336fa382f02241db3d4a99"
//#define CLIENT_SECRET   @"ba776556632aa28ac7a3792938b3b5dd"

#define API_KEY         @"c7871624c24b756de846c377f4cacea5"
#define CLIENT_SECRET   @"ac72368dee715a7e347f02f3263b59c5"

// token uri
#define TOKEN_URL       @"http://856854472.cloudapi.nowapp.cn/oauth/token/"
// 
#define API_URL         @"http://856854472.cloudapi.nowapp.cn/api/"


// @"api.nowapp.cn/api/" 192.168.100.182:10002
#endif

//合作商户ID。用签约支付宝账号登录ms.alipay.com后，在账户信息页面获取。
#define PartnerID @"2088901143035956"
//账户ID。用签约支付宝账号登录www.alipay.com后，在商家服务页面中获取。
#define SellerID  @"ecloudiot@ecloudiot.com"

//安全校验码（MD5）密钥  用签约支付宝账号登录www.alipay.com后，在商家服务页面中获取。
#define MD5_KEY @"nzotpw4538zryn3vd1mr1fwhkk71x7nw"

//商户私钥，自助生成
#define PartnerPrivKey @"MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBALufpKfS0coo6IRblsaG4G1mawYYGC+UVpSrGA23HwJ87bv/dgHKOexZCvb8gjyxH2x/BCue9ng8TigXH0lrkHSRq5sXxHN2S4k8PebOaDCNWi3NA5SOsonx8LKoM9bQ4NAfUi0IwpI3cvvKWyVoYaE1v73RwEV5yLy6nSoZQN8PAgMBAAECgYA6Hb0W7spk4D8FoIkXfXfO60aDYLs9Iamf609MEEjesGvDK+IVs9o1R2+KCbUdr4+YP8++40JdA/EBogfi6hqYOMJ4zCzmD4hTIWd1p7xgrLRFG1kfXwNNiirMAakLX55c+b3aJpA/RKf03EQ+whBFvgwe5ncSgTwOYIgqSimhYQJBAO1h6N26rBwpVkeq+f59ZQ2zMmaiVWtk+7ZGUPfK/9Yil039beCNwLpLvX5JDf+H3PCiwBnOQd6/gL8rq1MbFeUCQQDKVrDhva6UNtjkZj59d5O+vrfPhrEWdOT6IqldA2+DBOK1pwVrXdspoP6VmmbUJ+fnd4ZjLPhaVdzWsEL4I1HjAkBSgwHqcIR6lXPEHY4gA34osO0H980xMzy7Mt3aA9nBmOx202xp7VvcZY9MYiBXfeYyTp/vWF5VCsO5r3gxvuxxAkANJJ5uu2R4qitigqWyfq7xJ/BGoaglHki1WsUHjq6SoyGazROUCs+un4+J5jKhu0ncBi6LiKNFMuiaZW6kMZ8jAkBfjh6zjVqbDBQB6MQ3SbI5///a8C4MDTbDd0RgaFGdosqikI2L9az/+OJBJ9NXqhR4S0kcVAv4y0EMr/nir+pD"

//支付宝公钥
#define AlipayPubKey   @"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCKCl3wQPnvFdXzQ9rx7umOd96ZOSXJqc2yOZTxm+p75HdlTCTkAJgu2xfBYgLAF0e/oT850Jz7uh/hQHQcEoLxZzNCghaZzjrTfLqR8473r0B3wC/VnnsVFUi0IqHDuNLnq+xa3S0Sq4T5GJQGFcBVqG+maLC2otQAlDm2tLQtpwIDAQAB"
//                           MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCKCl3wQPnvFdXzQ9rx7umOd96ZOSXJqc2yOZTx m+p75HdlTCTkAJgu2xfBYgLAF0e/oT850Jz7uh/hQHQcEoLxZzNCghaZzjrTfLqR8473r0B3wC/V nnsVFUi0IqHDuNLnq+xa3S0Sq4T5GJQGFcBVqG+maLC2otQAlDm2tLQtpwIDAQAB


//#define AlipayPubKey     @"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC7n6Sn0tHKKOiEW5bGhuBtZmsG GBgvlFaUqxgNtx8CfO27/3YByjnsWQr2/II8sR9sfwQrnvZ4PE4oFx9Ja5B0kaub F8RzdkuJPD3mzmgwjVotzQOUjrKJ8fCyqDPW0ODQH1ItCMKSN3L7ylslaGGhNb+9 0cBFeci8up0qGUDfDwIDAQAB"


#define NotifyUrl @"http://phpalipay.nowapp.cn/notify_url.php"
#define AppScheme @"yundongjingan0001"

//MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC7n6Sn0tHKKOiEW5bGhuBtZmsG
//GBgvlFaUqxgNtx8CfO27/3YByjnsWQr2/II8sR9sfwQrnvZ4PE4oFx9Ja5B0kaub
//F8RzdkuJPD3mzmgwjVotzQOUjrKJ8fCyqDPW0ODQH1ItCMKSN3L7ylslaGGhNb+9
//0cBFeci8up0qGUDfDwIDAQAB