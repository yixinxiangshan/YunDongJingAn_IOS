//
//  AuthenticationManager.m
//  jinganledongtiyu
//
//  Created by cheng on 13-11-18.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "AuthenticationManager.h"
#import "NSStringExtends.h"
#import "ECCMController.h"
#import "ECEventRouter.h"
#import "ECPopViewUtil.h"

@implementation AuthenticationManager

+ (id) shareInstance
{
    static AuthenticationManager* manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[AuthenticationManager alloc] init];
        // 注册监听
        [[NSNotificationCenter defaultCenter] addObserver:manager selector:@selector(updateAuthentication) name:@"ECLoginController.loginSuccess" object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:manager selector:@selector(deleteAuthentication) name:@"logoutCmd.logoutSuccess" object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:manager selector:@selector(updateAuthentication) name:@"ECAuthenticateView.submitSuccess" object:nil];
    });
    return manager;
}

- (Authentication *) queryAuthenticationWithType:(NSString *)authenticationType
{
    if (!_authentications) {
        _authentications = [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:AUTHENTICATION]];
    }
    
    for (NSString* item in self.authentications) {
        Authentication* authentication = [Authentication initFromInitializedString:item];  //根据序列化的 用户验证信息，生成用户验证对像
        if ([authentication.authenticationType isEqualToString:authenticationType]) {
            
            return authentication;
        }
    }
    return nil;
}

+ (BOOL) queryAuthenticateStatusWithType:(NSString *)authenticationType
{
    //查询是否已经登录
    if (![[ECCMController shareInstance] hadLogin]) {
        [[ECEventRouter shareInstance] doAction:@"ecct://login?configName=ECLoginConfig"];
        [ECPopViewUtil toast:@"请登录！"];
        return NO;
    }
    
    NSInteger status = [[[self class] shareInstance] queryAuthenticationWithType:authenticationType].status;
    if (status == 0) {
        [[ECEventRouter shareInstance] doAction:@"ecct://sectionview?configName=ECAuthenticateConfig" userInfo:@{@"navTitle":@"身份验证"}];
        [ECPopViewUtil toast:@"请认证!"];
        return NO;
    }
    
    if (status == 2) {
        [ECPopViewUtil toast:@"您的身份证尚未通过，请耐心等待。" position:@"center"];
        return NO;
    }
    return YES;
}

- (void) updateAuthentication
{
    NSLog(@"ECLoginController.loginSuccess , updateAuthentication");
    
    NSDictionary* params = @{@"method":@"user/users/bind_status",@"apiversion":@"1.0"};
    
    NSString* notiName = [NSString randomString:0.5 maxLength:30 minLength:20];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didReceivedAuthenticationData:) name:[NSString stringWithFormat:@"%@.%@",notiName,ECCMNETREQUEST_SUCCESSED] object:nil];
    
    [ECCMController requestWithParams:params successedMessage:NO_SUCCESSALERT_MSSAGE faildMessage:NO_SUCCESSALERT_MSSAGE isNeedLogin:NO notiName:notiName];
}
- (void) didReceivedAuthenticationData:(NSNotification *)noti
{
    NSLog(@"Authentication data : %@",noti.userInfo);
    [self.authentications removeAllObjects];
    
    NSArray* data = [noti.userInfo objectForKey:@"sorts"];
    for (NSDictionary* item in data) {
        
        Authentication* authentication = [Authentication initWithDic:item];
        [self.authentications addObject:[authentication getInitializedString]];
    }
    
    [self saveAuthentication];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"AuthenticationManager.didUpdateAuthentication" object:nil userInfo:nil];
}

- (void) saveAuthentication
{
    [[NSUserDefaults standardUserDefaults] setObject:self.authentications forKey:AUTHENTICATION];
}
- (void) deleteAuthentication
{
    NSLog(@"logoutCmd.logoutSuccess : deleteAuthentication");
    [_authentications removeAllObjects];
    [self saveAuthentication];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"AuthenticationManager.didUpdateAuthentication" object:nil userInfo:nil];
}
@end

@implementation Authentication

+ (id) initWithDic:(NSDictionary *)dic
{
    Authentication* authentication = [[Authentication alloc] init];
    authentication.instance = [NSDictionary dictionaryWithDictionary:dic];
    
    return authentication;
}
- (id) objectForKey:(NSString *)key
{
    return [self.instance objectForKey:key];
}

- (NSString *) getAuthenticationType
{
    return [self objectForKey:@"sort_type"];
}

- (NSInteger) getStatus
{
    return [[self objectForKey:@"valid_status"] integerValue];
}

- (NSString *) getInitializedString
{
    return [ECJsonParser stringWithDic:self.instance];
}

+ (Authentication *) initFromInitializedString:(NSString *)initializedString
{
    Authentication* authentication = [[Authentication alloc] init];
    authentication.instance = [ECJsonParser objectWithJsonString:initializedString];
    return authentication;
}
@end
