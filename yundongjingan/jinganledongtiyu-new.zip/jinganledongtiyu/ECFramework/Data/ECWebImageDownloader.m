//
//  ECWebImageDownloader.m
//  ECMuse
//
//  Created by Alix on 10/22/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import "ECWebImageDownloader.h"
#import "SDImageCache.h"
#import "Extends.h"
/**
 * 照片地址必须是http... 格式的 
 */
@implementation ECWebImageDownloader
#pragma mark - 单例
+ (id)sharedInstance{
    static ECWebImageDownloader* obj = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        obj = [[self alloc] init];
    });
    return obj;
}
#pragma mark - 下载图片
-(void)downloadImageWithURI:(NSString*)uri{
    if (nil == uri || [uri isMemberOfClass:[NSNull class]] || NO == [uri hasPrefix:@"http"]) {
        return;
    }
    [self downloadImageWithURL:[NSURL URLWithString:[uri stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
}
-(void)downloadImageWithURL:(NSURL*)url{
    if (nil == url || [url isMemberOfClass:[NSNull class]] || NO == [[url absoluteString] hasPrefix:@"http"]) {
        return;
    }
    SDWebImageManager* manager = [SDWebImageManager sharedManager];
    UIImage* cachedImage = [manager imageWithURL:url];
    if (nil != cachedImage) {
    } else {
        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
        [manager downloadWithURL:url delegate:self];
    }
}
#pragma mark - 获取图片
-(UIImage*)getImageWithURI:(NSString*)uri{
    if (nil == uri || [uri isMemberOfClass:[NSNull class]] || NO == [uri hasPrefix:@"http"]) {
        return nil;
    }
    return [self getImageWithURL:[NSURL URLWithString:[uri stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
}
-(UIImage*)getImageWithURL:(NSURL*)url{
    if (nil == url || [url isMemberOfClass:[NSNull class]] || NO == [[url absoluteString] hasPrefix:@"http"]) {
        return nil;
    }
    SDWebImageManager* manager = [SDWebImageManager sharedManager];
    UIImage* cachedImage = [manager imageWithURL:url];
    if (nil != cachedImage) {
        return cachedImage;
    }
    // 未找到图片就开始下载,返回空
    [self downloadImageWithURL:url];
    return nil;
}
#pragma mark - 清除图片
-(void)removeImageWithURI:(NSString*)uri{
    if (nil == uri || [uri isMemberOfClass:[NSNull class]] || NO == [uri hasPrefix:@"http"]) {
        return;
    }
    [self removeImageWithURL:[NSURL URLWithString:[uri stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
}
-(void)removeImageWithURL:(NSURL*)url{
    if (nil == url || [url isMemberOfClass:[NSNull class]] || NO == [[url absoluteString] hasPrefix:@"http"]) {
        return;
    }
    SDImageCache* cache = [SDImageCache sharedImageCache];
    [cache removeImageForKey:[url absoluteString]];
}
-(void)removeAllImages{
    SDImageCache* cache = [SDImageCache sharedImageCache];
    [cache cleanDisk];
}
- (BOOL)clearAllImages{
    return [[SDImageCache sharedImageCache] clearDisk];
}
#pragma mark - 图片下载委托
- (void)webImageManager:(SDWebImageManager *)imageManager didFinishWithImage:(UIImage *)image{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}
- (void)webImageManager:(SDWebImageManager *)imageManager didFailWithError:(NSError *)error{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}
@end
