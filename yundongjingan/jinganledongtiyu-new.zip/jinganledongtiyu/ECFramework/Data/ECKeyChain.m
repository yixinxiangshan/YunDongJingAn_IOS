//
//  ECKeyChain.m
//  QCRL_NEW
//
//  Created by Guanglu Kang on 8/20/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "ECKeyChain.h"
// 参考地址 http://blog.csdn.net/bl1988530/article/details/6887946

static NSString* KEY_KEYCHAIN = @"com.ecloudiot.iosapplication.healthyclub.keychain";
static NSString* KEY_USERNAME = @"com.ecloudiot.iosapplication.healthyclub.username";  
static NSString* KEY_PASSWORD = @"com.ecloudiot.iosapplication.healthyclub.passwd";
static NSString* KEY_DEVICE_UUID = @"com.ecloudiot.iosapplication.healthyclub.deviceudid";
static NSString* KEY_ACCESS_TOKEN = @"com.ecloudiot.iosapplication.healthyclub.accesstoken";
static NSString* KEY_ENTERPRISE_ID = @"com.ecloudiot.iosapplication.healthyclub.enterpriseid";
static NSString* KEY_APIKEY = @"com.ecloudiot.iosapplication.healthyclub.apikey";
static NSString* KEY_CLIENTSECRET = @"com.ecloudiot.iosapplication.healthyclub.clientSecret";


@interface ECKeyChain ()
/**
 * 保存
 */
+ (void)save:(NSString *)service data:(id)data;  

/**
 * 加载
 */
+ (id)load:(NSString *)service;  

/**
 * 删除
 */
+ (void)delete:(NSString *)service; 

@end


@implementation ECKeyChain

#pragma mark- use KeyChain

//+ (NSMutableDictionary *)getKeychainQuery:(NSString *)service {  
//return [NSMutableDictionary dictionaryWithObjectsAndKeys:  
//        (id)kSecClassGenericPassword,(id)kSecClass,
//        service, (id)kSecAttrService,  
//        service, (id)kSecAttrAccount,  
//        (id)kSecAttrAccessibleAfterFirstUnlock,(id)kSecAttrAccessible,  
//        nil];  
//}  
//
//+ (void)save:(NSString *)service data:(id)data {  
//    //Get search dictionary  
//    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service];  
//    //Delete old item before add new item  
//    SecItemDelete((CFDictionaryRef)keychainQuery);  
//    //Add new object to search dictionary(Attention:the data format)  
//    [keychainQuery setObject:[NSKeyedArchiver archivedDataWithRootObject:data] forKey:(id)kSecValueData];  
//    //Add item to keychain with the search dictionary  
//    SecItemAdd((CFDictionaryRef)keychainQuery, NULL);  
//}  
//
//+ (id)load:(NSString *)service {  
//    id ret = nil;  
//    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service];  
//    //Configure the search setting  
//    //Since in our simple case we are expecting only a single attribute to be returned (the password) we can set the attribute kSecReturnData to kCFBooleanTrue  
//    [keychainQuery setObject:(id)kCFBooleanTrue forKey:(id)kSecReturnData];  
//    [keychainQuery setObject:(id)kSecMatchLimitOne forKey:(id)kSecMatchLimit];  
//    CFDataRef keyData = NULL;  
//    if (SecItemCopyMatching((CFDictionaryRef)keychainQuery, (CFTypeRef *)&keyData) == noErr) {  
//        @try {  
//            ret = [NSKeyedUnarchiver unarchiveObjectWithData:(NSData *)keyData];  
//        } @catch (NSException *e) {  
//        } @finally {
//            
//        }  
//    }  
//    if (keyData)   
//        CFRelease(keyData);  
//    return ret;  
//}  
//
//+ (void)delete:(NSString *)service {  
//    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service];  
//    SecItemDelete((CFDictionaryRef)keychainQuery);  
//}

#pragma mark- use userDefault
+ (NSMutableDictionary *)getKeychainQuery:(NSString *)service {
    return [[NSUserDefaults standardUserDefaults] objectForKey:service];
}

+ (void)save:(NSString *)service data:(id)data {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:service];
    [[NSUserDefaults standardUserDefaults] setObject:data forKey:service];
}

+ (id)load:(NSString *)service {
    return [[NSUserDefaults standardUserDefaults] objectForKey:service];
}

+ (void)delete:(NSString *)service {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:service];
}

#pragma mark -
+ (void)saveUserName:(NSString*)userName
            password:(NSString*)passwd
            deviceID:(NSString*)udid
         accessToken:(NSString*)token{
    NSMutableDictionary *KVPairs = [NSMutableDictionary dictionary];
    if (userName && userName.length) {
        [KVPairs setObject:userName forKey:KEY_USERNAME];  
    }
    if (passwd && passwd.length) {
        [KVPairs setObject:passwd forKey:KEY_PASSWORD];
    }
    if (udid && udid.length) {
        [KVPairs setObject:udid forKey:KEY_DEVICE_UUID];
    }
    if (token && token.length) {
        [KVPairs setObject:token forKey:KEY_ACCESS_TOKEN];
    }
    [self save:KEY_KEYCHAIN data:KVPairs];
}

+(NSString*)userName{
    NSMutableDictionary *usernamepasswordKVPairs = (NSMutableDictionary *)[self load:KEY_KEYCHAIN];  
    return  [usernamepasswordKVPairs objectForKey:KEY_USERNAME];  
}
+(NSString*)password{
    NSMutableDictionary *usernamepasswordKVPairs = (NSMutableDictionary *)[self load:KEY_KEYCHAIN];  
    return [usernamepasswordKVPairs objectForKey:KEY_PASSWORD];
}
+(NSString*)deviceUDID{
    NSMutableDictionary *usernamepasswordKVPairs = (NSMutableDictionary *)[self load:KEY_KEYCHAIN];
    NSString* udid =  [usernamepasswordKVPairs objectForKey:KEY_DEVICE_UUID];
    return udid;
}
+(NSString*)accessToken{
    NSMutableDictionary *usernamepasswordKVPairs = (NSMutableDictionary *)[self load:KEY_KEYCHAIN];
    return [usernamepasswordKVPairs objectForKey:KEY_ACCESS_TOKEN];
}
+(void)deleteUsernameAndPasswd{
    [self delete:KEY_KEYCHAIN]; 
}
#pragma mark - 企业编号
+(void)saveEnterpriseId:(NSString*)enterpriseId{
    NSMutableDictionary *KVPairs = [NSMutableDictionary dictionary];
    if (enterpriseId && enterpriseId.length) {
        [KVPairs setObject:enterpriseId forKey:KEY_ENTERPRISE_ID];
    }
    [self save:KEY_ENTERPRISE_ID data:KVPairs];
}

+(NSString*)enterpriseId{
    NSMutableDictionary *usernamepasswordKVPairs = (NSMutableDictionary *)[self load:KEY_ENTERPRISE_ID];
    return [usernamepasswordKVPairs objectForKey:KEY_ENTERPRISE_ID];
}
#pragma mark - apiKey
+(void)saveApiKey:(NSString*)apiKey{
    NSMutableDictionary *KVPairs = [NSMutableDictionary dictionary];
    if (apiKey && apiKey.length) {
        [KVPairs setObject:apiKey forKey:KEY_APIKEY];
    }
    [self save:KEY_APIKEY data:KVPairs];
}

+(NSString*)apiKey{
    NSMutableDictionary *KVPairs = (NSMutableDictionary *)[self load:KEY_APIKEY];
    return [KVPairs objectForKey:KEY_APIKEY];
}
#pragma mark - clientSecret
+(void)saveClientSecret:(NSString*)clientSecret{
    NSMutableDictionary *KVPairs = [NSMutableDictionary dictionary];
    if (clientSecret && clientSecret.length) {
        [KVPairs setObject:clientSecret forKey:KEY_CLIENTSECRET];
    }
    [self save:KEY_CLIENTSECRET data:KVPairs];
}

+(NSString*)clientSecret{
    NSMutableDictionary *KVPairs = (NSMutableDictionary *)[self load:KEY_CLIENTSECRET];
    return [KVPairs objectForKey:KEY_CLIENTSECRET];
}

@end  