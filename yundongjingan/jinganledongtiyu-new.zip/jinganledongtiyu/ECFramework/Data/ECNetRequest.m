//
//  ECNetRequest.m
//  ECMuse
//
//  Created by Alix on 10/23/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import "ECNetRequest.h"
#import "Extends.h"
#import "Reachability.h"
#import "CoreData.h"
#import <objc/runtime.h>
#import <objc/message.h>
#import "Utils.h"



#pragma mark - 网络请求管理
@implementation NetRequestManager
#pragma mark - 单例
+(id)sharedInstances{
    static NetRequestManager* object = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        object = [self new];
    });
    return object;
}
#pragma mark -
-(id)init{
    self = [super init];
    if (self) {
        _operationQueue = [ASINetworkQueue new];
        _operationQueue.maxConcurrentOperationCount = 1;
        [_operationQueue go];
        return self;
    }
    return nil;
}
#pragma mark -
-(void)dealloc{
    [_operationQueue cancelAllOperations];
     _operationQueue = nil;
//    [super dealloc];
}
#pragma mark - 添加一个请求
- (void)addOperation:(NSOperation*)_operation{
    if ([_operation isMemberOfClass:[FormDataRequest class]]) {
        FormDataRequest* operation = (FormDataRequest*)_operation;
        if (nil == [self operationWithGUID:operation.md5Hash]) {
            [_operationQueue addOperation:_operation];
        }
    }
}

#pragma mark - 获取某一个operation
- (FormDataRequest*)operationWithGUID:(NSString*)_guid{
    for (NSOperation* operation in [_operationQueue operations]) {
        if ([operation isMemberOfClass:[FormDataRequest class]]) {
            if ([[(FormDataRequest*)operation md5Hash] isEqualToString:_guid]) {
                return (FormDataRequest*)operation;
            }
        }
    
    }
    return nil;
}
#pragma mark - 取消一个请求
- (void)cancelOperationWithGUID:(NSString*)_guid{
    for (NSOperation* operation in [_operationQueue operations]) {
        if ([operation isMemberOfClass:[FormDataRequest class]]) {
            if ([[(FormDataRequest*)operation md5Hash] isEqualToString:_guid]) {
                [operation cancel];
            }
        }
        
    }
}
/**
 * 取消某个请求
 */
- (void)cancelOperationsWithDelegate:(id)delegate{
    for (NSOperation* operation in [_operationQueue operations]) {
        if ([operation isMemberOfClass:[FormDataRequest class]]) {
            if ([[(FormDataRequest*)operation delegate] isEqual:delegate]) {
                [operation cancel];
            }
        }
        
    }
}
#pragma mark - 取消所有请求
- (void)cancelAllOperationsAndNotClean{
    [_operationQueue cancelAllOperations];
}

#pragma mark - 是否有网络联接
+(BOOL)networdEnabled{
    return [[Reachability reachabilityForInternetConnection] currentReachabilityStatus] != kNotReachable;
}
+(BOOL)netEnabledWithWifi{
    return [[Reachability reachabilityForInternetConnection] currentReachabilityStatus] == kReachableViaWiFi;
}
#pragma mark - 可联网,但是在3G/E网的情况
+(BOOL)networdEnabledWithWWAN{
    return kReachableViaWWAN == [[Reachability reachabilityForInternetConnection] currentReachabilityStatus];
}
@end


#pragma mark -
@implementation FormDataRequest
@synthesize md5Hash = _md5Hash;

#pragma mark -
-(void)dealloc{
    _md5Hash = nil;
//    [super dealloc];
}
#pragma mark - 网络请求
+ (FormDataRequest*)requestNetURI:(NSString*)url
                           params:(NSDictionary*)params
                         delegate:(id)delegate
                 finishedSelector:(SEL)finishedSelector
                     failSelector:(SEL)failSelector
                    cacheSelector:(SEL)cacheSelector
{

    
    BOOL needCache = NO;
    if (nil != cacheSelector && ![[params objectForKey:@"method"] isEqualToString:@"token"]) {
        needCache = YES;
        NSData* data = [[ECCoreDataSupport sharedInstance]
                        cachesWithMd5Hash:[self MD5HashWithParams:params]];
        if (data && [data length]) {
            ECLog(@"read data from  caches files");
            if (delegate && cacheSelector && [delegate respondsToSelector:cacheSelector]) {
                objc_msgSend(delegate, cacheSelector,data);
            }
            return nil;
        }
    }
    
    NSDictionary* terminalParams = [params newParams];
    if (nil==terminalParams) {
        return nil;
    }
//    ECLog(@"request params:%@", [terminalParams description]);
    
    ECLog(@"request params : %@",terminalParams);
    url = [NSString stringWithFormat:@"%@%@/%@",url,[terminalParams objectForKey:@"apiversion"],[terminalParams objectForKey:@"method"]];
    ECLog(@"ECNetRequest %@",url);
    
    FormDataRequest* requestForm =[[FormDataRequest alloc] init];
    requestForm = [FormDataRequest requestWithURL:[NSURL URLWithString:url]];        

    [requestForm setDefaultResponseEncoding:NSUTF8StringEncoding];
	[requestForm setTimeOutSeconds:120];
    [requestForm setRequestMethod:@"POST"];
	[requestForm addRequestHeader:@"Content-Type" value:@"application/x-www-form-urlencoded; charset=UTF-8;"];
                              
    NSString* paramsString = [terminalParams toHtmlBody];
    NSMutableData* postData = [NSMutableData dataWithData:[paramsString dataUsingEncoding:NSUTF8StringEncoding]];
    [requestForm appendPostData:postData];
    [requestForm setMd5Hash:[self MD5HashWithParams:params]];
    [requestForm setDidFailSelector:failSelector];
    [requestForm setDidFinishSelector:finishedSelector];
	[requestForm setDelegate:delegate];
    
    //请求完成调用块
    __weak FormDataRequest *weakRequestForm = requestForm;
    [requestForm setCompletionBlock:^{
        NSString* requestSuccessString = nil;
        requestSuccessString =[weakRequestForm responseString];
        if ([requestSuccessString rangeOfString:@"\"error\""].location == NSNotFound
            && [requestSuccessString rangeOfString:@"\"Error\""].location == NSNotFound && [requestSuccessString rangeOfString:@"\"error_num\""].location == NSNotFound) {
            if (nil!=requestSuccessString && needCache) {
//                ECLog(@"setCompletionBlock 保存数据：%@",requestSuccessString);
                ECLog(@"setCompletionBlock 保存数据");
                [[ECCoreDataSupport sharedInstance] saveCachesWithData:[weakRequestForm responseData]
                                                               md5Hash:[weakRequestForm md5Hash]];
            }
        }
        
    }];
    
    
    return requestForm;
}
+ (FormDataRequest*)requestNetURI:(NSString*)url
                           params:(NSDictionary*)params
                         delegate:(id)delegate
                 finishedSelector:(SEL)finishedSelector
                     failSelector:(SEL)failSelector{
    return  [FormDataRequest requestNetURI:url
                                    params:params
                                  delegate:delegate
                          finishedSelector:finishedSelector
                              failSelector:failSelector
                             cacheSelector:nil];
}


// 根据网络请求参数，生成该请求md5Hash,格式：callId=call_id&method=method&sortId=sortid&lastId=lastId
+ (NSString*)MD5HashWithParams:(NSDictionary*)params{
    NSString* sortId = @"";
    NSString* lastId = @"";
    NSString* orderbyname = @"";
    //获取访问api的id值
    if (nil!=[params objectForKey:@"sortid"]) {
        sortId = [params objectForKey:@"sortid"];
    }
    else if (nil!= [params objectForKey:@"contentid"]){
        sortId = [params objectForKey:@"contentid"];
    }else if(nil!= [params objectForKey:@"conditionValue"]){
        sortId =[params objectForKey:@"conditionValue"];
    }
    
    //获取访问api的lastid值
    if(nil!=[params objectForKey:@"lastid"]){
        lastId = [params objectForKey:@"lastid"];
    }
    if(nil!=[params objectForKey:@"orderbyname"]){
        orderbyname = [params objectForKey:@"orderbyname"];
    }
    
    if (nil != params) {
        NSString* tempString = [NSString stringWithFormat:@"callId=%@&method=%@&sortId=%@&lastId=%@orderbyname=%@&params=%@",[params objectForKey:@"call_id"],[params objectForKey:@"method"],sortId,lastId,orderbyname,params];
        return [tempString md5Hash];
    }
    return nil;
}

@end

#pragma mark - 根据request params 获取 MD5hash 

@interface NSString (request)
/**
 * 缓存中的md5Hash值
 */
+(NSString*)requestHashMD5WithPostParams:(NSDictionary*)dict;
@end

@implementation NSString (request)

+(NSString*)requestHashMD5WithPostParams:(NSDictionary*)dict{
    if (dict) {
        
    }
    return nil;
}

@end


#pragma mark - api接口method
//获取token
NSString* tokenMethod(){
    return @"token";
}
//获取app信息
NSString* appInfo(){
    return @"project.getappinfo";
}

//获取子分类
NSString* sonSortList(){
    return @"content.getsonsortlist";
}
//获取分类中 内容列表
NSString* listByType(){
    return @"content.getlistbytype";
}
//获取详细内容
NSString* contentInfo(){
    return @"content.getcontentinfo";
}
// 图片地址
NSString* imageURI(){
    return @"http://is.hudongka.com/";
}
// 申请宜码
NSString* addApplyMethod(){
    return @"activity.applycoupon";
}
// 反聩
NSString* addComment(){
    return @"comment/comments/create";
}
// 教练
NSString* teacherList(){
    return @"activity.getteacherlist";
}
// 课程显示课表
NSString* scheduleByCourse(){
    return @"activity.getschedulebycourse";
}
// 教练显示课表
NSString* scheduleByTeacher(){
    return @"activity.getschedulebyteacher";
}
// 场馆显示课表
NSString* scheduleByVenue(){
    return @"activity.getschedulebyvenue";
}
// 时间显示课表
NSString* scheduleByWeekday(){
    return @"activity.getschedulebyweekday";
}



