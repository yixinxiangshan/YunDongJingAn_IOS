//
//  ECDetailViewController.h
//  DemoECEcloud
//
//  Created by EC on 3/13/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECBaseViewController.h"
#import "ECDetail.h"

@interface ECDetailViewController : ECBaseViewController <ECDetailDelegate>

@property (nonatomic, strong) NSDictionary* dataDic;
@property (nonatomic, strong) NSString* dataKey;

@property (nonatomic, strong) NSMutableArray* subViews;
- (void) layoutSubViews;

- (void) netRequest;
@end
