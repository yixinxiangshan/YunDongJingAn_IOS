//
//  BaseListViewController.h
//  DemoECEcloud
//
//  Created by EC on 3/4/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECBaseViewController.h"
#import "PullingRefreshTableView.h"

@interface ECBaseListViewController : ECBaseViewController <UITableViewDelegate,UITableViewDataSource>


@property (nonatomic, strong) NSString* requestId;
@property (nonatomic, strong) NSString* method;
@property (nonatomic, strong) NSDictionary* cellConfig;
@property (nonatomic, strong) NSString* cellId;

@property (nonatomic, strong) UITableView* tableView;
@property (nonatomic, strong) NSMutableArray* dataSource;

@end
