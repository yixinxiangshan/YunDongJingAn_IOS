//
//  ECPullingTableViewController.m
//  DemoECEcloud
//
//  Created by EC on 3/4/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECPullingTableViewController.h"
#import "Utils.h"
#import "ECViews.h"
#import "Extends.h"

#define TAG "ECPullingTableViewController"


@interface ECPullingTableViewController ()

@end

@implementation ECPullingTableViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self showTableView];
    
	// Do any additional setup after loading the view.
    
    self.styles = [self.configs objectForKey:@"style"];
    self.cellId = [self.styles objectForKey:@"cellId"];
    _isNeedRefresh = YES;
    if (![[self.configs valueForKey:@"isNeedRefresh"] boolValue]) {
        _isNeedRefresh = NO;
    }
    if (nil != [self.configs objectForKey:@"isNeedRefresh"] && ![@"" isEqualToString:[self.configs objectForKey:@"isNeedRefresh"]]) {
        _isNeedRefresh = [(NSNumber*)[self.configs objectForKey:@"isNeedRefresh"] boolValue];
    }
    self.contentIdKey = [self.configs objectForKey:@"contentIdKey"];
    
    if (nil != [self.query objectForKey:@"title"]) {
        self.navigationItem.title = [self.query objectForKey:@"title"];
    }
    
    self.dataSource = [NSMutableArray new];
    [self requestData];
    
}

- (void)requestData{
    self.isLocalData = [(NSNumber*)[self.configs objectForKey:@"isLocalData"] boolValue];
    if (self.isLocalData == NO) {
        if (nil != [self.query objectForKey:@"requestId"] ) {
            self.requestId = [self.query objectForKey:@"requestId"];
        }
        //网络数据
        NSDictionary* netDataRelevant = [self.configs objectForKey:@"netDataRelevant"];
        if (nil != [netDataRelevant objectForKey:@"requestId"] && ![@"" isEqualToString:[netDataRelevant objectForKey:@"requestId"]]) {
            self.requestId = [netDataRelevant objectForKey:@"requestId"];
        }
        self.requestIdKey = [netDataRelevant objectForKey:@"requestIdKey"];
        
        self.method = [netDataRelevant objectForKey:@"method"];
        
        if (nil==self.method || [@"" isEqualToString:self.method]) {
            ECLog(@"%@ configs error: method is null!",NSStringFromClass([self class]));
        }
        [self initNetRequestParams];
        [self freshData:YES];
        
    }else{
        //本地数据
        self.dataSource = [[self.configs objectForKey:@"localData"] objectForKey:@"dataList"];
        if (nil == self.dataSource || self.dataSource.count<1) {
            ECLog(@"%@ configs error: loacaldata is null!",NSStringFromClass([self class]));
        }else{
            [self showTableView];
        }
        
    }

}

- (void)handleRequestData:(NSData*)data{
    [super handleRequestData:data];
   
    id tempData = nil;
    //处理数据
    id obj = [ECJsonParser objectWithJsonData:data];
    
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        tempData = [obj valueForKey:@"data"];
    }
    if (tempData && [tempData isNSxxxClass:[NSDictionary class]]) {
        
        id dataArray = [self getValue:tempData forKey:[self.configs objectForKey:@"listKey"]];
        NSLog(@"dataArray : %@",[dataArray class]);
        if (dataArray && [dataArray isKindOfClass:[NSArray class]]) {
            [self.dataSource removeAllObjects];
            [self.dataSource addObjectsFromArray:dataArray];
            
            //  R.oshan Label
            NSLog(@"%s  data has done , reloadData for View",TAG);
            NSLog(@"%s  data has done , reloadData for View  %@",TAG,self.tableView);
        }
    }else if (tempData && [tempData isKindOfClass:[NSArray class]])
    {
        id dataArray = tempData;
        if (dataArray && [dataArray isKindOfClass:[NSArray class]]) {
            [self.dataSource removeAllObjects];
            [self.dataSource addObjectsFromArray:dataArray];
            
            //  R.oshan Label
            NSLog(@"%s  data has done , reloadData for View",TAG);
            NSLog(@"%s  data has done , reloadData for View  %@",TAG,self.tableView);
        }

    }
    else{
        //TODO: 弹出数据出错！
    }
    [self.tableView reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return nil;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

#pragma mark -Pulling Refresh Table view delegate
// pull down to refresh
- (void)pullingTableViewDidStartRefreshing:(PullingRefreshTableView *)tableView{
//    _pullingtDirection = ePullingDirectionUp;
//    NSString* lastId = nil;
//    if (self.dataSource && self.dataSource.count > 0) {
//       lastId = [[self.dataSource objectAtIndex:0] objectForKey:self.contentIdKey];//获取现有数据中 最下面一条数据的id
//    }else{
//        lastId = @"0";
//    }
    [self initNetRequestParams];
    [self freshData:YES];
    [self.tableView tableViewDidFinishedLoading];
//    [self sendReqeustWithID:lastId];
}

//Implement this method if headerOnly is false,pull up to loading more
- (void)pullingTableViewDidStartLoading:(PullingRefreshTableView *)tableView{
    _pullingtDirection = ePullingDirectionBottom;
    NSString* lastId = nil;
    if (self.dataSource && self.dataSource.count > 0) {
        lastId = [[self.dataSource lastObject] objectForKey:self.contentIdKey];//获取现有数据中 最下面一条数据的id
    }else{
        lastId = @"0";
    }
    if (_isNeedRefresh) {
        [self sendReqeustWithID:lastId];
    }else{
        [self.tableView tableViewDidFinishedLoading];
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (self.isLocalData == NO ) {
        [_tableView tableViewDidScroll:scrollView];
    }
//&& [self.method isEqualToString:listByType()]
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    if (self.isLocalData == NO ) {
        [_tableView tableViewDidEndDragging:scrollView];
    }
//    && [self.method isEqualToString:listByType()]
}
#pragma mark -- 请求网络获取刷新 / 更多
- (void)sendReqeustWithID:(NSString *)ID{
    if (nil == ID || [ID isEmpty]) {
        return ;
//        [self requestData];
    }else{
        NSMutableDictionary* params = [NSMutableDictionary new];
        [params setObject:self.method forKey:@"method"];
        [params setObject:self.requestId forKey:self.requestIdKey];
        [params setValue:ID forKey:@"lastid"];
        [params setValue:@"id" forKey:@"orderbyname"];
        if (self.pullingtDirection == ePullingDirectionUp) {
            //下拉刷新
            [params setValue:@"asc" forKey:@"orderbytype"];
        }else{
            [params setValue:@"desc" forKey:@"orderbytype"];
            [params setValue:@"20" forKey:@"pagesize"];
        }
        [params setValue:@"" forKey:@"titlename"];
        [params setValue:@"" forKey:@"ismycontent"];
        [params setValue:listByType() forKey:@"method"];
        
        
        FormDataRequest* request = [FormDataRequest requestNetURI:API_URL
                                                           params:params
                                                         delegate:self
                                                 finishedSelector:@selector(getMoreSuccess:)
                                                     failSelector:@selector(webRequestFailed:)];
        if (request) {
            [[NetRequestManager sharedInstances] addOperation:request];
            [self showLoading:nil];
        }

    }
       
}

- (void)getMoreSuccess:(ASIHTTPRequest*)request{
    [self removeLoading];
    id obj = [ECJsonParser objectWithJsonString:[request responseString]];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        ECLog(@"%@", [obj description]);
        id data = [obj valueForKey:@"data"];
        if (data && [data isNSxxxClass:[NSDictionary class]]) {
            self.pullingData = [data objectForKey:[self.configs objectForKey:@"listKey"]];

            if ([self.pullingData count] <= 0) {
                [self.tableView tableViewDidFinishedLoadingWithMessage:@"没有更多了"];
                return;
            }
            
            if (self.pullingtDirection == ePullingDirectionUp) {
                if ([self.pullingData count]>20) {
                    [self.dataSource removeAllObjects];
                    for (int i=0; i<20; i++) {
                        [self.dataSource addObject:[self.pullingData objectAtIndex:i]];
                    }
                }else{
                    for (id obj in self.pullingData) {
                        [self.dataSource insertObject:obj atIndex:0];

                    }
                }
            } else {
                for (id obj in self.pullingData) {

                    [self.dataSource addObject:obj ];
                }
                
                
            }
            [self.tableView tableViewDidFinishedLoading];
            [self.tableView reloadData];
            
        }
    }
}


- (void)showTableView{
//    CGFloat viewHeight = self.navigator.view.frame.size.height;

    if (nil == _tableView) {
        
        CGFloat tableViewHeight = self.view.frame.size.height;
        if (IOS7_OR_LATER) {
            tableViewHeight -= 20;
        }
        if ([[self.styles valueForKey:@"hasNavigationBar"]boolValue]) {
            tableViewHeight -= 44 ;
        }
        if ([self.styles valueForKey:@"hasTabBar"] && [[self.styles valueForKey:@"hasTabBar"] boolValue]) {
            tableViewHeight -= 49 ;
        }
        _tableView = [[ECPullingTableView alloc] initWithFrame:CGRectMake(0, 0, validWidth(), tableViewHeight) style:UITableViewStylePlain];
        
        
        [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
//        [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.pullingDelegate = self;
        
        if ([(NSNumber*)[self.styles objectForKey:@"isWithSeparateLine"] boolValue]) {
            [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        }
        [self.view addSubview:_tableView];
    }
    if (IOS7_OR_LATER) {
        _tableView.separatorInset = UIEdgeInsetsZero;
    }
}

-(void) initNetRequestParams
{
    //网络请求
    NSMutableDictionary* params = [NSMutableDictionary new];
    
//    if (nil != self.requestId && nil != self.requestIdKey && nil != self.method) {
//        [params setObject:self.method forKey:@"method"];
//        [params setObject:self.requestId forKey:self.requestIdKey];
//    }
    
    if (nil != [self.url.params valueForKey:@"requestId"])
    {
        self.requestId = [self.url.params valueForKey:@"requestId"];
    }else if (nil != [self.query objectForKey:@"requestId"] && [self.query objectForKey:@"requestId"] != NULL)
    {
        self.requestId = [self.query objectForKey:@"requestId"];
    }

    [params setValue:self.method forKey:@"method"];
    if ([self.method isEqualToString:@"content.getmyfavlist"]) {
        [params setValue:[self.netDataRelevant valueForKey:@"favtype"] forKey:@"favtype"];
    }
    
    [params setValue:self.requestId forKey:[[self.configs objectForKey:@"netDataRelevant"] valueForKey:@"requestIdKey"]];

    if (_isNeedRefresh) {
        [params setValue:@"id" forKey:@"orderbyname"];
        [params setValue:@"desc" forKey:@"orderbytype"];
    }else{
        if (nil != [self.configs objectForKey:@"orderbyname"] && ![@"" isEqualToString:[self.configs objectForKey:@"orderbyname"]]) {
            [params setValue:[self.configs objectForKey:@"orderbyname"] forKey:@"orderbyname"];
        }
        if (nil != [self.configs objectForKey:@"orderbytype"] && ![@"" isEqualToString:[self.configs objectForKey:@"orderbytype"]]) {
            [params setValue:[self.configs objectForKey:@"orderbytype"] forKey:@"orderbytype"];
        }
    }
    
    //针对本项目“生活圈”的设置 new API
    if ([[self.configs valueForKey:@"listKey"] isEqual:@"data"])
    {
        if (nil != [self.configs objectForKey:@"ordername"] && ![@"" isEqualToString:[self.configs objectForKey:@"ordername"]]) {
            [params setValue:[self.configs objectForKey:@"ordername"] forKey:@"ordername"];
        }
        if (nil != [self.configs objectForKey:@"ordertype"] && ![@"" isEqualToString:[self.configs objectForKey:@"ordertype"]]) {
            [params setValue:[self.configs objectForKey:@"ordertype"] forKey:@"ordertype"];
        }
        [params setObject:@"0" forKey:@"lastid"];
        
    }
    
    if ([self.method isEqualToString:listByType()]) {
        [params setValue:@"" forKey:@"titlename"];
        [params setValue:@"" forKey:@"ismycontent"];
        [params setValue:@"" forKey:@"lastid"];
        [params setValue:@"20" forKey:@"pagesize"];
    }
    if ([[self.configs valueForKey:@"isWithPosition"] boolValue]) {
        
        [params setValue:@"121.509068" forKey:@"log"];
        [params setValue:@"31.297842" forKey:@"lat"];
        [params setValue:@"10000000" forKey:@"size"];
        [params setValue:@"default" forKey:@"maptype"];
    }
    // add params from config
    NSArray* paramsArray =  [self.netDataRelevant objectForKey:@"params"];
    if (paramsArray && [paramsArray count]) {
        for (id paramItem in paramsArray) {
            if ([paramItem objectForKey:@"value"] && [paramItem objectForKey:@"key"]) {
                [params setValue:[paramItem objectForKey:@"value"]  forKey:[paramItem objectForKey:@"key"]];
            }
            
        }
    }
    
    NSDictionary* paramList = [self.configs objectForKey:@"paramList"];
    
    NSArray* paramKeyList = [paramList allKeys];
    for (NSString* key in paramKeyList)
    {
        if ([paramList valueForKey:key] && ![[paramList valueForKey:key] isEqual:@""]) {
            [params setValue:[paramList valueForKey:key] forKey:key];
        }
    }
    
    if ([self.netDataRelevant objectForKey:@"apiversion"] && ![[self.netDataRelevant objectForKey:@"apiversion"] isEqualToString:@""]) {
        [self.netRequestParams setObject:[self.netDataRelevant objectForKey:@"apiversion"] forKey:@"apiversion"];
    }
    
    self.netRequestParams = params;
}

- (void) freshData:(BOOL) isForce{
    ECLog(@"list view start fresh data params : %@" ,self.netRequestParams);
    // 先清除数据
//    [self.dataSource removeAllObjects];
//    [self.tableView reloadData];
        
    FormDataRequest* request = nil;
    if (isForce) {
        request = [FormDataRequest requestNetURI:API_URL
                                          params:self.netRequestParams
                                        delegate:self
                                finishedSelector:@selector(requestFindished:)
                                    failSelector:@selector(webRequestFailed:)];
    }else{
        NSLog(@"%s   ",TAG);
        request = [FormDataRequest requestNetURI:API_URL
                                          params:self.netRequestParams
                                        delegate:self
                                finishedSelector:@selector(requestFindished:)
                                    failSelector:@selector(webRequestFailed:)
                                   cacheSelector:@selector(handleRequestData:)];
    }
    
    if (request) {
        
        [[NetRequestManager sharedInstances] addOperation:request];
        
        [self showLoading:nil];
    }

}

-(id)getValue:(NSDictionary *)data forKey:(NSString *)key
{
    if (nil == key || [key isEqual:@""]) {
        return nil;
    }
    int location = [key rangeOfString:@"."].location;
    
    if (location == NSNotFound) {
        NSLog(@"value %@ fromkey : %@",[data valueForKey:key],key);
        return [data valueForKey:key];
    }else{
        NSString* forwardKey = [key substringToIndex:location];
        NSString* behandkey = [key substringFromIndex:location+1];
        //递归
        NSDictionary* subData = [data valueForKey:forwardKey];
        return [self getValue:subData forKey:behandkey];
    }
    return nil;
}
@end
