//
//  BaseViewController.m
//  HealthyClub
//
//  Created by Alix on 1/23/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECBaseViewController.h"
#import "Extends.h"
#import "ECViews.h"
#import <UIKit/UIGeometry.h>
#import "DisplayUtil.h"
#define TAG "ECBaseViewController"



@interface ECBaseViewController ()

@end

@implementation ECBaseViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSLog(@"ECBaseViewController viewDidLoad : ");
	// Do any additional setup after loading the view.
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    // 读取配置文件
    _configName = [self.url.params objectForKey:@"configName"];
    _instanceName = _configName;
    _isShowContent = YES;
    if (nil == _configName || [@"" isEqualToString:_configName]) {
        ECLog(@"%@ 参数传递错误：缺少config项",NSStringFromClass([self class]));
        return;
    }else{
        NSURL *PlistURL = [[NSBundle mainBundle] URLForResource:_configName withExtension:@"plist"];
        self.configs =  [NSDictionary dictionaryWithContentsOfURL:PlistURL];   

        ECLog(@"%s configs: %@",TAG,self.configs);

        self.styles = [self.configs objectForKey:@"style"];
        self.navTitle = [self.configs objectForKey:@"navTitle"];
        self.netDataRelevant = [self.configs objectForKey:@"netDataRelevant"];
        self.isNeedLogin = [(NSNumber*)[self.configs objectForKey:@"isNeedLogin"] boolValue];
    }
    if (nil == self.configs || self.configs == NULL) {
        
        [[ECClearApp shareInstance] exitApp:@"程序错误" message:@"退出程序：参数传递错误！"];
    }

    if (nil != [self.query objectForKey:@"navTitle"]) {
        self.navTitle = [self.query objectForKey:@"navTitle"];
    }
    if (nil != self.navTitle) {
        self.navigationItem.title = self.navTitle;
    }
    if (nil != [[self.configs objectForKey:@"style" ] objectForKey:@"hasNavigationBar"])
    {
        if ([@"NO" isEqual:[[self.configs objectForKey:@"style" ] objectForKey:@"hasNavigationBar"]]) {
            [self.navigationController setNavigationBarHidden:YES];
        }else
        {
            [self.navigationController setNavigationBarHidden:NO];
        }
        
    }
    
    //设置背景
    if (nil != [[self.configs objectForKey:@"style"] objectForKey:@"viewBg"] && ![[[self.configs objectForKey:@"style"] objectForKey:@"viewBg"] isEqual:@""]) {
        
        [self setViewBackgroud:self.view withImage:[UIImage imageNamed:[[self.configs objectForKey:@"style"] objectForKey:@"viewBg"]]];
    }else{
        [self.view setBackgroundColor:[UIColor whiteColor]];
    }
    //NavigationBar backGround
    [self.navigator.navigationBar setBackgroundImage:[UIImage imageNamed:@"navBackground.png"] forBarMetrics:UIBarMetricsDefault];
    
    //适应iOS7 的样式，设置 Controller.view 属性，不延伸到 statusbar及navigationBar 下面；
    if ( IOS7_OR_LATER )
    {
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = NO;
        self.modalPresentationCapturesStatusBarAppearance = NO;
        
        [self.navigator.navigationBar setTintColor:[UIColor whiteColor]];
    }else{
        [self.navigator.navigationBar setTintColor:[UIColor colorWithRed:0.53 green:0.15 blue:0.18 alpha:1.00]];
    }
    
    //返回按扭
    ECLog(@"set back button");
    UIBarButtonItem* back = [[UIBarButtonItem alloc] init];
    back.style = UIBarButtonItemStyleBordered;
    back.title = @"返回";
    self.navigationItem.backBarButtonItem = back;
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (BOOL)prefersStatusBarHidden
{
    return NO;
}

- (void) viewWillAppear:(BOOL)animated{
    if (self.isNeedLogin) {
        if (nil == [ECKeyChain userName] || [@"" isEqualToString:[ECKeyChain userName]]) {
            [self addNeedLoginView];
            _isShowContent = NO;
        }else{
            [_needLoginView removeFromSuperview];
            _isShowContent = YES;
        }
    }
    if (nil != [[self.configs objectForKey:@"style" ] objectForKey:@"hasNavigationBar"])
    {
        if ([@"NO" isEqual:[[self.configs objectForKey:@"style" ] objectForKey:@"hasNavigationBar"]]) {
            if (![self.navigationController isNavigationBarHidden]) {
                [self.navigationController setNavigationBarHidden:YES animated:YES];
            }
        
        }else
        {
            if ([self.navigationController isNavigationBarHidden]) {
                [self.navigationController setNavigationBarHidden:NO animated:YES];
                //NavigationBar backGround
                [self.navigator.navigationBar setBackgroundImage:[UIImage imageNamed:@"navBackground.png"] forBarMetrics:UIBarMetricsDefault];
            }
        
        }
        
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    return (toInterfaceOrientation == UIInterfaceOrientationPortrait);
}
#pragma mark - ios 6.0 & later
- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskPortrait;
}
- (BOOL)shouldAutorotate{
    return NO;
}
//- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
//    UIViewController* ctrl = [UIViewController new];
//    [self.navigationController pushViewController:ctrl animated:YES];
//}


#pragma mark - 网络请求失败
- (void)webRequestFailed:(ASIHTTPRequest*)request{
    [self removeLoading];
    UIAlertView* av = [[UIAlertView alloc] initWithTitle:@"获取信息失败" message:@"网络不给力!!" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [av show];
}
#pragma mark - 网络请求成功
- (void)requestFindished:(FormDataRequest*)request{
    
    NSString* reponseString = [request responseString];
    ECLog(@"%s responseString:%@",TAG,reponseString);
    if ([reponseString rangeOfString:@"\"error\""].location != NSNotFound || [reponseString rangeOfString:@"\"Error\""].location != NSNotFound || [reponseString rangeOfString:@"\"error_num\""].location != NSNotFound) {
//        [[ECSpecRequest shareInstance] showError:reponseString];
        NSLog(@"response error:%@",reponseString);
    }
    else{
        [self handleRequestData:request.responseData];
    }
    // 处理完成后 移除加载框
    [self removeLoading];
    
}
- (void)checkRequestData:(FormDataRequest*)request
{
    
    NSString* reponseString = [request responseString];
    ECLog(@"%s responseString:%@",TAG,reponseString);
    if ([reponseString rangeOfString:@"\"error\""].location != NSNotFound || [reponseString rangeOfString:@"\"Error\""].location != NSNotFound) {
        [[ECSpecRequest shareInstance] showError:reponseString];
        //        NSLog(@"response error:%@",reponseString);
    }
    // 处理完成后 移除加载框
    [self removeLoading];
    
}

- (void)handleRequestData:(NSData*)data{
    ECLog(@"%s Start Handing Data From Request...",TAG);
}

#pragma mark - 显示弹出框
- (void)showLoading:(NSString*)message{
    if ([NetRequestManager networdEnabled]) {
        [ECPopViewUtil showLoading:message view:self.view];
    }
}
- (void)removeLoading{
    [ECLoadingBezelActivityView removeViewAnimated:YES];
}

#pragma mark - 退出程序
- (void)exitApp{
    [[ECClearApp shareInstance] exitAppForNet];
}

- (BOOL)viewDeckController:(IIViewDeckController *)viewDeckController shouldPan:(UIPanGestureRecognizer *)panGestureRecognizer {
    CGPoint translation = [panGestureRecognizer translationInView:self.view];
    if (translation.x>2 &&(ABS(translation.x)>ABS(translation.y))) {
        [self.navigationController popViewControllerAnimated:YES];
        ECLog(@"向右滑动事件！！");
    }
    return NO;
}

- (IBAction)goBack:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) addToRootButton{
    UIButton* btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setImage:[UIImage ecImageNamed:@"menu.png"] forState:UIControlStateNormal];
    [btn sizeToFit];
    
    [btn addTarget:self action:@selector(goRootViewCtrl:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem* rightItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    [self.navigationItem setRightBarButtonItem:rightItem];
}

- (void)goRootViewCtrl:(id)sender{
    [self.viewDeckController toggleLeftViewAnimated:YES];
    [self.navigationController popToRootViewControllerAnimated:YES];
    
}

- (NSString*)description{
    return [NSString stringWithFormat:@"%@.%@",NSStringFromClass([self class]),self.instanceName];
}

// 在试图前添加 _needLoginView 
- (void)addNeedLoginView{
    _needLoginView = [[ECNeedLoginView alloc] initWithFrame:CGRectMake(0, 0, validWidth(), validHeight())];
    [self.view addSubview:_needLoginView];
}
- (void) setViewBackgroud:(UIView *)view withImage:(UIImage *)backgroudImage
{
    UIGraphicsBeginImageContext(view.frame.size);
    [backgroudImage drawInRect:view.bounds];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    view.backgroundColor = [UIColor colorWithPatternImage:image];
}
@end
