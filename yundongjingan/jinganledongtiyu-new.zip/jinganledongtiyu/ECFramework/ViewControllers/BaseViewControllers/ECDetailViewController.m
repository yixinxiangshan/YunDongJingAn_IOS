//
//  ECDetailViewController.m
//  DemoECEcloud
//
//  Created by EC on 3/13/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECDetailViewController.h"
#import "NSObjectExtends.h"

@interface ECDetailViewController ()

@end

@implementation ECDetailViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    self.subViews = [NSMutableArray new];
	// Do any additional setup after loading the view.
    self.isLocalData = [(NSNumber*)[self.configs objectForKey:@"isLocalData"] boolValue];
    self.dataKey = [self.configs objectForKey:@"dataKey"];
    if (self.isLocalData == NO) {
        //网络数据
        if (nil != [self.url.params valueForKey:@"requestId"])
        {
            self.requestId = [self.url.params valueForKey:@"requestId"];
        }else if (nil != [self.query objectForKey:@"requestId"] && ![[NSString stringWithFormat:@"%@",[self.query objectForKey:@"requestId"]] isEqualToString:@""])
        {
            self.requestId = [self.query objectForKey:@"requestId"];
        }
        
        NSDictionary* netDataRelevant = [self.configs objectForKey:@"netDataRelevant"];
        if (nil != [netDataRelevant objectForKey:@"requestId"] && ![@"" isEqualToString:[netDataRelevant objectForKey:@"requestId"]]) {
            self.requestId = [netDataRelevant objectForKey:@"requestId"];
        }
        self.requestIdKey = [netDataRelevant objectForKey:@"requestIdKey"];
        self.method = [netDataRelevant objectForKey:@"method"];
        
        if (nil==self.method || [@"" isEqualToString:self.method]) {
            ECLog(@"%@ configs error: method is null!",NSStringFromClass([self class]));
        }
        
        //网络请求
        [self netRequest];
        
    }else{
        if (nil == [self.configs objectForKey:@"localData"]) {
            ECLog(@"configs error: localdata is null");
            return ;
        }
        self.dataDic = [self.configs objectForKey:@"localData"];
        [self handleRequestData:nil];
    }
}
- (void) netRequest
{
    
    NSMutableDictionary* params = [NSMutableDictionary new];
    if (nil != self.requestId && nil != self.requestIdKey && nil != self.method) {
        [params setObject:self.method forKey:@"method"];
        [params setObject:self.requestId forKey:self.requestIdKey];
    }
    if ([self.netDataRelevant objectForKey:@"apiversion"] && ![[self.netDataRelevant objectForKey:@"apiversion"] isEqualToString:@""]) {
        [params setObject:[self.netDataRelevant objectForKey:@"apiversion"] forKey:@"apiversion"];
    }
    FormDataRequest* request = [FormDataRequest requestNetURI:API_URL
                                                       params:params
                                                     delegate:self
                                             finishedSelector:@selector(requestFindished:)
                                                 failSelector:@selector(webRequestFailed:)];
    if (request) {
        [[NetRequestManager sharedInstances] addOperation:request];
        [self showLoading:nil];
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.

}

- (void)handleRequestData:(NSData*)data{
    [super handleRequestData:data];
    id tempData = nil;
    //处理数据
    id obj = [ECJsonParser objectWithJsonData:data];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        tempData = [obj valueForKey:@"data"];
    }
    if (tempData && [tempData isNSxxxClass:[NSDictionary class]]) {
        self.dataDic = tempData;
    }else{
        if (nil == self.dataDic) {
            // TODO: 弹出数据出错！
        }
    }

}

#pragma mark - layout subviews
- (void) layoutSubViews
{
    [self.view removeAllSubViews];
    CGSize size = CGSizeMake(self.view.frame.size.width, 10);
    for (UIView* view in _subViews) {
        [view setFrame:CGRectMake(view.frame.origin.x, size.height, view.frame.size.width, view.frame.size.height)];
        size.height += view.frame.size.height + 5;
        [self.view addSubview:view];
    }
}

@end
