//
//  ECPullingTableViewController.h
//  DemoECEcloud
//
//  Created by EC on 3/4/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECBaseViewExtendController.h"
#import "PullingRefreshTableView.h"
#import "ECPullingTableView.h"
#import "Utils.h"

// 下拉加载最新 or 上拖加载更多
enum PullingDirectionType : NSInteger {
    ePullingDirectionUp = 0,
    ePullingDirectionBottom,
    };

@interface ECPullingTableViewController : ECBaseViewExtendController  <PullingRefreshTableViewDelegate,UITableViewDataSource,UITableViewDelegate>

@property (nonatomic, assign) enum PullingDirectionType pullingtDirection;    // 拖动的方向

@property (nonatomic, strong) NSString* cellId;
@property (nonatomic, strong) NSString* contentIdKey;
@property (nonatomic, assign) BOOL isNeedRefresh;


@property (nonatomic,strong) ECPullingTableView* tableView;
@property (nonatomic,strong) NSMutableArray* dataSource;
@property (nonatomic,strong) NSMutableArray* pullingData;

@property  (nonatomic, strong) NSMutableDictionary* netRequestParams;


- (void)requestData;
- (void)handleRequestData:(NSData*)data;
- (void)showTableView;
- (void) freshData:(BOOL) isForce;
-(id)getValue:(NSDictionary *)data forKey:(NSString *)key;
-(void) initNetRequestParams;
@end
