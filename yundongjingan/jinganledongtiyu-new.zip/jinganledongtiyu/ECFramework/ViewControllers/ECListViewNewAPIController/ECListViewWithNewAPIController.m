//
//  ECListViewWithNewAPIController.m
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-10.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "ECListViewWithNewAPIController.h"
#import "ECToolBar.h"

#define TAG "ECListViewWithNewAPIController"

@interface ECListViewWithNewAPIController ()
@property CGFloat toolBarHeight;
@end

@implementation ECListViewWithNewAPIController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
    [super viewDidLoad];
//    [self showToolBar];
//    [self getMenuFromServer];
//    [self showToolBar:nil localConfig:[[self.configs objectForKey:@"localData"] objectForKey:@"toolBarConfig"]];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateNetRequestParams:) name:@"updateNetRequestParams" object:nil];
	
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void) showToolBar:(NSArray *)menuFromServer localConfig:(NSArray *)localConfig
{
    ECToolBar* toolBar = [[ECToolBar alloc] initWithFrame:CGRectMake(0, 0, validWidth(), 44) menuFromServer:menuFromServer localConfig:localConfig];
    [toolBar setBackgroundColor:[UIColor colorWithRed:0.91 green:0.96 blue:0.91 alpha:1.00]];
    [self.view addSubview:toolBar];
    
}
- (void)showTableView{
    //    CGFloat viewHeight = self.navigator.view.frame.size.height;
    if (nil == self.tableView) {
        self.tableView = [[ECPullingTableView alloc] initWithFrame:CGRectMake(0, 0, validWidth(), validHeight()-44-49) style:UITableViewStylePlain];
        [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
//        [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        self.tableView.pullingDelegate = self;
        
        if ([(NSNumber*)[self.styles objectForKey:@"isWithSeparateLine"] boolValue]) {
            [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        }
        //  R.oshan Label
        NSLog(@"%s  showTableView",TAG);
        [self.view addSubview:self.tableView];
    }
}

- (void) getMenuFromServer
{

    NSDictionary* config = [self.configs valueForKey:@"menuFromServer"];
    NSMutableDictionary* params = [NSMutableDictionary new];
    
    [params setObject:[config valueForKey:@"requestId"] forKey:[config valueForKey:@"requestIdKey"]];
    [params setObject:[config valueForKey:@"method"] forKey:@"method"];
    
    FormDataRequest* request = [FormDataRequest requestNetURI:API_URL
                                                       params:params
                                                     delegate:self
                                             finishedSelector:@selector(menuDataLoaded:)
                                                 failSelector:@selector(webRequestFailed:)
                                                cacheSelector:@selector(paraseMenuData:)
                                ];
    if (request) {
        
        [[NetRequestManager sharedInstances] addOperation:request];
        
        [self showLoading:nil];
    }
}
- (void)menuDataLoaded:(FormDataRequest*)request{
    
    
    
    NSString* reponseString = [request responseString];
    ECLog(@"%s responseString:%@",TAG,reponseString);
    if ([reponseString rangeOfString:@"\"error\""].location != NSNotFound || [reponseString rangeOfString:@"\"Error\""].location != NSNotFound) {
        [[ECSpecRequest shareInstance] showError:reponseString];
        //        NSLog(@"response error:%@",reponseString);
    }
    else{
        [self paraseMenuData:request.responseData];
           }
    // 处理完成后 移除加载框
    [self removeLoading];
    
}
- (void) paraseMenuData:(NSData *)data
{
    NSDictionary* config = [self.configs valueForKey:@"menuFromServer"];
    id tempData = nil;
    //处理数据
    id obj = [ECJsonParser objectWithJsonData:data];
    
    //    NSLog(@"%@ : %@",self.class,obj);
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        tempData = [obj valueForKey:@"data"];
    }
    if (tempData && [tempData isNSxxxClass:[NSDictionary class]]) {
        
        id dataArray = [self getValue:tempData forKey:[config objectForKey:@"listKey"]];
        if (dataArray && [dataArray isNSxxxClass:[NSArray class]]) {
            [self showToolBar:dataArray localConfig:[[self.configs objectForKey:@"localData"] objectForKey:@"toolBarConfig"]];
        }
    }

}

-(void) updateNetRequestParams:(NSNotification*)noti
{
    NSLog(@"%@",noti.userInfo);
    NSArray* keys = [noti.userInfo allKeys];
    for (NSString* key in keys) {
        [self.netRequestParams setValue:[noti.userInfo valueForKey:key] forKey:key];
        
//        NSLog(@"%@",self.netRequestParams);
    }
    //lastid 置 0
    [self.netRequestParams setValue:@"0" forKey:@"lastid"];
    
    [self freshData:YES];
}
- (void) reciveBroadcast:(NSDictionary *)params
{
//    NSLog(@"%@ : %@",self.class,params);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updateNetRequestParams" object:nil userInfo:[params valueForKey:@"urlParams"]];
}
@end
