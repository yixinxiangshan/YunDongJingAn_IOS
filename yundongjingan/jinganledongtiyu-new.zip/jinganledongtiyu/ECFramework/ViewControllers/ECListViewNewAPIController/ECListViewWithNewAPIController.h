//
//  ECListViewWithNewAPIController.h
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-10.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "ECListViewController.h"

@interface ECListViewWithNewAPIController : ECListViewController

@end
