//
//  ECGeneralDetailViewController.m
//  JingAnWeekly
//
//  Created by EC on 3/18/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECGeneralDetailViewController.h"

@interface ECGeneralDetailViewController ()

@end

@implementation ECGeneralDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)handleRequestData:(NSData*)data{
    [super handleRequestData:data];
    self.dataItem = [self.dataDic objectForKey:[self.configs objectForKey:@"dataKey"]];
    [self showContentView];
}

-(void) showContentView{
    // Do any additional setup after loading the view.
     _genDetail = [[ECDetail alloc] initWithFrame:CGRectMake(0, 0, validWidth(), validHeight())];
    
    _genDetail.detailDelegate = self;
    self.isWithPraise = [(NSNumber*)[self.configs objectForKey:@"isWithPraise"] boolValue];
    if (_isWithPraise) {
        [_genDetail.praiseButton setHidden:NO];
        [_genDetail.voteCount setHidden:NO];
        [_genDetail.shareButton setHidden:NO];
        //设置title label 长度
        _genDetail.titleDetail.frame = CGRectMake(_genDetail.titleDetail.frame.origin.x, _genDetail.titleDetail.frame.origin.y, 220.0f, _genDetail.titleDetail.frame.size.height);
    }else{
        [_genDetail.praiseButton setHidden:YES];
        [_genDetail.voteCount setHidden:YES];
        [_genDetail.shareButton setHidden:YES];
         //设置title label 长度
        _genDetail.titleDetail.frame = CGRectMake(_genDetail.titleDetail.frame.origin.x, _genDetail.titleDetail.frame.origin.y, 260.0f, _genDetail.titleDetail.frame.size.height);
        
    }
    _isPraised = NO;
    if ([(NSNumber*)[self.dataItem objectForKey:@"IsVote"] boolValue]) {
        // have praised before
        _isPraised = YES;
        [_genDetail.praiseButton setImage:[UIImage imageNamed:@"praised.png"]];
    }
    [self.view addSubview:_genDetail];
    
//    [_genDetail.content setEditable:NO];


    // TODO: 处理detail
    _genDetail.titleDetail.text = [self.dataItem objectForKey:[self.configs objectForKey:@"titleKey"]];
    
//    _genDetail.content.text = [self.dataItem objectForKey:[self.configs objectForKey:@"contentKey"]];
    [_genDetail setContents:[self.dataItem objectForKey:[self.configs objectForKey:@"contentKey"]]];
    
    
    _genDetail.voteCount.text = [NSString stringWithFormat: @"%@",[self.dataItem objectForKey:@"VoteCount"]];
    _imageUri = [NSString stringWithFormat:@"%@%@",imageURI(),[self.dataItem objectForKey:[self.configs objectForKey:@"imageKey"]]];

    [self resetViewPosition];

    //处理UITextView大小
    CGRect frame = _genDetail.content.frame;
    frame.size.height = _genDetail.content.frame.size.height;
    _genDetail.content.frame = frame;


    //处理图片
    [_genDetail.imageContainer updateWithNormalImageURI:_imageUri];
    [_genDetail.imageContainer.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_genDetail.imageContainer.layer setBorderWidth:1.0f];

    if (_genDetail.imageContainer.image!=nil) {
        CGFloat showHeight = _genDetail.imageContainer.frame.size.width*_genDetail.imageContainer.image.size.height/_genDetail.imageContainer.image.size.width;
        [_genDetail.imageContainer setFrame:CGRectMake(20, _genDetail.titleDetail.frame.origin.y+_genDetail.titleDetail.frame.size.height, _genDetail.imageContainer.frame.size.width, showHeight)];
        [_genDetail.imageContainer updateWithNormalImageURI:_imageUri];
    } else {
        //TODO 修改默认imageContainer 大小
        [_genDetail.imageContainer setImage:[UIImage imageNamed:kDefaultImage]];
        CGFloat showHeight = _genDetail.imageContainer.frame.size.width*_genDetail.imageContainer.image.size.height/_genDetail.imageContainer.image.size.width;
        [_genDetail.imageContainer setFrame:CGRectMake(20, _genDetail.titleDetail.frame.origin.y+_genDetail.titleDetail.frame.size.height, _genDetail.imageContainer.frame.size.width, showHeight)];
        [_genDetail.imageContainer setImage:[UIImage imageNamed:kDefaultImage]];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(imageContainerFrameChanged:) name:kImageContainerFrameChangedNoti object:nil];
    }
    [self resetViewPosition];
    
}



- (void)imageContainerFrameChanged:(NSNotification*)noti{

    id obj = [noti object];
    if (obj && [obj isEqual:_genDetail.imageContainer]) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        if (_genDetail.imageContainer.image!=nil) {
            CGFloat showHeight = _genDetail.imageContainer.frame.size.width*_genDetail.imageContainer.image.size.height/_genDetail.imageContainer.image.size.width;
            [_genDetail.imageContainer setFrame:CGRectMake(20, _genDetail.titleDetail.frame.origin.y+_genDetail.titleDetail.frame.size.height, _genDetail.imageContainer.frame.size.width, showHeight)];
            [_genDetail.imageContainer updateWithNormalImageURI:_imageUri];
            [self resetViewPosition];
        } else {
            return;
        }
    }
}

- (void)resetViewPosition{
    // 设置内容位置
    CGRect contentFrame = _genDetail.content.frame;
    contentFrame.origin.y =_genDetail.imageContainer.frame.origin.y + _genDetail.imageContainer.frame.size.height + 8.0f;
//
//    CGSize newSize = [_genDetail.content.text
//                      sizeWithFont:_genDetail.content.font
//                      constrainedToSize:CGSizeMake(_genDetail.content.frame.size.width,9999)
//                      lineBreakMode:NSLineBreakByCharWrapping];
//    
    contentFrame.size.height += 10;
    [_genDetail.content setFrame:contentFrame];

    //设置scrollview contentsize
    CGFloat height = _genDetail.content.frame.origin.y+_genDetail.content.frame.size.height;
    if (height > _genDetail.scrollView.frame.size.height) {
        [_genDetail.scrollView setContentSize:CGSizeMake(320.0f,height)];
    }
    
}
#pragma mark -- ecDetail delegate
- (void) pressPraise:(ECDetail*)ecDetail{
    if (nil == [ECKeyChain userName] || [@"" isEqualToString:[ECKeyChain userName]]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:[NSString stringWithFormat:@"%@.%@.needLogin",self.instanceName,NSStringFromClass([self class])] object:nil userInfo:nil];
        return;
    }
    if (!_isPraised) {
        NSMutableDictionary* params = [NSMutableDictionary new];
        [params setObject:addComment() forKey:@"method"];
        [params setObject:self.requestId forKey:@"contentid"];
        [params setObject:@"3" forKey:@"typenum"];
        [params setObject:@"1" forKey:@"vote_star"];
        
        FormDataRequest* request = [FormDataRequest requestNetURI:API_URL
                                                           params:params
                                                         delegate:self
                                                 finishedSelector:@selector(praiseFindished:)
                                                     failSelector:@selector(webRequestFailed:)];
        if (request) {
            [[NetRequestManager sharedInstances] addOperation:request];
            [self showLoading:nil];
        }

    }
    
}

- (void)touchedInside:(ECDetail*)ecDetail{
    ECLog(@"touch inside...");
}

- (void)praiseFindished:(FormDataRequest*)request{
    NSString* reponseString = [request responseString];
    if ([reponseString rangeOfString:@"\"error\""].location != NSNotFound || [reponseString rangeOfString:@"\"Error\""].location != NSNotFound) {
        [[ECSpecRequest shareInstance] showError:reponseString];
        NSLog(@"response error:%@",reponseString);
    }
    else if([reponseString rangeOfString:@"Success"].location != NSNotFound) {
        [_genDetail.praiseButton setImage:[UIImage imageNamed:@"praised.png"]];
        NSInteger voteCount = [(NSNumber*)_genDetail.voteCount.text integerValue]+1;
        _genDetail.voteCount.text = [NSString stringWithFormat:@"%d",voteCount];
        _isPraised = YES;
        id tempData = nil;
        //处理数据
        id obj = [ECJsonParser objectWithJsonData:request.responseData];
        if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
            tempData = [obj valueForKey:@"data"];
        }
        NSString* praiseMsg = @"";
        if (nil != [tempData objectForKey:@"point_data"]) {
            id loginDic = [tempData objectForKey:@"point_data"];
            if (nil != [loginDic objectForKey:@"point_message"] && ![[loginDic objectForKey:@"point_message"] isEqualToString:@""]) {
                praiseMsg = [loginDic objectForKey:@"point_message"];
            }
        }
        [ECPopViewUtil showAlertView:@"好感动，谢谢你" massage:praiseMsg];

    }
    // 处理完成后 移除加载框
    [self removeLoading];
    
}


@end
