//
//  ECGeneralDetailViewController.h
//  JingAnWeekly
//
//  Created by EC on 3/18/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECDetailViewController.h"
#import "ECDetail.h"

@interface ECGeneralDetailViewController : ECDetailViewController <ECDetailDelegate>

@property (strong, nonatomic) NSString* imageUri;
@property (strong, nonatomic) NSDictionary* dataItem;
@property (strong, nonatomic) ECDetail* genDetail;
@property (assign, nonatomic) BOOL isWithPraise;
@property (assign, nonatomic) BOOL isPraised;

- (void) showContentView;
- (void) resetViewPosition;

@end
