//
//  ECGridViewController.m
//  DemoECEcloud
//
//  Created by EC on 3/5/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECGridViewController.h"
#import "ECThreeImagesCell.h"
#import "ECIndexPath.h"

@interface ECGridViewController ()

@end

@implementation ECGridViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.

    
}

- (void)viewWillAppear:(BOOL)animated{

}

- (void)handleRequestData:(NSData*)data{
    [super handleRequestData:data];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPathz{
    return 122.0;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    int count = [self.dataSource count];

    if (count && count %3) {
        return count/ 3 +1;
    } else {
        return count / 3;
    }

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = nil;
    if (CellIdentifier == nil) {
        CellIdentifier = self.cellId;
    }
    UITableViewCell *cell = nil;
    
    if([CellIdentifier isEqualToString:@"ECThreeImagesCell"]){
        NSInteger count = indexPath.row*3;
        
        cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = (ECThreeImagesCell*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
            
        }
        ((ECThreeImagesCell*)cell).delegate = self;
        ((ECThreeImagesCell*)cell).indexPath = [ECIndexPath new];
        ((ECThreeImagesCell*)cell).indexPath.row = indexPath.row;
//        [((ECThreeImagesCell*)cell).itemImage1 setImage:[UIImage imageNamed:kDefaultImage]];
//        [((ECThreeImagesCell*)cell).itemImage2 setImage:[UIImage imageNamed:kDefaultImage]];
//        [((ECThreeImagesCell*)cell).itemImage3 setImage:[UIImage imageNamed:kDefaultImage]];
        
        [((ECThreeImagesCell*)cell).itemImage1 setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:[self.styles valueForKey:@"cellBg"]]]];
        [((ECThreeImagesCell*)cell).itemImage2 setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:[self.styles valueForKey:@"cellBg"]]]];
        [((ECThreeImagesCell*)cell).itemImage3 setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:[self.styles valueForKey:@"cellBg"]]]];
        
        
        NSLog(@"++++++%@",[self.styles valueForKey:@"cellBg"]);
        
        NSString* imageuri = nil;
        NSArray* splitString = nil;
        NSString* imageName = nil;
        //第一副
        id dataItem = [self.dataSource objectAtIndex:count];
        
        if ([[self.configs valueForKey:@"isLocalData"] boolValue]) {
            ((ECThreeImagesCell*)cell).itemLabel1.text = [dataItem valueForKey:@"title"];
            [((ECThreeImagesCell*)cell).itemImage1 updateWithNormalImage:[UIImage imageNamed:[dataItem valueForKey:@"image_cover"]] hightedImage:nil];
        }else
        {
            ((ECThreeImagesCell*)cell).itemLabel1.text = [dataItem objectForKey:[self.configs objectForKey:@
                                                                                 "titleKey"]];
            splitString = [[dataItem objectForKey:[self.configs objectForKey:@
                                                   "imageUrlKey"]] componentsSeparatedByString:@"."];
            imageName = [NSString stringWithFormat:@"%@_200.%@",splitString[0],splitString[1]];
            imageuri = [NSString stringWithFormat:@"%@%@",imageURI(),imageName];
            ECLog(@"imageURI:%@",imageuri);
            [((ECThreeImagesCell*)cell).itemImage1 updateWithNormalImageURI:imageuri];
        }
        
        
        //第二幅
        if (count+1 < self.dataSource.count) {
            [((ECThreeImagesCell*)cell).itemImage2 setHidden:NO];
            [((ECThreeImagesCell*)cell).itemLabel2 setHidden:NO];
            dataItem = nil;
            dataItem = [self.dataSource objectAtIndex:count+1];
            imageuri = nil;
            splitString = nil;
            imageName = nil;
            
            if ([[self.configs valueForKey:@"isLocalData"] boolValue]) {
                ((ECThreeImagesCell*)cell).itemLabel2.text = [dataItem valueForKey:@"title"];
                [((ECThreeImagesCell*)cell).itemImage2 updateWithNormalImage:[UIImage imageNamed:[dataItem valueForKey:@"image_cover"]] hightedImage:nil];
            }else{
                splitString = [[dataItem objectForKey:[self.configs objectForKey:@
                                                       "imageUrlKey"]] componentsSeparatedByString:@"."];
                imageName = [NSString stringWithFormat:@"%@_200.%@",splitString[0],splitString[1]];
                imageuri = [NSString stringWithFormat:@"%@%@",imageURI(),imageName];
                
                ((ECThreeImagesCell*)cell).itemLabel2.text = [dataItem objectForKey:[self.configs objectForKey:@
                                                                                     "titleKey"]];
                [((ECThreeImagesCell*)cell).itemImage2 updateWithNormalImageURI:imageuri];
            }

            if (count+2 < self.dataSource.count) {
                [((ECThreeImagesCell*)cell).itemImage3 setHidden:NO];
                [((ECThreeImagesCell*)cell).itemLabel3 setHidden:NO];
                dataItem = nil;
                dataItem = [self.dataSource objectAtIndex:count+2];
                imageuri = nil;
                splitString = nil;
                imageName = nil;
                
                
                if ([[self.configs valueForKey:@"isLocalData"] boolValue]) {
                    ((ECThreeImagesCell*)cell).itemLabel3.text = [dataItem valueForKey:@"title"];
                    [((ECThreeImagesCell*)cell).itemImage3 updateWithNormalImage:[UIImage imageNamed:[dataItem valueForKey:@"image_cover"]] hightedImage:nil];
                }else{
                    splitString = [[dataItem objectForKey:[self.configs objectForKey:@
                                                           "imageUrlKey"]] componentsSeparatedByString:@"."];
                    imageName = [NSString stringWithFormat:@"%@_200.%@",splitString[0],splitString[1]];
                    imageuri = [NSString stringWithFormat:@"%@%@",imageURI(),imageName];
                    
                    ((ECThreeImagesCell*)cell).itemLabel3.text = [dataItem objectForKey:[self.configs objectForKey:@
                                                                                         "titleKey"]];
                    [((ECThreeImagesCell*)cell).itemImage3 updateWithNormalImageURI:imageuri];
                }
            }else{
                [((ECThreeImagesCell*)cell).itemImage3 setHidden:YES];
                [((ECThreeImagesCell*)cell).itemLabel3 setHidden:YES];
            }
        }else{
            [((ECThreeImagesCell*)cell).itemImage2 setHidden:YES];
            [((ECThreeImagesCell*)cell).itemLabel2 setHidden:YES];
            [((ECThreeImagesCell*)cell).itemImage3 setHidden:YES];
            [((ECThreeImagesCell*)cell).itemLabel3 setHidden:YES];
        }
        
        ((ECThreeImagesCell*)cell).selectionStyle = UITableViewCellAccessoryNone;
        ((ECThreeImagesCell*)cell).backgroundColor = [UIColor clearColor];
        [((ECThreeImagesCell*)cell).itemImage1 setClipsToBounds:YES];
        [((ECThreeImagesCell*)cell).itemImage2 setClipsToBounds:YES];
        [((ECThreeImagesCell*)cell).itemImage3 setClipsToBounds:YES];
    }
//    if (!cell) {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
//    }

    return cell;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     */
}



- (void) selectImage:(ECIndexPath*)indexPath{
    NSInteger count = (indexPath.row)*3 +indexPath.column;
//    ECLog(@"你点击了第%d张图片。。。",count+1);
    NSDictionary* dataItem = [self.dataSource objectAtIndex:count];
    
    //如果存在 url
    NSString *urlString = [dataItem objectForKey:@"url"];
    if (urlString && (NSNull *)urlString != [NSNull null] && urlString.length > 5) {
        [[ECEventRouter shareInstance] doAction:urlString];
        return;
    }
    
    
    // gen params pass to next ctrl
    NSMutableDictionary* params = [NSMutableDictionary new];
    
    if ([[self.configs valueForKey:@"isLocalData"] boolValue]) {
        [params setObject:[dataItem valueForKey:@"requestId"] forKey:@"requestId"];
        [params setObject:[dataItem valueForKey:@"title"] forKey:@"navTitle"];
    }else{
        [params setObject:[dataItem objectForKey:[self.configs objectForKey:@"contentIdKey"]] forKey:@"requestId"];
        [params setObject:[dataItem objectForKey:[self.configs objectForKey:@"titleKey"]] forKey:@"navTitle"];
    }
    
    
    NSLog(@"%@ clecke action : %@",self.class,[NSString stringWithFormat:@"%@.%@.itemClick",self.instanceName,NSStringFromClass([self class])]);
    
    [[NSNotificationCenter defaultCenter] postNotificationName:[NSString stringWithFormat:@"%@.%@.itemClick",self.instanceName,NSStringFromClass([self class])] object:nil userInfo:params];
}

@end
