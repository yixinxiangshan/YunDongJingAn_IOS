//
//  ECGridViewController.h
//  DemoECEcloud
//
//  Created by EC on 3/5/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECPullingTableViewController.h"
#import "ECThreeImagesCell.h"

#define EC_GRIDVIEW_CTRL_ITEMCLICK  @"ec.gridview.controller.itemclick"

@interface ECGridViewController : ECPullingTableViewController <GridViewDelegate>

@end
