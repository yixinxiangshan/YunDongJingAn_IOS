//
//  ECTabBarController.m
//  ECTabBarController
//
//  Created by EC on 3/8/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECTabBarController.h"
#import "DisplayUtil.h"
#import "UMViewController.h"
#import "DisplayUtil.h"

#define TAG "ECTabBarController"

@interface ECTabBarController ()

@end

typedef NS_ENUM (BOOL, tabStatus){
    tabStatusNormal         = 0,
    tabStatusHighLight      = 1,
} ;

@implementation ECTabBarController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _containerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, validWidth(), self.view.frame.size.height - 49)];
    [_containerView setBackgroundColor:[UIColor yellowColor]];
    [self.view addSubview:_containerView];
    // parsing config file
    
    NSArray* itemsConfig = [self.configs objectForKey:@"tabBarItems"];
    _count = itemsConfig.count;
    
    // Items
    _items = [NSMutableArray new];
    _viewControllers = [NSMutableArray new];
    CGFloat viewHeight = IOS7_OR_LATER ? validHeight()-29 : validHeight()-49 ;
    for (int i = 0; i<_count; i++) {
        NSDictionary* itemConfig = [itemsConfig objectAtIndex:i];
        // item
        UITabBarItem *item = [[UITabBarItem alloc] init];
        item.title = [itemConfig objectForKey:@"title"];
        [item setFinishedSelectedImage:[self tabImage:i status:tabStatusNormal] withFinishedUnselectedImage:[self tabImage:i status:tabStatusHighLight]];
        item.tag = i;
        [_items addObject:item];
        
        //viewController
        UMViewController* viewController = (UMViewController*)[[UMNavigationController alloc] initWithRootViewControllerURL:[NSURL URLWithString:[itemConfig objectForKey:@"viewUrl"]]];
        
        [viewController.view setFrame:CGRectMake(0, 0, validWidth(), viewHeight)];
        [((UMNavigationController*)viewController) setNavigationBarHidden:YES];
        [((UMNavigationController*)viewController) setWantsFullScreenLayout:NO];
        [_viewControllers addObject:viewController];
    }
	
    
    
    // Tab bar
    self.tabBar = [[InfiniTabBar alloc] initWithItems:_items];
    [self.tabBar setFrame:CGRectMake(0, self.view.frame.size.height - 49, validWidth(), 49)];
    
    // Don't show scroll indicator
	self.tabBar.showsHorizontalScrollIndicator = YES;
	self.tabBar.infiniTabBarDelegate = self;
	self.tabBar.bounces = NO;
//    [self.tabBar.s];
    [self.view addSubview:self.tabBar];
    
    [self.tabBar selectItemWithTag:0];
}

- (void)infiniTabBar:(InfiniTabBar *)tabBar didScrollToTabBarWithTag:(int)tag{
    
}
- (void)infiniTabBar:(InfiniTabBar *)tabBar didSelectItemWithTag:(int)tag{
    NSArray *viewsToRemove = [_containerView subviews];
    for (UIView *v in viewsToRemove) {
        [v removeFromSuperview];
    }
    
//    [_containerView addSubview:((UMViewController*)(((UMNavigationController*)_viewControllers[tag]).rootViewController)).view];
    
    //  R.oshan Label
    NSLog(@"init tab's content");
    
    [_containerView addSubview:((UMNavigationController*)_viewControllers[tag]).view];
    self.navigationItem.title = [[((NSArray*)[self.configs objectForKey:@"tabBarItems"]) objectAtIndex:tag] objectForKey:@"title"];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (UIImage *) tabImage:(NSInteger)location status:(tabStatus)tabStatus
{
    NSString* imageName = tabStatus ? [NSString stringWithFormat:@"tab%i",location] : [NSString stringWithFormat:@"tab%i-h",location];
    if (IOS7_OR_LATER) {
        imageName = [NSString stringWithFormat:@"%@-ios7",imageName];
    }
    imageName = [NSString stringWithFormat:@"%@.png",imageName];
    UIImage* image = [UIImage imageNamed:imageName];
    if (!image) {
        image = [UIImage imageNamed:[imageName stringByReplacingOccurrencesOfString:@"-h" withString:@""]];
    }
    return image;
}
@end
