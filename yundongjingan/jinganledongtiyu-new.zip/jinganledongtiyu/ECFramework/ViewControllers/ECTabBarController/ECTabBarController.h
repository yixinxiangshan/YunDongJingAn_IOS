//
//  ECTabBarController.h
//  ECTabBarController
//
//  Created by EC on 3/8/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InfiniTabBar.h"
#import "ECBaseViewController.h"

@interface ECTabBarController : ECBaseViewController <InfiniTabBarDelegate>

@property (nonatomic, strong) InfiniTabBar *tabBar;
@property (nonatomic, strong) UIView* containerView;
@property (nonatomic, strong) NSMutableArray* viewControllers;
@property (nonatomic, strong) NSMutableArray* items;
@property (nonatomic, assign) NSInteger count;

@end
