//
//  ECChannelController.m
//  DemoECEcloud
//
//  Created by EC on 3/14/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECChannelController.h"
#import "LightMenuBarView.h"
#import "LightMenuBarDelegate.h"
#import "ECPullingTableViewController.h"


@interface ECChannelController ()
@property int navigationBarHeight;
@end

@implementation ECChannelController


- (void)viewDidLoad
{

    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    
    self.dataSource = [NSMutableArray new];
    self.isLocalData = [(NSNumber*)[self.configs objectForKey:@"isLocalData"] boolValue];
    if (self.isLocalData == NO) {
        //网络数据
        NSDictionary* netDataRelevant = [self.configs objectForKey:@"netDataRelevant"];
        self.requestId = [netDataRelevant objectForKey:@"requestId"];
        self.requestIdKey = [netDataRelevant objectForKey:@"requestIdKey"];
        self.method = [netDataRelevant objectForKey:@"method"];
        
        if (nil==self.method || [@"" isEqualToString:self.method]) {
            ECLog(@"%@ configs error: method is null!",NSStringFromClass([self class]));
        }
        if (nil != [self.query objectForKey:@"requestId"]) {
            self.requestId = [self.query objectForKey:@"requestId"];
        }
        //网络请求
        NSMutableDictionary* params = [NSMutableDictionary new];
        if (nil != self.requestId && nil != self.requestIdKey && nil != self.method) {
            [params setObject:self.method forKey:@"method"];
            [params setObject:self.requestId forKey:self.requestIdKey];
        }
        if ([self.method isEqualToString:listByType()]) {
            [params setValue:@"id" forKey:@"orderbyname"];
            [params setValue:@"desc" forKey:@"orderbytype"];
            [params setValue:@"" forKey:@"titlename"];
            [params setValue:@"" forKey:@"ismycontent"];
            [params setValue:@"" forKey:@"lastid"];
            [params setValue:@"20" forKey:@"pagesize"];
        }
        
        
        FormDataRequest* request = [FormDataRequest requestNetURI:API_URL
                                                           params:params
                                                         delegate:self
                                                 finishedSelector:@selector(requestFindished:)
                                                     failSelector:@selector(webRequestFailed:)
                                                    cacheSelector:@selector(handleRequestData:)];
        if (request) {
            [[NetRequestManager sharedInstances] addOperation:request];
            [self showLoading:nil];
        }
        
        
    }else{
        //本地数据
        self.dataSource = [[self.configs objectForKey:@"localData"] objectForKey:@"dataList"];
        if (nil == self.dataSource || self.dataSource.count<1) {
            ECLog(@"%@ configs error: loacaldata is null!",NSStringFromClass([self class]));
        }else{
            [self handleRequestData:nil];
        }
        
    }
    
}


- (void)addViewControllers{
    self.itemCount = [self.dataSource count];
    
    _channelBar = [[LightMenuBar alloc] initWithFrame:CGRectMake(0, 0, validWidth(), 33) andStyle:LightMenuBarStyleItem];
    
    _channelBar.delegate = self;
    _channelBar.bounces = YES;
    _channelBar.selectedItemIndex = 0;
    
    _channelBar.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_channelBar];
    
    _containerView = [[UIView alloc] initWithFrame:CGRectMake(0, 33, validWidth(), validHeight()-33)];
    
    [_containerView setBackgroundColor:[UIColor lightGrayColor]];
    [self.view addSubview:_containerView];
    
    
     NSArray* viewControllersConfig = [self.configs objectForKey:@"viewControllers"];
    _viewControllers = [NSMutableArray new];
    if ([viewControllersConfig count]<self.itemCount) {
        ECLog(@"config error: viewControllers is not enough....");
        return;
    }
    for (int i = 0; i<self.itemCount; i++) {

        NSDictionary* viewCtrlConfig = [viewControllersConfig objectAtIndex:i];
        
        //viewController
        UMViewController* viewController = (UMViewController*)[[UMNavigationController alloc] initWithRootViewControllerURL:[NSURL URLWithString:[viewCtrlConfig objectForKey:@"viewUrl"]]];
        [viewController.view setFrame:CGRectMake(0, 0, _containerView.frame.size.width, _containerView.frame.size.height)];
        [((UMNavigationController*)viewController) setNavigationBarHidden:YES];
        [((UMNavigationController*)viewController) setWantsFullScreenLayout:YES];
        [_viewControllers addObject:viewController];
    }
    // simulate a click event
    [self itemSelectedAtIndex:0 inMenuBar:_channelBar];
}

- (void)handleRequestData:(NSData*)data{
    [super handleRequestData:data];
    
    id tempData = nil;
    //处理数据
    id obj = [ECJsonParser objectWithJsonData:data];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        tempData = [obj valueForKey:@"data"];
    }
    if (tempData && [tempData isNSxxxClass:[NSDictionary class]]) {
        id dataArray = [tempData objectForKey:[self.configs objectForKey:@"listKey"]];
        if (dataArray && [dataArray isNSxxxClass:[NSArray class]]) {
            [self.dataSource addObjectsFromArray:dataArray];
        }
    }else{
        if (nil == self.dataSource) {
            //TODO: 弹出数据出错！
            return;
        }
    }
    
    [self addViewControllers];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.

}


/****************************************************************************/
#pragma mark LightMenuBarDelegate
- (NSUInteger)itemCountInMenuBar:(LightMenuBar *)menuBar {
    return self.itemCount;
}

- (NSString *)itemTitleAtIndex:(NSUInteger)index inMenuBar:(LightMenuBar *)menuBar {
    id itemData = [_dataSource objectAtIndex:index];
    return [NSString stringWithFormat:@"%@",[itemData objectForKey:[self.configs objectForKey:@"titleKey"]]];
}

- (void)itemSelectedAtIndex:(NSUInteger)index inMenuBar:(LightMenuBar *)menuBar {
    ECLog(@"%@",[NSString stringWithFormat:@"ECChannelController : channel %d Selected", index]);
    NSArray *viewsToRemove = [_containerView subviews];
    for (UIView *v in viewsToRemove) {
        [v removeFromSuperview];
    }
    
    [_containerView addSubview:((UIViewController*)_viewControllers[index]).view];
    [((UMNavigationController*)_viewControllers[index]).rootViewController setWantsFullScreenLayout:YES];
}

//< Optional
- (CGFloat)itemWidthAtIndex:(NSUInteger)index inMenuBar:(LightMenuBar *)menuBar {
    if (_itemCount<=5) {
        return (validWidth())/_itemCount;

    }else{
        return 64.0;
    }
}

/****************************************************************************/

/**< Top and Bottom Padding, by Default 5.0f */
- (CGFloat)verticalPaddingInMenuBar:(LightMenuBar *)menuBar {
    CGFloat vPadding = [(NSNumber*)[self.styles objectForKey:@"vpadding"] floatValue];
    if (vPadding) {
        return vPadding;
    }
    return 0.0f;
}

/**< Left and Right Padding, by Default 5.0f */
- (CGFloat)horizontalPaddingInMenuBar:(LightMenuBar *)menuBar {
    CGFloat hPadding = [(NSNumber*)[self.styles objectForKey:@"hpadding"] floatValue];
    if (hPadding) {
        return hPadding;
    }
    return 0.0f;
}

/**< Corner Radius of the background Area, by Default 5.0f */
- (CGFloat)cornerRadiusOfBackgroundInMenuBar:(LightMenuBar *)menuBar {
    CGFloat barCorner = [(NSNumber*)[self.styles objectForKey:@"barcorner"] floatValue];
    if (barCorner) {
        return barCorner;
    }
    return 0.0f;
}

- (UIColor *)colorOfBackgroundInMenuBar:(LightMenuBar *)menuBar {
    NSString* bgColor = [self.styles objectForKey:@"channelBg"];
    if (bgColor) {
        return [UIColor colorWithString:bgColor];
    }
    return [UIColor lightGrayColor];
}

//< For Button
/****************************************************************************/

/**< Corner Radius of the Button highlight Area, by Default 5.0f  */
- (CGFloat)cornerRadiusOfButtonInMenuBar:(LightMenuBar *)menuBar {
    CGFloat itemCorner = [(NSNumber*)[self.styles objectForKey:@"itemcorner"] floatValue];
    if (itemCorner) {
        return itemCorner;
    }
    return 0.0f;
}

- (UIColor *)colorOfButtonHighlightInMenuBar:(LightMenuBar *)menuBar {
    NSString* color = [self.styles objectForKey:@"itemBgSelected"];
    if (color) {
        return [UIColor colorWithString:color];
    }
    return [UIColor whiteColor];
}

- (UIColor *)colorOfTitleNormalInMenuBar:(LightMenuBar *)menuBar {
    NSString* color = [self.styles objectForKey:@"itemTitleColor"];
    if (color) {
        return [UIColor colorWithString:color];
    }
    return [UIColor whiteColor];
}

- (UIColor *)colorOfTitleHighlightInMenuBar:(LightMenuBar *)menuBar {
    NSString* color = [self.styles objectForKey:@"itemTitleColorSelected"];
    if (color) {
        return [UIColor colorWithString:color];
    }
    return [UIColor blackColor];
}

- (UIFont *)fontOfTitleInMenuBar:(LightMenuBar *)menuBar {
    CGFloat size = [(NSNumber*)[self.styles objectForKey:@"itemTitleSize"] floatValue];
    if (size) {
       return [UIFont systemFontOfSize:size];
    }
    return [UIFont systemFontOfSize:15.0f];
}


//< For Seperator
/****************************************************************************/

///**< Color of Seperator, by Default White */
- (UIColor *)seperatorColorInMenuBar:(LightMenuBar *)menuBar {
    NSString* color = [self.styles objectForKey:@"seperatorColor"];
    if (color) {
        return [UIColor colorWithString:color];
    }
    return [UIColor whiteColor];
}

/**< Width of Seperator, by Default 1.0f */
- (CGFloat)seperatorWidthInMenuBar:(LightMenuBar *)menuBar {
    CGFloat width = [(NSNumber*)[self.styles objectForKey:@"seperatorWidth"] floatValue];
    if (width) {
        return width;
    }
    return 0.0f;
}

/**< Height Rate of Seperator, by Default 0.7f */
- (CGFloat)seperatorHeightRateInMenuBar:(LightMenuBar *)menuBar {
    
    return 0.7f;
}




@end
