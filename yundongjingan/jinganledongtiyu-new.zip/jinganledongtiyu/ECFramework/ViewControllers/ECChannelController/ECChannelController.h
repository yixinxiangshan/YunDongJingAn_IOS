//
//  ECChannelController.h
//  DemoECEcloud
//
//  Created by EC on 3/14/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECBaseViewController.h"
#import "LightMenuBar.h"
#import "LightMenuBarDelegate.h"


@interface ECChannelController : ECBaseViewController <LightMenuBarDelegate>

@property (nonatomic, strong) LightMenuBar* channelBar;
@property (nonatomic, assign) NSInteger itemCount;
@property (nonatomic, strong) UIView* containerView;
@property (nonatomic, strong) NSMutableArray* viewControllers;
@property (nonatomic, strong) NSMutableArray* dataSource;

@end
