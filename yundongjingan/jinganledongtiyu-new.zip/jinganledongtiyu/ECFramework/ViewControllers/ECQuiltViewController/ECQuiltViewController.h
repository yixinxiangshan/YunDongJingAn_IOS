//
//  ECQuiltViewController.h
//  JingAnWeekly
//
//  Created by Angel on 13-5-25.
//  Copyright (c) 2013年 ecloud. All rights reserved.
//

#import "UIKit/UIKit.h"
#import "ECBaseViewController.h"
#import "TMQuiltView.h"
#import "EGORefreshTableHeaderView.h"
#import "EGORefreshTableFooterView.h"

enum PullingDirectionType : NSInteger {
    ePullingDirectionUp = 0,
    ePullingDirectionBottom,
};
    
@interface ECQuiltViewController : ECBaseViewController<TMQuiltViewDataSource, TMQuiltViewDelegate, EGORefreshTableDelegate,UIScrollViewDelegate>
{
    //Pulling for refresh or reload
    //EGOHeader
    EGORefreshTableHeaderView *_refreshHeaderView;
    //EGOFoot
    EGORefreshTableFooterView *_refreshFooterView;
    //
    BOOL _reloading;
}
@property (nonatomic, retain) TMQuiltView *quiltView;


@property (nonatomic, strong) NSString* cellId;
@property (nonatomic, strong) NSString* contentIdKey;
@property (nonatomic, assign) BOOL isNeedRefresh;
@property (nonatomic,strong) NSMutableArray* dataSource;
@property (nonatomic,strong) NSMutableArray* pullingData;

@property (nonatomic, assign) enum PullingDirectionType pullingtDirection;    // 拖动的方向

@end
