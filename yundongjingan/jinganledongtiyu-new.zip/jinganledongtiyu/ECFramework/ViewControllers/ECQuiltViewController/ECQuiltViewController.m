//
//  TMQuiltView
//  JingAnWeekly
//
//  Created by Angel on 13-5-25.
//  Copyright (c) 2013年 ecloud. All rights reserved.
//


#import "ECQuiltViewController.h"

#import "ECQuiltViewCell.h"

#define TAG @"ECQuiltViewController"


@interface ECQuiltViewController ()

@property (nonatomic, retain) NSArray *images;
@property  CGFloat cellHeight;
@end

@implementation ECQuiltViewController
const CGFloat ratioOfImage = 1.33 ;
@synthesize images = _images;
@synthesize  cellHeight ;

- (void)dealloc {
     _images = nil;
}

#pragma mark - UIViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self showQuiltView];
    [self initData];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

#pragma mark - QuiltViewControllerDataSource

- (NSInteger)quiltViewNumberOfCells:(TMQuiltView *)TMQuiltView {
    return self.dataSource.count;
}

- (TMQuiltViewCell *)quiltView:(TMQuiltView *)quiltView cellAtIndexPath:(NSIndexPath *)indexPath {
    id dataItem = [self.dataSource objectAtIndex:indexPath.row];
    
    TMQuiltViewCell *cell = (TMQuiltViewCell *)[quiltView dequeueReusableCellWithReuseIdentifier:@"QuiltViewCell"];
    if (!cell) {
        cell = [[TMQuiltViewCell alloc] initWithReuseIdentifier:@"QuiltViewCell"];
    }
    
//  图片
    NSString* imageName = [dataItem objectForKey:[self.configs objectForKey:@"imageKey"]];
    NSString* imageuri = nil ;
    ECImageContainer *imageContainer = [[ECImageContainer alloc] initWithFrame:CGRectMake(0, 0, self.quiltView.cellWidth,self.quiltView.cellWidth*ratioOfImage)];
    [imageContainer setImage:[UIImage imageNamed:kDefaultImage]];
    if (imageName && ![imageName isEqual:@""]) {
        imageuri = [ECUriUtil getSmallImageUrl:imageName];
        [imageContainer updateWithNormalImageURI:imageuri];
        [imageContainer setClipsToBounds:YES];
    }
    [cell addSubview:imageContainer];
//  说明
    NSString *labelText = [dataItem objectForKey:[self.configs objectForKey:@"contentKey"]];
    UILabel *label = [[UILabel alloc] init];
    [label setWidth:self.quiltView.cellWidth];
    [label setNumberOfLines:0];
    [label setFont:[UIFont fontWithName:@"Arial" size:11]];
    [label setText:labelText];
    [label sizeToFit];
    [label setFrame:CGRectMake(0, self.quiltView.cellWidth*ratioOfImage, self.quiltView.cellWidth, label.height)];
    cellHeight = label.height ;
    [cell addSubview:label];
    
    [cell setFrame:CGRectMake(0, 0, self.quiltView.cellWidth, self.quiltView.cellWidth*ratioOfImage+label.height)];
    
    return cell;
}


#pragma mark - TMQuiltViewDelegate

- (NSInteger)quiltViewNumberOfColumns:(TMQuiltView *)quiltView {
    
    return 3 ;
}

- (CGFloat)quiltView:(TMQuiltView *)quiltView heightForCellAtIndexPath:(NSIndexPath *)indexPath {
    return [self quiltView:quiltView cellAtIndexPath:indexPath].frame.size.height;
}

-(void)showQuiltView
{
    _quiltView = [[TMQuiltView alloc] initWithFrame:CGRectZero];
    _quiltView.delegate = self;
    _quiltView.dataSource = self;
    _quiltView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    self.view = _quiltView ;
    self.quiltView.backgroundColor = [UIColor blackColor];

    [self createHeaderView];
//    [self setFooterView];
    [self performSelector:@selector(finishedLoadData) withObject:nil afterDelay:0.3f];
}
/* =====================================================================
 *  设置下拉刷新、上拖加载更多方法
 */
#pragma mark -
#pragma mark EGORefreshTableDelegate Methods

//刷新调用的方法
-(void)refreshView{
    [self freshData:YES];
    [self finishedLoadData];
}
//加载调用的方法
-(void)getNextPageView{
    [self removeFooterView];
    _pullingtDirection = ePullingDirectionBottom;
    [self loadMore];
    [self finishedLoadData];
}
-(void)finishedLoadData{
    [self finishReloadingData];
    [self setFooterView];
}
- (void)egoRefreshTableDidTriggerRefresh:(EGORefreshPos)aRefreshPos{
    if (aRefreshPos == EGORefreshHeader) {
        // pull down to refresh data
        [self performSelector:@selector(refreshView) withObject:nil afterDelay:0.3];
    }else if(aRefreshPos == EGORefreshFooter){
        // pull up to load more data
        [self performSelector:@selector(getNextPageView) withObject:nil afterDelay:0.3];
    }
}
- (NSDate*)egoRefreshTableDataSourceLastUpdated:(UIView*)view{
	
	return [NSDate date]; // should return date data source was last changed
	
}
- (BOOL)egoRefreshTableDataSourceIsLoading:(UIView*)view{
	
	return _reloading; // should return if data source model is reloading
	
}

/*  添加refreshHeaderView 与 refreshFooterView
 */
#pragma mark
#pragma methods for creating and removing the header view

-(void)createHeaderView{
    if (_refreshHeaderView && [_refreshHeaderView superview]) {
        [_refreshHeaderView removeFromSuperview];
    }
	_refreshHeaderView = [[EGORefreshTableHeaderView alloc] initWithFrame:
                          CGRectMake(0.0f, 0.0f - self.view.bounds.size.height,
                                     self.view.frame.size.width, self.view.bounds.size.height)];
    _refreshHeaderView.delegate = self;
    _refreshHeaderView.backgroundColor = [UIColor blackColor];
	[self.quiltView addSubview:_refreshHeaderView];
    
    [_refreshHeaderView refreshLastUpdatedDate];
}

-(void)removeHeaderView{
    if (_refreshHeaderView && [_refreshHeaderView superview]) {
        [_refreshHeaderView removeFromSuperview];
    }
    _refreshHeaderView = nil;
}

-(void)setFooterView{
    // if the footerView is nil, then create it, reset the position of the footer
    CGFloat height = MAX(self.quiltView.contentSize.height, self.quiltView.frame.size.height);
    if (_refreshFooterView && [_refreshFooterView superview]) {
        // reset position
        _refreshFooterView.frame = CGRectMake(0.0f,
                                              height,
                                              self.quiltView.frame.size.width,
                                              self.view.bounds.size.height);
    }else {
        // create the footerView
        _refreshFooterView = [[EGORefreshTableFooterView alloc] initWithFrame:
                              CGRectMake(0.0f, height,
                                         self.quiltView.frame.size.width, self.view.bounds.size.height)];
        _refreshFooterView.delegate = self;
        [self.quiltView addSubview:_refreshFooterView];
    }
    _refreshFooterView.backgroundColor = [UIColor blackColor];
    if (_refreshFooterView) {
        [_refreshFooterView refreshLastUpdatedDate];
    }
}

-(void)removeFooterView{
    if (_refreshFooterView && [_refreshFooterView superview]) {
        [_refreshFooterView removeFromSuperview];
    }
    _refreshFooterView = nil;
}

#pragma mark -
#pragma mark method that should be called when the refreshing is finished
- (void)finishReloadingData{
	
	//  model should call this when its done loading
	_reloading = NO;
    
	if (_refreshHeaderView) {
        [_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.quiltView];
    }
    
    if (_refreshFooterView) {
        [_refreshFooterView egoRefreshScrollViewDataSourceDidFinishedLoading:self.quiltView];
    }
    
    // overide, the actula reloading tableView operation and reseting position operation is done in the subclass
}

#pragma mark -
#pragma mark UIScrollViewDelegate Methods

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
	if (_refreshHeaderView) {
        [_refreshHeaderView egoRefreshScrollViewDidScroll:scrollView];
    }
	
	if (_refreshFooterView) {
        [_refreshFooterView egoRefreshScrollViewDidScroll:scrollView];
    }
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
	if (_refreshHeaderView) {
        [_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
    }
	
	if (_refreshFooterView) {
        [_refreshFooterView egoRefreshScrollViewDidEndDragging:scrollView];
    }
}
/*
 *  ＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
 */

/*
 *加载数据
 */
-(void)initData
{
    self.styles = [self.configs objectForKey:@"style"];
    self.cellId = [self.styles objectForKey:@"cellId"];
    _isNeedRefresh = YES;
    if (nil != [self.configs objectForKey:@"isNeedRefresh"] && ![@"" isEqualToString:[self.configs objectForKey:@"isNeedRefresh"]]) {
        _isNeedRefresh = [(NSNumber*)[self.configs objectForKey:@"isNeedRefresh"] boolValue];
    }
    self.contentIdKey = [self.configs objectForKey:@"contentIdKey"];
    
    if (nil != [self.query objectForKey:@"title"]) {
        self.navigationItem.title = [self.query objectForKey:@"title"];
    }
    
    self.dataSource = [NSMutableArray new];
    [self requestData];
    

}

- (void)requestData{
    self.isLocalData = [(NSNumber*)[self.configs objectForKey:@"isLocalData"] boolValue];
    if (self.isLocalData == NO) {
        if (nil != [self.query objectForKey:@"requestId"] ) {
            self.requestId = [self.query objectForKey:@"requestId"];
        }
        //网络数据
        NSDictionary* netDataRelevant = [self.configs objectForKey:@"netDataRelevant"];
        if (nil != [netDataRelevant objectForKey:@"requestId"] && ![@"" isEqualToString:[netDataRelevant objectForKey:@"requestId"]]) {
            self.requestId = [netDataRelevant objectForKey:@"requestId"];
        }
        self.requestIdKey = [netDataRelevant objectForKey:@"requestIdKey"];
        self.method = [netDataRelevant objectForKey:@"method"];
        
        if (nil==self.method || [@"" isEqualToString:self.method]) {
            ECLog(@"%@ configs error: method is null!",NSStringFromClass([self class]));
        }
        
        [self freshData:NO];
        
    }else{
        //本地数据
        self.dataSource = [[self.configs objectForKey:@"localData"] objectForKey:@"dataList"];
        if (nil == self.dataSource || self.dataSource.count<1) {
            ECLog(@"%@ configs error: loacaldata is null!",NSStringFromClass([self class]));
        }else{
//            [self showQuiltView];
        }
        
    }
    
}

- (void)handleRequestData:(NSData*)data{
    [super handleRequestData:data];
    
    id tempData = nil;
    //处理数据
    id obj = [ECJsonParser objectWithJsonData:data];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        tempData = [obj valueForKey:@"data"];
    }
    if (tempData && [tempData isNSxxxClass:[NSDictionary class]]) {
        id dataArray = [tempData objectForKey:[self.configs objectForKey:@"listKey"]];
        if (dataArray && [dataArray isNSxxxClass:[NSArray class]]) {
            [self.dataSource removeAllObjects];
            [self.dataSource addObjectsFromArray:dataArray];
            
            //  R.oshan Label
            
            NSLog(@"%@  data has done , reloadData for View  %@",TAG,self.quiltView);
            [self.quiltView reloadData];
        }
    }else{
        //TODO: 弹出数据出错！
    }
    
}

//loading more
- (void)loadMore
{
    _pullingtDirection = ePullingDirectionBottom;
    NSString* lastId = nil;
    if (self.dataSource && self.dataSource.count > 0) {
        lastId = [[self.dataSource lastObject] objectForKey:self.contentIdKey];//获取现有数据中 最下面一条数据的id
    }else{
        lastId = @"0";
    }
    if (_isNeedRefresh) {
        [self sendReqeustWithID:lastId];
    }
}
#pragma mark -- 请求网络获取刷新 / 更多
- (void)sendReqeustWithID:(NSString *)ID{
    if (nil == ID || [ID isEmpty]) {
        return ;
        //        [self requestData];
    }else{
        NSMutableDictionary* params = [NSMutableDictionary new];
        [params setObject:self.method forKey:@"method"];
        [params setObject:self.requestId forKey:self.requestIdKey];
        [params setValue:ID forKey:@"lastid"];
        [params setValue:@"id" forKey:@"orderbyname"];
        if (self.pullingtDirection == ePullingDirectionUp) {
            //下拉刷新
            [params setValue:@"asc" forKey:@"orderbytype"];
        }else{
            [params setValue:@"desc" forKey:@"orderbytype"];
            [params setValue:@"20" forKey:@"pagesize"];
        }
        [params setValue:@"" forKey:@"titlename"];
        [params setValue:@"" forKey:@"ismycontent"];
        [params setValue:listByType() forKey:@"method"];
        
        
        FormDataRequest* request = [FormDataRequest requestNetURI:API_URL
                                                           params:params
                                                         delegate:self
                                                 finishedSelector:@selector(getMoreSuccess:)
                                                     failSelector:@selector(webRequestFailed:)];
        if (request) {
            [[NetRequestManager sharedInstances] addOperation:request];
            [self showLoading:nil];
        }
        
    }
    
}

- (void)getMoreSuccess:(ASIHTTPRequest*)request{
    [self removeLoading];
    id obj = [ECJsonParser objectWithJsonString:[request responseString]];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        ECLog(@"%@", [obj description]);
        id data = [obj valueForKey:@"data"];
        if (data && [data isNSxxxClass:[NSDictionary class]]) {
            self.pullingData = [data objectForKey:[self.configs objectForKey:@"listKey"]];
            
            if ([self.pullingData count] <= 0) {
//                [self finishedLoadingWithMessage:@"没有更多了"];
                return;
            }
            
            if (self.pullingtDirection == ePullingDirectionUp) {
                if ([self.pullingData count]>20) {
                    [self.dataSource removeAllObjects];
                    for (int i=0; i<20; i++) {
                        [self.dataSource addObject:[self.pullingData objectAtIndex:i]];
                    }
                }else{
                    for (id obj in self.pullingData) {
                        [self.dataSource insertObject:obj atIndex:0];
                        
                    }
                }
            } else {
                for (id obj in self.pullingData) {
                    
                    [self.dataSource addObject:obj ];
                }
                
                
            }
            
            [self.quiltView reloadData];
            [self finishedLoadData];
            
        }
    }
}


- (void) freshData:(BOOL) isForce{
    ECLog(@"list view start fresh data");
    //网络请求
    NSMutableDictionary* params = [NSMutableDictionary new];
    if (nil != self.requestId && nil != self.requestIdKey && nil != self.method) {
        [params setObject:self.method forKey:@"method"];
        [params setObject:self.requestId forKey:self.requestIdKey];
    }
    if (_isNeedRefresh) {
        [params setValue:@"id" forKey:@"orderbyname"];
        [params setValue:@"desc" forKey:@"orderbytype"];
    }else{
        if (nil != [self.configs objectForKey:@"orderbyname"] && ![@"" isEqualToString:[self.configs objectForKey:@"orderbyname"]]) {
            [params setValue:[self.configs objectForKey:@"orderbyname"] forKey:@"orderbyname"];
        }
        if (nil != [self.configs objectForKey:@"orderbytype"] && ![@"" isEqualToString:[self.configs objectForKey:@"orderbytype"]]) {
            [params setValue:[self.configs objectForKey:@"orderbytype"] forKey:@"orderbytype"];
        }
    }
    if ([self.method isEqualToString:listByType()]) {
        [params setValue:@"" forKey:@"titlename"];
        [params setValue:@"" forKey:@"ismycontent"];
        [params setValue:@"" forKey:@"lastid"];
        [params setValue:@"20" forKey:@"pagesize"];
    }
    
    // add params from config
    NSArray* paramsArray =  [self.netDataRelevant objectForKey:@"params"];
    if (paramsArray && [paramsArray count]) {
        for (id paramItem in paramsArray) {
            if ([paramItem objectForKey:@"value"] && [paramItem objectForKey:@"key"]) {
                [params setValue:[paramItem objectForKey:@"value"]  forKey:[paramItem objectForKey:@"key"]];
            }
            
        }
    }
    
    
    FormDataRequest* request = nil;
    if (isForce) {
        request = [FormDataRequest requestNetURI:API_URL
                                          params:params
                                        delegate:self
                                finishedSelector:@selector(requestFindished:)
                                    failSelector:@selector(webRequestFailed:)];
    }else{
        NSLog(@"%@   ",TAG);
        request = [FormDataRequest requestNetURI:API_URL
                                          params:params
                                        delegate:self
                                finishedSelector:@selector(requestFindished:)
                                    failSelector:@selector(webRequestFailed:)
                                   cacheSelector:@selector(handleRequestData:)];
    }
    
    if (request) {
        
        [[NetRequestManager sharedInstances] addOperation:request];
        
        [self showLoading:nil];
    }
}
/*=======================================================================
 *处理点击事件
 */
#pragma mark - TMQuilt view delegate

- (void)quiltView:(TMQuiltView *)quiltView didSelectCellAtIndexPath:(NSIndexPath *)indexPath
{
//    [self.quiltView deselectCellAtIndexPath:indexPath animated:YES];
    NSString* cellTitle ;
    NSString* tag = @"";
    if ([self.cellId isEqualToString:@"Cell"]) {
        
    }else{
        
    }
    NSLog(@"Do click......");
    NSMutableDictionary* params = [NSMutableDictionary new];
    if (indexPath.section == 0 ) {
        NSDictionary* dataItem = [self.dataSource objectAtIndex:indexPath.row];
        // gen params pass to next ctrl
        cellTitle = [dataItem objectForKey:[self.configs objectForKey:@"titleKey"]];
        [params setObject:[dataItem objectForKey:[self.configs objectForKey:@"contentIdKey"]] forKey:@"requestId"];
        
    }else {
//        cellTitle = [quiltView cellForRowAtIndexPath:indexPath].textLabel.text;
    }
    [params setObject:cellTitle forKey:@"navTitle"];
    
    NSURL *PlistURL = [[NSBundle mainBundle] URLForResource:@"SpeEventTagConfig" withExtension:@"plist"];
    NSDictionary* speEventTag =  [NSDictionary dictionaryWithContentsOfURL:PlistURL];
    NSEnumerator* enumerator = [speEventTag keyEnumerator];
    for (NSString *key in enumerator) {
        if ([cellTitle rangeOfString:key].location != NSNotFound) {
            tag = [speEventTag objectForKey:key];
        }
    }
    NSLog(@"Message : %@ ",[NSString stringWithFormat:@"%@.%@.itemClick%@",self.instanceName,NSStringFromClass([self class]),tag]);
    
    [[NSNotificationCenter defaultCenter] postNotificationName:[NSString stringWithFormat:@"%@.%@.itemClick%@",self.instanceName,NSStringFromClass([self class]),tag] object:nil userInfo:params];
    
}

@end
