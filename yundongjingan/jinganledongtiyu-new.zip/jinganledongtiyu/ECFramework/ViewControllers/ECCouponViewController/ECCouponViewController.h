//
//  ECCouponViewController.h
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-12.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "ECDetailViewController.h"

@interface ECCouponViewController : ECDetailViewController

@end

//@interface ECCountDownView : UIView
//@property (strong, nonatomic) NSDate* endTime;

//@end