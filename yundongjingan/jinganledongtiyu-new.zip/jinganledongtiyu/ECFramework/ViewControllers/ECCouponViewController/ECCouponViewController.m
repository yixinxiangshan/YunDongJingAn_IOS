//
//  ECCouponViewController.m
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-12.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "ECCouponViewController.h"
#import "ECImageContainer.h"
#define TAG "ECCouponViewController"

@interface ECCouponViewController ()

@property CGFloat viewHeight;

@property (strong, nonatomic) ECImageContainer* image;
@property (strong, nonatomic) UIButton* couponButton;
@property (strong, nonatomic) UIView* labelView_1;
@property (strong, nonatomic) UIView* lavelView_2;

@property (strong, nonatomic) NSString* couponTime;
@property (strong, nonatomic) NSString* couponPlace;
@property (strong, nonatomic) NSString* couponImage;

@property (strong, nonatomic) NSString* couponNumber;

@end

@implementation ECCouponViewController
@synthesize image;
@synthesize couponButton;
@synthesize viewHeight;
@synthesize labelView_1;
@synthesize lavelView_2;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(doAction:) name:@"ECLoginController.loginSuccess" object:nil];
   
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)handleRequestData:(NSData*)data
{
    [super handleRequestData:data];
    
    self.dataDic = [self.dataDic objectForKey:[self.configs valueForKey:@"dataKey"]];
    self.couponTime = [self.dataDic valueForKey:[self.configs valueForKey:@"timeKey"]];
    self.couponPlace = [self.dataDic valueForKey:[self.configs valueForKey:@"placeKey"]];
    self.couponImage = [self.dataDic valueForKey:[self.configs valueForKey:@"imageKey"]];
    
    [self.view removeAllSubViews];
    [self showContentView];
}
-(void)updateCouponButton
{
    [couponButton setTitle:self.couponNumber forState:UIControlStateNormal];
    [couponButton setBackgroundImage:[UIImage imageNamed:@"couponbutton_applydone.png"] forState:UIControlStateNormal];
    [couponButton setEnabled:NO];
}
-(void)showContentView
{
    viewHeight = 0;
    image = [[ECImageContainer alloc] initWithFrame:CGRectMake(0, viewHeight, 320, 240)];
    if (self.couponImage == nil) {
        [image updateWithNormalImage:[UIImage imageNamed:@"defaultImage.jpg"] hightedImage:nil];
    }else{
        [image updateWithNormalImageURI:self.couponImage];
    }
    
    [self.view addSubview:image];
    viewHeight += 10 + image.frame.size.height;
    //申领按钮
    couponButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [couponButton setFrame:CGRectMake(10,  viewHeight, 300, 44)];
    [couponButton setBackgroundImage:[UIImage imageNamed:@"couponbutton_normal.png"] forState:UIControlStateNormal];
    [couponButton setTitle:@"立即申请" forState:UIControlStateNormal];
    [couponButton addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:couponButton];
    viewHeight += 54 ;
    
    //信息
    //活动地点
    labelView_1 = [self labelView:@"活动时间" content:self.couponPlace withAction:NO];
    [labelView_1 setFrame:CGRectMake(10, viewHeight, 300, 44)];
    [self.view addSubview:labelView_1];
    viewHeight += 54 ;
    
    lavelView_2 = [self labelView:@"活动地点" content:self.couponTime withAction:YES];
    [lavelView_2 setFrame:CGRectMake(10, viewHeight, 300, 44)];
    [self.view addSubview:lavelView_2];
    
}

- (UIView *) labelView:(NSString *)title content:(NSString *)content withAction:(BOOL)isWithAction
{
    UIView* view = [[UIView alloc] initWithFrame:CGRectMake(10, 0, 300, 44)];
    
    UILabel* titleLabel = [[UILabel alloc] init];
    [titleLabel setText:title];
    [titleLabel sizeToFit];
    [titleLabel setFrame:CGRectMake(20, 22-titleLabel.frame.size.height, titleLabel.frame.size.width, titleLabel.frame.size.height)];
    [view addSubview:titleLabel];
    
    UILabel* contentLabel = [[UILabel alloc] init];
    [contentLabel setText:content];
    [contentLabel sizeToFit];
    [contentLabel setFrame:CGRectMake(160, 22-contentLabel.frame.size.height, contentLabel.frame.size.width, contentLabel.frame.size.height)];
    [view addSubview:contentLabel];
    
    if (isWithAction) {
        UITapGestureRecognizer* doAction = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doAction:)];
        [view addGestureRecognizer:doAction];
    }
    
    return view;
}
-(void) doAction:(id)sender
{
    NSMutableDictionary* params = [NSMutableDictionary new];
    [params setValue:self.requestId forKey:@"contentid"];
    [params setValue:@"activity.applycoupon" forKey:@"method"];
    
    FormDataRequest* request = [FormDataRequest requestNetURI:API_URL
                                                       params:params
                                                     delegate:self
                                             finishedSelector:@selector(applyDone:)
                                                 failSelector:@selector(webRequestFailed:)];
    if (request) {
        [[NetRequestManager sharedInstances] addOperation:request];
        [self showLoading:nil];
    }
}
-(void)applyDone:(FormDataRequest*)request{
    
    NSString* reponseString = [request responseString];
    ECLog(@"%s responseString:%@",TAG,reponseString);
    if ([reponseString rangeOfString:@"\"error\""].location != NSNotFound || [reponseString rangeOfString:@"\"Error\""].location != NSNotFound) {
        [[ECSpecRequest shareInstance] showError:reponseString];
        //        NSLog(@"response error:%@",reponseString);
    }
    // 处理完成后 移除加载框
    [self removeLoading];
    
    id tempData = nil;
    //处理数据
    id obj = [ECJsonParser objectWithJsonData:request.rawResponseData];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        tempData = [obj valueForKey:@"data"];
    }
    if (tempData && [tempData isNSxxxClass:[NSDictionary class]]) {
        self.couponNumber = [tempData valueForKey:[self.configs valueForKey:@"couponNumberKey"]];
        [self updateCouponButton];
    }
}
@end

//@interface ECCountDownView ()
//@property (nonatomic) long secondsLeft;
//@property (nonatomic, strong) NSTimer* timer;
//@property (strong, nonatomic) UILabel* countDownLabel;
//@end
//
//@implementation ECCountDownView
//#define LabelFormat @"%i 天 %i 小时 %i 分钟 %i 秒"
//
//- (id) initWithFrame:(CGRect)frame
//{
//    self = [super initWithFrame:frame];
//    if (self) {
//        _countDownLabel = [[UILabel alloc] init];
//        [self addSubview:_countDownLabel];
//    }
//    return self;
//}
//
//- (void) setEndTime:(NSDate *)endTime
//{
//    _endTime = endTime;
//    _secondsLeft = [endTime timeIntervalSinceNow];
//    _timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(updateStatus) userInfo:nil repeats:YES];
//}
//- (void)updateStatus
//{
//    if (_secondsLeft == 0) {
//        [_timer invalidate];
//        return;
//    }
//    _secondsLeft --;
//    _countDownLabel.text = [NSString stringWithFormat:LabelFormat,[self getDay],[self getHour],[self getMimute],[self getSecond]];
//    
//    [_countDownLabel sizeToFit];
//    [_countDownLabel setFrame:CGRectMake((self.frame.size.width - _countDownLabel.frame.size.width) / 2.0, (self.frame.size.height - _countDownLabel.frame.size.height) / 2.0, _countDownLabel.frame.size.width, _countDownLabel.frame.size.height)];
//}
//- (NSInteger) getDay
//{
//    return  _secondsLeft / 86400;
//}
//- (NSInteger) getHour
//{
//    return _secondsLeft % 86400 / 3600;
//}
//- (NSInteger) getMimute
//{
//    return _secondsLeft % 3600 / 60;
//}
//- (NSInteger) getSecond
//{
//    return _secondsLeft % 60;
//}
//@end