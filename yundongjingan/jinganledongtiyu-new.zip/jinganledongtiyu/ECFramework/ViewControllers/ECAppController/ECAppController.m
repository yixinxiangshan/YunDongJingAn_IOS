//
//  ECAppController.m
//  DemoECEcloud
//
//  Created by EC on 3/6/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECAppController.h"
#import "ECNetRequest.h"
#import "ECKeyChain.h"
#import "NSObjectExtends.h"
#import "Extends.h"

@interface ECAppController ()

@end

@implementation ECAppController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    
    [self.navigationController setNavigationBarHidden:YES];
	[self.view setBackgroundColor:[UIColor lightGrayColor]];
//    [self showLoading:@"启动中..."];
    
    //判断网络是否存在
    if (![NetRequestManager networdEnabled]) {
        [self exitApp];
        return ;
    }
//    if (EC_DEBUG_ON) {
//        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"showGuidanceView"];
//        [[NSUserDefaults standardUserDefaults] synchronize];
//    }
    
    NSString *showGuidanceView = [[NSUserDefaults standardUserDefaults] objectForKey:@"showGuidanceView"];
    
    if (![showGuidanceView isEqualToString:@"showGuidanceView"]) {
        //欢迎界面
        UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:[UIScreen mainScreen].bounds];
        [scrollView setContentSize:scrollView.frame.size];
        scrollView.showsHorizontalScrollIndicator = NO;
        scrollView.showsVerticalScrollIndicator = NO;
        scrollView.pagingEnabled = YES;
        [self.view addSubview:scrollView];
        
        NSString *hFlag = @"";
        ECLog(@"screen height : %f",[UIScreen mainScreen].bounds.size.height);
        if ([UIScreen mainScreen].bounds.size.height == 568) {
            hFlag = @"-568h";
        }
        
        int imageCount = 0;
        while (YES) {
            UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"Default%i%@",imageCount,hFlag]];
            if (!image) {
                break;
            }
            imageCount ++;
            
            UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
            [imageView setCenter:CGPointMake(scrollView.frame.size.width * ((float)imageCount - 0.5), scrollView.frame.size.height/2)];
            
            [scrollView addSubview:imageView];
        }
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width * imageCount, scrollView.frame.size.height)];
        
        UIButton *button = [[UIButton alloc] init];
        [button.titleLabel setFont:[UIFont systemFontOfSize:19]];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [button setFrame:CGRectMake(0, 0, 300, 44)];
        [button setCenter:CGPointMake(scrollView.frame.size.width * ((float)imageCount - 0.5), scrollView.frame.size.height - 44)];
        
        [button setTitle:@"开始使用" forState:UIControlStateNormal];
        UIImage *rightArrowImage = [UIImage imageNamed:@"right_arrow.png"];
        [button setImage:rightArrowImage forState:UIControlStateNormal];
        
        if (IOS7_OR_LATER) {
            [button setTintColor:[UIColor whiteColor]];
        }
        //布局 title image
        [button setTitleEdgeInsets:UIEdgeInsetsMake(0, - rightArrowImage.size.width, 0, rightArrowImage.size.width + 5 )];
        [button setImageEdgeInsets:UIEdgeInsetsMake(0, button.titleLabel.frame.size.width, 0, - button.titleLabel.frame.size.width - 5)];
        
//        [button setBackgroundColor:[UIColor redColor]];
        
        [scrollView addSubview:button];
        
        [button addTarget:self action:@selector(startApp) forControlEvents:UIControlEventTouchUpInside];
    }else{
        [self GenInit];
    }
}

- (void) startApp
{
    [[NSUserDefaults standardUserDefaults] setObject:@"showGuidanceView" forKey:@"showGuidanceView"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [self GenInit];
}

- (void)GenInit{
    NSLog(@"GenInit : init.....");
    if (nil != [self.configs objectForKey:@"apiKey"]) {
        [ECKeyChain saveApiKey:[self.configs objectForKey:@"apiKey"]];
    }
    if (nil != [self.configs objectForKey:@"clientSecret"]) {
        [ECKeyChain saveClientSecret:[self.configs objectForKey:@"clientSecret"]];
    }
    //TODO: 删除清除用户
//    [ECKeyChain saveUserName:nil password:nil deviceID:[UIDevice UDID] accessToken:nil];
//    [ECKeyChain saveUserName:[ECKeyChain userName] password:[ECKeyChain password] deviceID:[UIDevice UDID] accessToken:nil];
    if (nil == [ECKeyChain accessToken] || NULL ==[ECKeyChain accessToken]) {
        [self getDefaultAccessToken];
    }else{
        [self startMainViewController];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
// ---------------------------------------------------------------------------------------------------------------------
#pragma mark - 获取默认token
- (void)getDefaultAccessToken{
    if (![NetRequestManager networdEnabled]) {
        //  TODO : 没有网络退出程序
        [self exitApp];
        return;
    }
    NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"device", @"grant_type",[UIDevice UDID], @"devicenumber",tokenMethod(),@"method", [self.configs objectForKey:@"apiKey"],@"client_id",[self.configs objectForKey:@"apiKey"],@"api_key", nil];
    
    FormDataRequest* request = [FormDataRequest requestNetURI:TOKEN_URL
                                                       params:params
                                                     delegate:self
                                             finishedSelector:@selector(defaultTokenFinished:)
                                                 failSelector:@selector(tokenRequestFailed:)];
    if (request) {
        [[NetRequestManager sharedInstances] addOperation:request];
    }
    
}
#pragma mark - 默认token获取成功 及失败
- (void)defaultTokenFinished:(FormDataRequest*)request{
    NSString* responseString = request.responseString;
    ECLog(@"token response: %@", responseString);
    if ([responseString rangeOfString:@"\"error\""].location != NSNotFound || [responseString rangeOfString:@"\"Error\""].location != NSNotFound) {
        [[ECSpecRequest shareInstance] showError:responseString];
        return;
    }
    id obj = [ECJsonParser objectWithJsonString:[request responseString]];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        if ([obj valueForKey:@"access_token"]) {
            [ECKeyChain saveUserName:[ECKeyChain userName] password:[ECKeyChain password] deviceID:[UIDevice UDID]
                         accessToken:[obj valueForKey:@"access_token"]];
            if (((BOOL)[self.configs objectForKey:@"needEnterpriseId"]) == YES) {
                //TODO: 弹出输入框
            }else{
                [self startMainViewController];
            }
            return;
        }
    }
    // 拿不到后面就没法继续了
    [self exitApp];
}
// ---------------------------------------------------------------------------------------------------------------------
#pragma mark - 获取token
- (void)getAccessToken{
    if (![NetRequestManager networdEnabled]) {
        //  TODO : 没有网络退出程序
        [self exitApp];
        return;
    }
    
    NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"device", @"grant_type",[UIDevice UDID], @"devicenumber",tokenMethod(),@"method",[ECKeyChain apiKey],@"client_id", nil];
    
    FormDataRequest* request = [FormDataRequest requestNetURI:TOKEN_URL
                                                       params:params
                                                     delegate:self
                                             finishedSelector:@selector(tokenReuestFinished:)
                                                 failSelector:@selector(tokenRequestFailed:)];
    if (request) {
        [[NetRequestManager sharedInstances] addOperation:request];
    }
    
}

#pragma mark - token获取成功 及失败
- (void)tokenReuestFinished:(FormDataRequest*)request{
    NSString* responseString = request.responseString;
    ECLog(@"token response: %@", responseString);
    if ([responseString rangeOfString:@"\"error\""].location != NSNotFound || [responseString rangeOfString:@"\"Error\""].location != NSNotFound) {
        [[ECSpecRequest shareInstance] showError:responseString];
        return;
    }
    id obj = [ECJsonParser objectWithJsonString:[request responseString]];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        if ([obj valueForKey:@"access_token"]) {
            [ECKeyChain saveUserName:[ECKeyChain userName] password:[ECKeyChain password] deviceID:[UIDevice UDID]
                         accessToken:[obj valueForKey:@"access_token"]];
            [self getSonsortList];
            return;
        }
    }
    // 拿不到后面就没法继续了
    [self exitApp];
}
- (void) tokenRequestFailed:(FormDataRequest*)request{
    ECLog(@"获取token失败!!!");
    [self exitApp];
}


// -----------------------------------------------------------------------------------------------------------------------
#pragma mark - 获取sonSortList
- (void)getSonsortList{
    NSDictionary* params = [NSDictionary dictionaryWithObjectsAndKeys:@"0",@"sortid",sonSortList(),@"method", nil];
    
    FormDataRequest* request = [FormDataRequest requestNetURI:API_URL
                                                       params:params
                                                     delegate:self
                                             finishedSelector:@selector(sonSortListFinished:)
                                                 failSelector:@selector(sonSortListFailed:)];
    if (request) {
        [[NetRequestManager sharedInstances] addOperation:request];
        [self showLoading:@"请等待..."];
    }
}
- (void)sonSortListFinished:(FormDataRequest*)request{
    NSString* responseString = request.responseString;
    ECLog(@"token response: %@", responseString);
    if ([responseString rangeOfString:@"\"error\""].location != NSNotFound || [responseString rangeOfString:@"\"Error\""].location != NSNotFound) {
        [[ECSpecRequest shareInstance] showError:responseString];
        return;
    }
    id obj = [ECJsonParser objectWithJsonString:[request responseString]];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        id tempData = [obj valueForKey:@"data"];
        if (tempData && [tempData isNSxxxClass:[NSDictionary class]]) {
            SonList* ss = [[SonList alloc] initWithDictionary:tempData];
            if (ss) {
                NSData *ssData = [NSKeyedArchiver archivedDataWithRootObject:ss];//打包为nsdata型
                [[NSUserDefaults standardUserDefaults] setObject:ssData forKey:@"sonSortList"];
                [[NSUserDefaults standardUserDefaults] synchronize];
            }else{
                //拿不到后面就没法继续了
                [self exitApp];
            }
        }
    }
    [self removeLoading];
}
- (void) sonSortListFailed:(FormDataRequest*)request{
    ECLog(@"获取sonSortList失败!!!");
    [self removeLoading];
    [self exitApp];
}

// -----------------------------------------------------------------------------------------------------------------------
#pragma mark - 启动首界面

- (void)startMainViewController{
    
    [[ECNoticeController shareInstance] checkNotice];
    
//    return;
    
    //Label R.oshan
    NSLog(@"Ｒ.oshan     StartMainView from here");
    UMViewController* mainViewController = (UMViewController*)[[UMNavigationController alloc] initWithRootViewControllerURL:[NSURL URLWithString:[self.configs objectForKey:@"startViewController"]]];
    EC_WINDOW.rootViewController = mainViewController;
//    [self.navigator openURL:[NSURL URLWithString:[self.configs objectForKey:@"startViewController"]]];
    [self removeLoading];
}
@end
