//
//  ECAppController.h
//  DemoECEcloud
//
//  Created by EC on 3/6/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECBaseViewController.h"
#import "Utils.h"

#import "ECNoticeController.h"

@interface ECAppController : ECBaseViewController

@property (nonatomic, strong) NSDictionary* configs;
@end
