//
//  ECViewDeckController.h
//  DemoECEcloud
//
//  Created by EC on 3/6/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "IIViewDeckController.h"
#import "Utils.h"

@interface ECViewDeckController : IIViewDeckController

@property (nonatomic, strong) NSString* configName;
@property (nonatomic, strong) NSString* instanceName;
@property (nonatomic, strong) NSDictionary* configs;


- (void)refreshCenterViewCom:(NSDictionary*)params;
@end
