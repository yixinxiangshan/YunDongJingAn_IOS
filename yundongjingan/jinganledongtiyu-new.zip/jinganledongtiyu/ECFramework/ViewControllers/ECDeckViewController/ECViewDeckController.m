//
//  ECViewDeckController.m
//  DemoECEcloud
//
//  Created by EC on 3/6/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECViewDeckController.h"

@interface ECViewDeckController ()

@end

@implementation ECViewDeckController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
	// Do any additional setup after loading the view.
    _configName = [self.url.params objectForKey:@"configName"];
    _instanceName = _configName;
    if (nil == _configName || [@"" isEqualToString:_configName]) {
        ECLog(@"%@ 参数传递错误：缺少config项",NSStringFromClass([self class]));
        return;
    }else{
        NSURL *PlistURL = [[NSBundle mainBundle] URLForResource:_configName withExtension:@"plist"];
        self.configs =  [NSDictionary dictionaryWithContentsOfURL:PlistURL];
        ECLog(@"%@ configs: %@",NSStringFromClass([self class]),self.configs);
    }
    if (nil == self.configs) {
        [[ECClearApp shareInstance] exitApp:@"程序错误" message:@"退出程序：参数传递错误！"];
    }

    
    if (nil != [self.configs objectForKey:@"leftViewController"] && nil != [self.configs objectForKey:@"centerViewController"]) {
        UMViewController* leftViewController = (UMViewController*)[[UMNavigationController alloc] initWithRootViewControllerURL:[NSURL URLWithString:[self.configs objectForKey:@"leftViewController"]]];
        [self setLeftController:leftViewController];
        UMViewController* centerViewController = (UMViewController*)[[UMNavigationController alloc] initWithRootViewControllerURL:[NSURL URLWithString:[self.configs objectForKey:@"centerViewController"]]];
        [self setCenterController:centerViewController];
    }else{
        ECLog(@"%@ configs error: leftview or centerview is null",NSStringFromClass([self class]));
    }
    if (nil != [self.configs objectForKey:@"rightViewController"] && ![@"" isEqualToString:[self.configs objectForKey:@"rightViewController"]]) {
        UMViewController* rightViewController = (UMViewController*)[[UMNavigationController alloc] initWithRootViewControllerURL:[NSURL URLWithString:[self.configs objectForKey:@"rightViewController"]]];
        [self setRightController:rightViewController];
    }
    
    
    [self setLeftSize:80.0f];
    [self setOpenSlideAnimationDuration:0.15f];
    [self setCloseSlideAnimationDuration:0.25f];
    self.centerhiddenInteractivity = IIViewDeckCenterHiddenUserInteractive;
    [self toggleLeftViewAnimated:YES];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)refreshCenterViewCom:(NSDictionary*)params{
    NSString* centerViewUrlString = [[params objectForKey:@"urlParams"] objectForKey:@"viewUrl"];
    ECLog(@"%@ parsing url : %@ ",NSStringFromClass([self class]),centerViewUrlString);
    NSURL* centerViewUrl = [NSURL URLWithString:[centerViewUrlString stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    UMViewController* centerViewController = (UMViewController*)[[UMNavigationController alloc] initWithRootViewControllerURL:centerViewUrl withQuery:[params objectForKey:@"query"]];
    IIViewDeckController* viewDeckController = (IIViewDeckController*)((UMNavigationController*)EC_WINDOW.rootViewController).rootViewController;
    [viewDeckController setCenterController:centerViewController];
    
}
@end
