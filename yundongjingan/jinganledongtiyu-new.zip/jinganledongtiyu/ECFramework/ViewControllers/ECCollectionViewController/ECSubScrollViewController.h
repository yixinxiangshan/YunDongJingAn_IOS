//
//  ECSubScrollViewController.h
//  jinganledongtiyu
//
//  Created by cww on 13-7-19.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECBaseViewExtendController.h"

@interface ECSubScrollViewController : ECBaseViewExtendController

@end
