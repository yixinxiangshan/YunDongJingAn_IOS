//
//  ECECCollectionViewController.h
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-2.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "ECBaseViewExtendController.h"
#import "ECSubTableViewController.h"

@interface ECCollectionViewController : ECBaseViewExtendController 

@property (nonatomic, strong) ECSubTableViewController* contentView;

@property (nonatomic, strong) NSDictionary* netRequestConfig;
@property (nonatomic, strong) NSDictionary* contentViewData;

-(void)praise:(NSDictionary*)params;
-(void) requestNetData:(NSString *)remoteAddress;
@end
