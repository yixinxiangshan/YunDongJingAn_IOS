//
//  ECSubScrollViewController.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-19.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSubScrollViewController.h"
#import "SubScrollViewHeader.h"

@interface ECSubScrollViewController ()

@property (strong, nonatomic) UIScrollView* scrollView;
@property CGFloat scrollViewContentViewHeight;
@property (strong, nonatomic) NSDictionary* dataSource;
@end

@implementation ECSubScrollViewController
@synthesize scrollView;
@synthesize scrollViewContentViewHeight;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    //网络数据
    
    if (nil != [self.url.params valueForKey:@"requestId"])
    {
        self.requestId = [self.url.params valueForKey:@"requestId"];
    }else if (nil != [self.query objectForKey:@"requestId"] && [self.query objectForKey:@"requestId"] != NULL)
    {
        self.requestId = [self.query objectForKey:@"requestId"];
    }

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showContentView) name:@"freshScrollView" object:nil];
    [self showContentView];
    
    if (nil == self.configs || self.configs == NULL){
        return;
    }
    [self netRequest];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)showContentView
{
    [self.view removeAllSubViews];
    scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, validWidth(), validHeight())];
    
    scrollViewContentViewHeight = 0;
    
    NSArray* itemConfigs = [[self.configs objectForKey:@"localData"] objectForKey:@"dataList"];
    
    for (NSDictionary* itemConfig in itemConfigs) {
        if ([[itemConfig valueForKey:@"isStaticItem"] boolValue]) {
            
            [self addSubView:itemConfig content:self.dataSource];
        }else{
            [self addSubView:itemConfig content:self.dataSource];
        }
    }
    
    if (scrollViewContentViewHeight > validHeight()) {
        [scrollView setContentSize:CGSizeMake(validWidth(), scrollViewContentViewHeight)];
    }
    [self.view addSubview:scrollView];
}

-(void) addSubView:(NSDictionary *)itemConfig content:(NSDictionary *)content
{
    SubScrollViewItem* cell =nil;
    NSString* CellIdentifier = [itemConfig valueForKey:@"itemtype"];
    if ([CellIdentifier isEqualToString:@"oneLineTwoCellItem"])
    {
        cell = (oneLineTwoCellItem*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
        [(oneLineTwoCellItem*)cell initView:content withConfig:itemConfig];
        
    }else if ([CellIdentifier isEqualToString:@"oneLineTwoCellLabel"])
    {
        cell = (oneLineTwoCellLabel*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
        [(oneLineTwoCellLabel*)cell initView:content withConfig:itemConfig];
        
    }
    else if ([CellIdentifier isEqualToString:@"SepratorLine"])
    {
        cell = (SepratorLine*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
    }
    else if ([CellIdentifier isEqualToString:@"noTitleLabel"]){
        cell = (noTitleLabel*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
        [(noTitleLabel*)cell initView:content withConfig:itemConfig];
    }
    else if ([CellIdentifier isEqualToString:@"buttonItem"]){
        cell = (buttonItem*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
        [(buttonItem*)cell initView:content withConfig:itemConfig];
    }
    else if ([CellIdentifier isEqualToString:@"severDataItem"]){
        cell = (severDataItem*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];

        [(severDataItem*)cell initView:content withConfig:itemConfig withId:self.requestId];
        
    }else if ([CellIdentifier isEqualToString:@"imageShowWithDetail"]){
        cell = (imageShowWithDetail*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
        [(imageShowWithDetail*)cell initView:content withConfig:itemConfig];
    }else if ([CellIdentifier isEqualToString:@"oneLineOneCellItem"]){
        cell = (oneLineOneCellItem*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
        [(oneLineOneCellItem*)cell initView:content withConfig:itemConfig];
    }else if ([CellIdentifier isEqualToString:@"twoLineTwoCellItem"]){
        cell = (twoLineTwoCellItem*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
        [(twoLineTwoCellItem*)cell initView:content withConfig:itemConfig];
    }else if ([CellIdentifier isEqualToString:@"messageBoard"]){
        cell = (messageBoard*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
        [(messageBoard*)cell initView:content withConfig:itemConfig];
 
    }else if ([CellIdentifier isEqualToString:@"imageCover"]){
        cell = (imageCover*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
        [(imageCover*)cell initView:content withConfig:itemConfig];
        
        
    }
    
    [cell setFrame:CGRectMake(0, scrollViewContentViewHeight, 320, cell.frame.size.height)];
    scrollViewContentViewHeight += cell.frame.size.height;
    cell.requestId = self.requestId;
    cell.title = self.navTitle;
    [scrollView addSubview:cell];

}
-(void)addSubView:(NSDictionary *)itemConfig
{
    
}
-(void)netRequest
{
    NSMutableDictionary* params = [NSMutableDictionary new];
    self.netDataRelevant = [self.configs objectForKey:@"netDataRelevant"];
    
    [params setValue:self.requestId forKey:[self.netDataRelevant valueForKey:@"requestIdKey"]];
    [params setValue:[self.netDataRelevant valueForKey:@"method"] forKey:@"method"];
    
    FormDataRequest* request = [FormDataRequest requestNetURI:API_URL
                                                       params:params
                                                     delegate:self
                                             finishedSelector:@selector(requestFindished:)
                                                 failSelector:@selector(webRequestFailed:)];
    if (request) {
        [[NetRequestManager sharedInstances] addOperation:request];
        [self showLoading:nil];
    }
    
}

- (void)handleRequestData:(NSData*)data{
    [super handleRequestData:data];
    NSDictionary* dataDic = [[NSDictionary alloc] init];
    id tempData = nil;
    //处理数据
    id obj = [ECJsonParser objectWithJsonData:data];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        tempData = [self getValue:obj forKey:[self.netDataRelevant valueForKey:@"dataKey"]];
    }
    if (tempData && [tempData isNSxxxClass:[NSDictionary class]])
    {
        dataDic = tempData;
    }else{
        if (nil == dataDic) {
            // TODO: 弹出数据出错！
        }
    }
    self.dataSource = dataDic;
    [self showContentView];
    
}


@end
