//
//  ECECCollectionViewController.m
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-2.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "ECCollectionViewController.h"
#import "PraiseView.h"



@interface ECCollectionViewController ()



@end

@implementation ECCollectionViewController
@synthesize netRequestConfig;
@synthesize contentViewData;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    NSLog(@"ECECCollectionViewController start ...");

    [self showContentView];
    
    NSLog(@"%@ : %@",self.class,self.query);
    //网络数据
    if (nil != [self.query objectForKey:@"requestId"]) {
        self.requestId = [self.query objectForKey:@"requestId"];
    }else{
        self.requestId = [[self.configs objectForKey:@"netRequestConfig"] valueForKey:@"requestId"];
    }
    
    [self requestNetData:[NSString stringWithFormat:@"%@",self.requestId]];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) showContentView
{
    
//    NSLog(@"%@ : %@",self.class,self.contentViewData);
    if (self.contentView) {
        [self.contentView.view removeAllSubViews];
    }else{
        self.contentView = [[ECSubTableViewController alloc] initWithConfig:[self.configs objectForKey:@"viewConfig"] content:self.contentViewData];
    }
    
    NSMutableDictionary* params = [NSMutableDictionary new];
//    [params setObject:[NSString stringWithFormat:@"%@",self.requestId] forKey:[netRequestConfig valueForKey:@"idKey"]];
    [params setObject:[NSString stringWithFormat:@"%@",self.requestId] forKey:@"requestId"];
    [params setObject:[NSString stringWithFormat:@"%@",self.navigationItem.title] forKey:@"historyTitle"];
    self.contentView.requestParams = params ;
    
    
//    [self.contentView.view setFrame:CGRectMake(0, 0, validWidth(), validHeight())];
    [self.contentView.view setFrame:self.view.bounds];
 
//    self.contentView.delegate = self ;
    
    [self.view addSubview:self.contentView.view];
    self.buttonEnable = YES;

}

-(void)praise:(NSDictionary*)params
{
    NSLog(@"%@  Praise Content : %@",self.class,[params objectForKey:@"urlParams"]);
    PraiseView* praiseView = [[PraiseView alloc] initWithFrame:CGRectMake(0, 0, validWidth(), validHeight()) andParams:[params objectForKey:@"urlParams"]];
    [praiseView show];

}

#pragma net request
-(void) requestNetData:(NSString *)remoteAddress
{
    if (remoteAddress == nil || [remoteAddress isEqual:@""]) {
        return;
    }
    if ([[self.configs valueForKey:@"isLocalData"] boolValue]) {
        return;
    }
    netRequestConfig = [self.configs objectForKey:@"netRequestConfig"];
    
    NSMutableDictionary* params = [NSMutableDictionary new];
    if ((nil != [netRequestConfig valueForKey:@"idKey"]) && (nil != [netRequestConfig valueForKey:@"requestMethod"])) {
        [params setObject:remoteAddress forKey:[netRequestConfig valueForKey:@"idKey"]];

        [params setObject:[netRequestConfig valueForKey:@"requestMethod"] forKey:@"method"];

    }else{
        [[ECClearApp shareInstance] exitApp:@"程序错误" message:@"退出程序：参数传递错误！"];
        return ;
    }
    
    FormDataRequest* request = [FormDataRequest requestNetURI:API_URL
                                                       params:params
                                                     delegate:self
                                             finishedSelector:@selector(requestFindished:)
                                                 failSelector:@selector(webRequestFailed:)];
    if (request) {
        [[NetRequestManager sharedInstances] addOperation:request];
        [self showLoading:nil];
    }
    
}
- (void)handleRequestData:(NSData*)data{
    [super handleRequestData:data];
    NSDictionary* dataDic = [[NSDictionary alloc] init];
    id tempData = nil;
    //处理数据
    id obj = [ECJsonParser objectWithJsonData:data];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        tempData = [obj valueForKey:@"data"];
    }
    if (tempData && [tempData isNSxxxClass:[NSDictionary class]])
    {
        dataDic = tempData;
    }else{
        if (nil == dataDic) {
            // TODO: 弹出数据出错！
        }
    }
    self.contentViewData = dataDic;
    [self showContentView];
    
}

#pragma ECSubTableViewActionDelegate
- (void) doAction:(UITableView *)tableView action:(NSString *)action
{
    NSLog(@"ECSignUpController doAction : %@",action);
//    [self doAction:action];
}


@end
