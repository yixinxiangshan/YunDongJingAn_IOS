//
//  ECOrderListController.m
//  jinganledongtiyu
//
//  Created by cheng on 13-10-15.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECOrderListController.h"
#import "ECOrderListCell.h"
#import "ECEventRouter.h"

@implementation ECOrderListController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    [self.navigationController setWantsFullScreenLayout:NO];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    if (IOS7_OR_LATER) {
        self.tableView.separatorInset = UIEdgeInsetsZero;
    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshData) name:@"ECOrderListController.refreshData" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshData) name:@"aliPay.successed" object:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void) handleRequestData:(NSData *)data
{
    [super handleRequestData:data];
    [self.tableView reloadData];
}
- (void) refreshData
{
    [self freshData:YES];
}
#pragma mark- Table view data source
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 66.0;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return self.dataSource.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    id dataItem = [self.dataSource objectAtIndex:indexPath.row];
    
    NSString *CellIdentifier = @"ECOrderListCell";
    //获取表视图 cell 的布局
    ECOrderListCell *cell = nil;
    cell = (ECOrderListCell *)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
    
    if (!cell) {
        cell = [[ECOrderListCell alloc] init];
    }
    
    [cell setTitle:[dataItem objectForKey:@"title"]];
    [cell setOrderNumber:[NSString stringWithFormat:@"%@",[dataItem objectForKey:@"order_number"]]];
    [cell setTotalPrice:[[dataItem objectForKey:@"must_price"] floatValue]];
    [cell setOrderStatus:[[dataItem objectForKey:@"act_status_type_id"] floatValue]];
    
    return cell;
}

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSLog(@"Do click......");
    
    NSMutableDictionary* params = [NSMutableDictionary new];
    NSDictionary* dataItem = [self.dataSource objectAtIndex:indexPath.row];
    [params setObject:[self getValue:dataItem forKey:@"id"] forKey:@"requestId"];
    [params setObject:[self getValue:dataItem forKey:@"title"] forKey:@"navTitle"];
    
    NSString* action = [self.configs objectForKey:@"action"];
    NSLog(@"%@",action);
    
    [[ECEventRouter shareInstance] doAction:action userInfo:params];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
#pragma mark -Pulling Refresh Table view delegate
// pull down to refresh
- (void)pullingTableViewDidStartRefreshing:(PullingRefreshTableView *)tableView{
    [super pullingTableViewDidStartRefreshing:tableView];
}

//Implement this method if headerOnly is false,pull up to loading more
- (void)pullingTableViewDidStartLoading:(PullingRefreshTableView *)tableView{
    [super pullingTableViewDidStartLoading:tableView];
}
@end
