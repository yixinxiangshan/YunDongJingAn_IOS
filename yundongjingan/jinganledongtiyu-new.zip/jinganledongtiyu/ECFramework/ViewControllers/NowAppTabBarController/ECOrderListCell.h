//
//  ECOrderListCell.h
//  jinganledongtiyu
//
//  Created by cheng on 13-10-15.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ECOrderListCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *addressLabel;

@property (weak, nonatomic) IBOutlet UILabel *totalPriceLabel;
@property (weak, nonatomic) IBOutlet UILabel *orderStatusLabel;
- (void) setTitle:(NSString *)title;
- (void) setAddress:(NSString *)address;
- (void) setTotalPrice:(CGFloat)totalPrice;
- (void) setOrderStatus:(NSInteger)orderStatus;
- (void) setOrderNumber:(NSString *)orderNumber;

+ (NSString *)stringWithOrderStatus:(NSInteger)orderStatus;
@end
