//
//  ECOrderDetailViewController.h
//  jinganledongtiyu
//
//  Created by cheng on 13-10-15.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECDetailViewController.h"

@interface ECOrderDetailViewController : ECDetailViewController
@property (strong, nonatomic) NSString* checkTime;
@property (strong, nonatomic) NSString* updateTime;
@property NSInteger actStatusType;
@property (strong, nonatomic) NSString* gymProject;
@property (strong, nonatomic) NSDictionary* extendedJson;
@end
@interface UIRoundRectText : UITextView
@end
@interface PrivateRoundRectButton : UIButton
- (void) setState:(NSInteger)state;
@end