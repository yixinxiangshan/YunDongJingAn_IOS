//
//  ECOrderDetailViewController.m
//  jinganledongtiyu
//
//  Created by cheng on 13-10-15.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECOrderDetailViewController.h"
#import "NSDateExtends.h"
#import "ECOrderListCell.h"
#import "ECCMController.h"
#import "NSStringExtends.h"

#define DefaultFontSize 15
#define DefaultFont [UIFont systemFontOfSize:DefaultFontSize]

@interface ECOrderDetailViewController ()
@property (strong, nonatomic) PrivateRoundRectButton* payButton;
@property (strong, nonatomic) PrivateRoundRectButton* cancelButton;
@property (strong, nonatomic) UIRoundRectText* headerView;
@property (strong, nonatomic) UIRoundRectText* orderDetail;
@property (strong, nonatomic) UIRoundRectText* footerView;
@end

@implementation ECOrderDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void) payOrder
{
    ECLog(@"pay for order now");
    
    NSDictionary* aliPayConfig = [self.configs objectForKey:@"aliPayConfig"];
    NSMutableDictionary* aliPayParams = [NSMutableDictionary new];
    NSEnumerator* aliPayParamsKey = [aliPayConfig keyEnumerator];
    id key ;
    while (key = [aliPayParamsKey nextObject]) {
        if ([self.dataDic objectForKey:[aliPayConfig objectForKey:key]]) {
            [aliPayParams setObject:[self.dataDic objectForKey:[aliPayConfig objectForKey:key]] forKey:key];
        }
    }
    NSString *orderBody = [NSAttributedString attributedStringWithHtmlString:[self parseOrderDetails] defaultFont:nil].string;
    [aliPayParams setObject:orderBody forKey:@"body"];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(aliPaySuccessed:) name:@"aliPay.successed" object:nil];
    [[ECCMController shareInstance] alipay:aliPayParams];
}
- (void)aliPaySuccessed:(NSNotification *) noti
{
//    [_cancelButton setState:0];
//    [_payButton setState:0];
//    [_payButton setTitle:@"已支付" forState:UIControlStateNormal];
    [self netRequest];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ECOrderListController.refreshData" object:nil];
}
- (void) cancelOrder
{
    ECLog(@"cancel order ...");
    NSMutableDictionary* params = [NSMutableDictionary new];
    [params setObject:@"trade/orders/destroy" forKey:@"method"];
    [params setObject:self.requestId forKey:@"buy_order_id"];
    NSString* notiName = [NSString randomString:0 maxLength:20 minLength:10];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(cancelOrderFinished:) name:[NSString stringWithFormat:@"%@.netRuqestSuccessed",notiName] object:nil];
    [ECCMController requestWithParams:params successedMessage:@"删除成功！" faildMessage:@"删除失败，请重新操作！" isNeedLogin:YES notiName:notiName];
}
- (void) cancelOrderFinished:(NSNotificationCenter *)noti
{
    ECLog(@"cancle order successed !");
    [self.navigationController popViewControllerAnimated:YES];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ECBookViewController.refreshData" object:nil];
}
- (void) initView
{
    [self.subViews removeAllObjects];
    
    [self.dataDic objectForKey:@"order_number"];
    // 订单编号
    _headerView = [[UIRoundRectText alloc] initWithFrame:CGRectMake(10, 0, self.view.frame.size.width - 20, 10)];
    [_headerView setText:[NSString stringWithFormat:@"订单编号：<font color = \"red\">%@</font>",[self.dataDic objectForKey:@"order_number"]]];
    [self.subViews addObject:_headerView];
    
    //订单详情
    _orderDetail = [[UIRoundRectText alloc] initWithFrame:CGRectMake(10, 0, self.view.frame.size.width - 20, 10)];
    [_orderDetail setText:[self creatOrderDetail:self.dataDic]];
    [self.subViews addObject:_orderDetail];
    
    //订单状态
    _footerView = [[UIRoundRectText alloc] initWithFrame:CGRectMake(10, 0, self.view.frame.size.width - 20, 10)];
    [_footerView setText:[NSString stringWithFormat:@"订单状态：%@",[self parseActStatus]]];
    [self.subViews addObject:_footerView];
    
    //按钮
    UIView* buttonContainer = [[UIView alloc] initWithFrame:CGRectMake(10, 0, self.view.frame.size.width - 20, 44)];
    [buttonContainer setBackgroundColor:[UIColor clearColor]];
    // button cancel order
    self.cancelButton = [[PrivateRoundRectButton alloc] initWithFrame:CGRectMake(10, 0, buttonContainer.frame.size.width/2-20, 44)];
    [_cancelButton setTitle:@"取消订单" forState:UIControlStateNormal];
    [_cancelButton setState:_actStatusType == 2 || _actStatusType == 4 ? 1 : 0];
    [_cancelButton addTarget:self action:@selector(cancelOrder) forControlEvents:UIControlEventTouchUpInside];
    [buttonContainer addSubview:_cancelButton];
    
    //button pay order
    self.payButton = [[PrivateRoundRectButton alloc] initWithFrame:CGRectMake(buttonContainer.frame.size.width/2+10, 0, buttonContainer.frame.size.width/2-20, 44)];
    [_payButton setTitle:@"立即支付" forState:UIControlStateNormal];
    [_payButton setState:_actStatusType == 4 ? 1 : 0];
    [_payButton addTarget:self action:@selector(payOrder) forControlEvents:UIControlEventTouchUpInside];
    [buttonContainer addSubview:_payButton];
    
    [self.subViews addObject:buttonContainer];
    
    [self layoutSubViews];
}
- (NSString *) creatOrderDetail:(NSDictionary *)data
{
    ;
    NSMutableString* orderDetail = [NSMutableString new];
    [orderDetail appendString:[NSString stringWithFormat:@"运动项目：%@",[_extendedJson objectForKey:@"gym_project"]]];
    [orderDetail appendString:[NSString stringWithFormat:@"\n场馆名称：%@",[data objectForKey:@"title"]]];
    [orderDetail appendString:[NSString stringWithFormat:@"\n预订时间：%@",_checkTime]];
    [orderDetail appendString:[NSString stringWithFormat:@"\n订单详情：%@",[self parseOrderDetails]]];
    
    [orderDetail appendString:[NSString stringWithFormat:@"\n订单总额：<font color = \"#FF0000\">%0.2f元</font>",[[data objectForKey:@"must_price"] floatValue]]];
    [orderDetail appendString:[NSString stringWithFormat:@"\n订单日期：%@",_updateTime]];
    
    return orderDetail;
}
- (NSString *) parseOrderDetails
{
    NSMutableString*  orderDetails = [NSMutableString new];
    NSArray* orderDetailsItems = [[_extendedJson objectForKey:@"orderDetails"] componentsSeparatedByString:@"<br/>"];
    
    for (NSString* item in orderDetailsItems) {
        
        if (item && ![item isEqualToString:@""]) {
            [orderDetails appendFormat:@"\n\t%@",item];
        }
    }
    return orderDetails;
}
- (NSString *) parseActStatus
{
    NSInteger actStatus = [[self.dataDic objectForKey:@"act_status_type_id"] integerValue];
    return [ECOrderListCell stringWithOrderStatus:actStatus];
}
- (void) handleRequestData:(NSData *)data
{
    [super handleRequestData:data];
    NSArray* stringArray = [NSArray arrayWithObjects:[NSString stringWithFormat:@"T"], [NSString stringWithFormat:@"Z"], nil];
    self.dataDic = [self.dataDic objectForKey:@"ContentInfo"];
    
    _extendedJson = [ECJsonParser objectWithJsonString:[self.dataDic objectForKey:@"json_property"]];
    _actStatusType = [[self.dataDic objectForKey:@"act_status_type_id"] integerValue];
    
    _checkTime = [self.dataDic objectForKey:@"check_time"];
    for (NSString* str in stringArray) {
        _checkTime = [_checkTime stringByReplacingOccurrencesOfString:str withString:@" "];
    }
    _checkTime = [[NSDate dateFromString:_checkTime formate:@"yyyy-MM-dd HH:mm:ss"] stringWithFormat:@"yyy年MM月dd日"];
    
    _updateTime = [self.dataDic objectForKey:@"created_at"];
    for (NSString* str in stringArray) {
        _updateTime = [_updateTime stringByReplacingOccurrencesOfString:str withString:@" "];
    }
    _updateTime = [[NSDate dateFromString:_updateTime formate:@"yyyy-MM-dd HH:mm:ss"] stringWithFormat:@"yyy年MM月dd日"];
    [self initView];
}
#pragma mark- method utils

@end
@implementation UIRoundRectText
- (id) initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    [self setFont:DefaultFont];
    self.editable = NO;
    return self;
}

- (void) drawRect:(CGRect)rect
{
    [super drawRect:rect];
    //设置圆角边框
    self.layer.cornerRadius = 3;
    self.layer.masksToBounds = YES;
    //设置边框及边框颜色
    self.layer.borderWidth = 1;
    self.layer.borderColor =[ [UIColor lightGrayColor] CGColor];
}
- (void) setText:(NSString *)text
{
//    self.attributedText = [NSAttributedString attributedStringFromHTML:text boldFont:[self font]];
    self.attributedText = [NSAttributedString attributedStringWithHtmlString:text defaultFont:self.font];
    [self sizeToFit];
}
- (void) sizeToFit
{
    [self setFrame:CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, [self textViewHeightForAttributedText:self.attributedText andWidth:self.frame.size.width])];
}
- (CGFloat)textViewHeightForAttributedText:(NSAttributedString*)text andWidth:(CGFloat)width
{
    UITextView *calculationView = [[UITextView alloc] init];
    [calculationView setAttributedText:text];
    CGSize size = [calculationView sizeThatFits:CGSizeMake(width, FLT_MAX)];
    return size.height + 3;
}
@end
@implementation PrivateRoundRectButton
-(id) initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setBackgroundImage:[UIImage imageNamed:@"jingan-35.png"] forState:UIControlStateNormal];
    }
    return self;
}
- (void) setState:(NSInteger)state
{
    if (!state) {
        // state 0 : 不可用
        [self setBackgroundImage:[UIImage imageNamed:@"bg_channel.png"] forState:UIControlStateNormal];
        self.userInteractionEnabled = NO;
    }else{
        // state  : 可用
        [self setBackgroundImage:[UIImage imageNamed:@"jingan-35.png"] forState:UIControlStateNormal];
        self.userInteractionEnabled = YES;
    }
}
- (void) drawRect:(CGRect)rect
{
    [super drawRect:rect];
    //设置圆角边框
    self.layer.cornerRadius = 3;
    self.layer.masksToBounds = YES;
    //设置边框及边框颜色
    self.layer.borderWidth = 0;
    self.layer.borderColor =[ [UIColor grayColor] CGColor];
}
@end