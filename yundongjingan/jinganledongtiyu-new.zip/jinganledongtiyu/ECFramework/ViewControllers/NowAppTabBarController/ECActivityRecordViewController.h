//
//  ECActivityRecordViewController.h
//  jinganledongtiyu
//
//  Created by cww on 13-7-18.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECListViewController.h"

@interface ECActivityRecordViewController : ECListViewController

@end
