//
//  ECOrderListCell.m
//  jinganledongtiyu
//
//  Created by cheng on 13-10-15.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECOrderListCell.h"
#import "NSStringExtends.h"

@implementation ECOrderListCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (void) setTitle:(NSString *)title
{
    _titleLabel.text = title;
}
- (void) setAddress:(NSString *)address
{
    _addressLabel.text = address;
}
- (void) setOrderNumber:(NSString *)orderNumber
{
    NSAttributedString* text = [NSAttributedString attributedStringWithHtmlString:[NSString stringWithFormat:@"<font color = \"gray\" size = \"11\">订单号：</font><font color = \"blue\",size = \"13\">%@</font>",orderNumber] defaultFont:_addressLabel.font];
//    [NSAttributedString attributedStringFromHTML:[NSString stringWithFormat:@"<font color = \"gray\" size = \"11\">订单号：</font><font color = \"blue\",size = \"13\">%@</font>",orderNumber] boldFont:[_addressLabel font]];
    _addressLabel.attributedText = text;
}
- (void) setTotalPrice:(CGFloat)totalPrice
{
    
    NSAttributedString* text = [NSAttributedString attributedStringWithHtmlString:[NSString stringWithFormat:@"<font color = \"red\",size = \"15\">%0.2f元</font>",totalPrice] defaultFont:_totalPriceLabel.font];
//    [NSAttributedString attributedStringFromHTML:[NSString stringWithFormat:@"<font color = \"red\",size = \"15\">%0.2f元</font>",totalPrice] boldFont:[_totalPriceLabel font]];
    _totalPriceLabel.attributedText = text;
}
- (void) setOrderStatus:(NSInteger)orderStatus
{
    _orderStatusLabel.attributedText = [NSAttributedString attributedStringWithHtmlString:[ECOrderListCell stringWithOrderStatus:orderStatus] defaultFont:_orderStatusLabel.font];
//    [NSAttributedString attributedStringFromHTML:[ECOrderListCell stringWithOrderStatus:orderStatus] boldFont:[_orderStatusLabel font]];
}
+ (NSString *)stringWithOrderStatus:(NSInteger)orderStatus
{
    switch (orderStatus) {
        case 1:
            return @"";
        case 2:
            return [NSString stringWithFormat:@"<font color = \"green\">购物车状态</font>"];
            break;
        case 3:
            return [NSString stringWithFormat:@"<font color = \"blue\">等待确认收货地址</font>"];
            break;
        case 4:
            return [NSString stringWithFormat:@"<font color = \"red\">未支付</font>"];
            break;
        case 5:
            return [NSString stringWithFormat:@"<font color = \"black\">已支付</font>"];
            break;
        case 6:
            return [NSString stringWithFormat:@"<font color = \"green\">已验正</font>"];
            break;
        case 7:
            return [NSString stringWithFormat:@"<font color = \"green\">订单已送达</font>"];
            break;
        case 8:
            return [NSString stringWithFormat:@"<font color = \"darkgray\">订单完成</font>"];
            break;
        case 9:
            return [NSString stringWithFormat:@"<font color = \"yellow\">等待商家确认</font>"];
            break;
        case 10:
            return [NSString stringWithFormat:@"<font color = \"gray\">订单已取消</font>"];
            break;
            
        default:
            return [NSString stringWithFormat:@"<font color = \"lightgray\">订单异常</font>"];
            break;
    }
}
@end
