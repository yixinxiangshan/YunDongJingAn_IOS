//
//  NowAppTabBarController.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-18.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "NowAppTabBarController.h"

@interface NowAppTabBarController ()

@end

@implementation NowAppTabBarController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
