//
//  ECActivityRecordViewController.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-18.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECActivityRecordViewController.h"
#import "CellItemViews.h"

@interface ECActivityRecordViewController ()

@end

@implementation ECActivityRecordViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)showTableView{
    //    CGFloat viewHeight = self.navigator.view.frame.size.height;
    
//    UserInfoItem* userInfo = (UserInfoItem*)[[[NSBundle mainBundle] loadNibNamed:@"UserInfoItem" owner:self options:nil] lastObject];
//    [(UserInfoItem*)userInfo initInfo];
//    
//    [self.view addSubview:userInfo];
    
    if (nil == self.tableView) {
        self.tableView = [[ECPullingTableView alloc] initWithFrame:CGRectMake(0, 0, validWidth(), validHeight()) style:UITableViewStylePlain];
        //        [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        self.tableView.pullingDelegate = self;
        
        
//            UIImageView* bg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"timeline2.png"]];
//            [bg setFrame:CGRectMake(1, 0, 44, validHeight())];
//            [self.tableView addSubview:bg];
        
        
        
        if ([(NSNumber*)[self.styles objectForKey:@"isWithSeparateLine"] boolValue]) {
            [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        }
        [self.view addSubview:self.tableView];
    }
}

-(void) initNetRequestParams
{
    [super initNetRequestParams];
    
    //网络请求
    NSMutableDictionary* params = [NSMutableDictionary new];
    [params addEntriesFromDictionary:self.netRequestParams];
    
    [params setValue:@"1" forKey:@"typenum"];
    
    self.netRequestParams = params;
    
}
@end
