//
//  ECLeftMenuController.h
//  DemoECEcloud
//
//  Created by EC on 3/6/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECBaseListViewController.h"

@interface ECLeftMenuController : ECBaseListViewController

@end
