//
//  ECLeftMenuController.m
//  DemoECEcloud
//
//  Created by EC on 3/6/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECLeftMenuController.h"
#import "ECOneLineCell.h"

@interface ECLeftMenuController ()

@end

@implementation ECLeftMenuController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.dataSource = [self.configs objectForKey:@"dataList"];
    if (nil == self.dataSource || self.dataSource.count<1) {
        ECLog(@"%@ configs error",NSStringFromClass([self class]));
    }else{
        [self.tableView reloadData];
    }
    self.cellConfig = [self.configs objectForKey:@"cell"];
    self.cellId = [self.cellConfig objectForKey:@"cellId"];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary* itemDic = [self.dataSource objectAtIndex:indexPath.row];
    static NSString *CellIdentifier = nil;
    if (nil == CellIdentifier && nil != self.cellId) {
        CellIdentifier = self.cellId;
    }
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if ([CellIdentifier isEqualToString:@"ECOneLineCell"]) {
        if (!cell) {
            cell = (ECOneLineCell*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];;
        }
        ((ECOneLineCell*)cell).itemTitle.text = [itemDic objectForKey:@"title"];
        ((ECOneLineCell*)cell).leftIcon.image = [UIImage imageNamed:[itemDic objectForKey:@"icon"]];
        [((ECOneLineCell*)cell).rightIcon setHidden:YES];
    }

    return cell;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableDictionary* params = [NSMutableDictionary new];
//    [params setObject:@"课表" forKey:@"title"];
    [[NSNotificationCenter defaultCenter] postNotificationName:[NSString stringWithFormat:@"%@.%@.itemClick%d",self.instanceName,NSStringFromClass([self class]),indexPath.row] object:nil userInfo:params];
}

@end
