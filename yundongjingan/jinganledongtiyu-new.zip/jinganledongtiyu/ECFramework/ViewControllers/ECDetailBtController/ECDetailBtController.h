//
//  ECDetailBtController.h
//  JingAnWeekly
//
//  Created by EC on 3/25/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECGeneralDetailViewController.h"

@interface ECDetailBtController : ECGeneralDetailViewController


@property (nonatomic, strong) UIButton* expandButton;
@end
