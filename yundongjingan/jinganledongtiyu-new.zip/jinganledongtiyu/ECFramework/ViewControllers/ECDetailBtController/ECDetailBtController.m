//
//  ECDetailBtController.m
//  JingAnWeekly
//
//  Created by EC on 3/25/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECDetailBtController.h"

@interface ECDetailBtController ()

@end

@implementation ECDetailBtController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
}

-(void) showContentView{
    [super showContentView];
    
    // add signUpButton
    CGFloat yValue = self.genDetail.content.frame.origin.y + self.genDetail.content.frame.size.height + 8.0;
    self.expandButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [self.expandButton setFrame:CGRectMake(20, yValue, validWidth()-40, 44)];
    [self.expandButton setTitle:@"我要报名" forState:UIControlStateNormal];
    [self.expandButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.expandButton setBackgroundImage:[UIImage imageNamed:@"LoginBt.png"] forState:UIControlStateNormal];
    [self.expandButton setBackgroundImage:[UIImage imageNamed:@"LoginBtSelect.png"] forState:UIControlStateHighlighted];
    [self.expandButton addTarget:self action:@selector(expandButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.genDetail.scrollView addSubview:self.expandButton];
    [self resetViewPosition];
}


- (void)resetViewPosition{
    [super resetViewPosition];
    if (nil != self.expandButton) {
        // set bt location
        CGRect contentFrame = self.expandButton.frame;
        contentFrame.origin.y =self.genDetail.content.frame.origin.y + self.genDetail.content.frame.size.height + 8.0f;
        self.expandButton.frame = contentFrame;
        
        //set scrollview contentsize
        CGFloat height = self.expandButton.frame.origin.y+self.expandButton.frame.size.height+80;
        if (height > self.genDetail.scrollView.frame.size.height) {
            [self.genDetail.scrollView setContentSize:CGSizeMake(320.0f,height)];
        }

    }
}

- (void) expandButtonClick:(id)sender{
    [[NSNotificationCenter defaultCenter] postNotificationName:[NSString stringWithFormat:@"%@.%@.expandBtClick",self.instanceName,NSStringFromClass([self class])] object:nil userInfo:nil];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
