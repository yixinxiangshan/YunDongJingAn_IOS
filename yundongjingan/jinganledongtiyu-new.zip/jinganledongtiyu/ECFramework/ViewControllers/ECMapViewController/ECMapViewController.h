//
//  ECMapViewController.h
//  jinganledongtiyu
//
//  Created by cww on 13-7-16.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECBaseViewExtendController.h"
#import "LightMenuBar.h"
#import "LightMenuBarDelegate.h"
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "ECMapAnnotation.h"

@interface ECMapViewController : ECBaseViewExtendController <LightMenuBarDelegate,MKMapViewDelegate>

//navigatorBar menu
@property (nonatomic, strong) NSArray* navigatorBarMenuConfig;
//channelbar
@property (nonatomic, strong) LightMenuBar* channelBar;
@property (nonatomic, strong) NSArray* channelBarMenuConfig;

//mapview
@property (nonatomic) NSMutableArray *mapAnnotations;

@property (strong, nonatomic)  MKMapView *mapView;

-(void) commandReceiver:(NSDictionary  *)params;
@end
