//
//  ECGalleryViewController.h
//  DemoECEcloud
//
//  Created by EC on 3/15/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "FGalleryViewController.h"

@interface ECGalleryViewController : FGalleryViewController


@end
