//
//  ECGalleryViewController.m
//  DemoECEcloud
//
//  Created by EC on 3/15/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECGalleryViewController.h"

@interface ECGalleryViewController ()

@end

@implementation ECGalleryViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)handleRequestData:(NSData*)data{
    [super handleRequestData:data];
    self.dataSource = [[NSMutableArray alloc] init];
    if (nil != self.dataDic && NULL != self.dataDic) {
        NSString* listKey = [self.configs objectForKey:@"listKey"];
        id tempDic = nil;
        if([listKey rangeOfString:@"."].location != NSNotFound){
            NSArray* splitString = [listKey componentsSeparatedByString:@"."];
            tempDic = self.dataDic;
            for (int i = 0; i<[splitString count]; i++) {
                tempDic = [tempDic objectForKey:[splitString objectAtIndex:i]];
            }
        }else{
            tempDic = [self.dataDic objectForKey:listKey];
        }
        
        if (tempDic && [tempDic isNSxxxClass:[NSArray class]]) {
            self.dataSource = [NSMutableArray arrayWithArray:tempDic];
        }else{
            ECLog(@"data error: con not get list data to dataSource");
            return;
        }
    }else{
        ECLog(@"data error: data dictionary is null");
        return;
    }
    // parse data to parentclass EGalleryViewController
    NSString* imageKey = [self.configs objectForKey:@"imageKey"];
    NSString* titleKey = [self.configs objectForKey:@"titleKey"];
    for (id dic in self.dataSource) {
        [self.photosUri addObject:[NSString stringWithFormat:@"%@%@",imageURI(),[dic objectForKey:imageKey]]];
        [self.photoTitles addObject:[NSString stringWithFormat:@"%@",[dic objectForKey:titleKey]]];
    }
    
    [self reloadGallery];
}

@end
