//
//  ECStaticViewController.m
//  jinganledongtiyu
//
//  Created by cheng on 14-2-20.
//  Copyright (c) 2014年 eCloud. All rights reserved.
//

#import "ECStaticViewController.h"
#import "NSStringExtends.h"
#import "UCUIControlEventProtocol.h"
#import "ECEventRouter.h"

@interface ECStaticViewController ()

@end

@implementation ECStaticViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
	// Do any additional setup after loading the view.
    
    UIView *view = [[[NSBundle mainBundle] loadNibNamed:@"YunDongJingAn" owner:self options:nil] lastObject];
    self.view = view;
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) touchUpInside:(UIControl *)sender
{
    ECLog(@"touch up in side : ID = %@",sender.ID);
    ECLog(@"URL : %@",sender.url);
    NSString *action;
    
    NSURL *url = [NSURL URLWithString:sender.url];
    action = [NSString stringWithFormat:@"%@://%@?requestId=%@&%@",url.scheme, url.host ,sender.ID,url.query];
    
    [[ECEventRouter shareInstance] doAction:action];
}
@end
