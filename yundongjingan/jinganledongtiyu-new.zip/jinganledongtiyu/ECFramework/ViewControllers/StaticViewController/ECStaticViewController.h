//
//  ECStaticViewController.h
//  jinganledongtiyu
//
//  Created by cheng on 14-2-20.
//  Copyright (c) 2014年 eCloud. All rights reserved.
//

#import "ECBaseViewExtendController.h"

@interface ECStaticViewController : ECBaseViewExtendController

@end
