//
//  ECSectionViewController.h
//  jinganledongtiyu
//
//  Created by cheng on 13-9-27.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECBaseViewExtendController.h"
#import "ECImageContainer.h"
#import "ECSectionViewCell.h"

@interface ECSectionViewController : ECBaseViewExtendController <UITableViewDataSource, UITableViewDelegate>

/**
 * 独立配置每一个 cell，充许批量配置cell，通过action（self.requestId) 和 query (self.netRequestParams)传递事件参数
 */

@property (strong, nonatomic) NSMutableDictionary* dataSource;
@property (nonatomic) BOOL isNeedCache;
@property (strong, nonatomic) NSArray* sectionConfigs;
@property (strong, nonatomic) NSMutableArray* sections;

@property (strong, nonatomic) UITableView* tableView;

@property (strong, nonatomic) NSMutableDictionary* netRequestParams;

- (void) reloadData;
@end

