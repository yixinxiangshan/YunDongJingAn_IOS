//
//  ECSectionViewController.m
//  jinganledongtiyu
//
//  Created by cheng on 13-9-27.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSectionViewController.h"
#import "NSString+SBJSON.h"
#import "NSObjectExtends.h"

#define HeightForSectionHeader 33

@interface ECSectionViewController ()
@property NSInteger nextRequest;
@property BOOL loadDataFinished;
@end

@implementation ECSectionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
//    ECLog(@"ECSectionViewController query : %@",self.query);
    
//    if (nil != [self.query objectForKey:@"requestId"] ) {
//        self.requestId = [self.query objectForKey:@"requestId"];
//    }
    
    
    self.requestId = [self getValue:self.query forKey:@"requestId"] ? [self getValue:self.query forKey:@"requestId"] : nil;
    
    if (!self.requestId && [self getValue:self.configs forKey:@"idKey"]) {
        self.requestId = [self getValue:self.query forKey:[self.configs objectForKey:@"idKey"]];
    }
    
    //键盘变化通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    // 默认需要 cache
    _isNeedCache = YES;
    NSEnumerator* enumrator = [self.configs keyEnumerator];
    id key;
    while (key = [enumrator nextObject]) {
        if ([key isEqualToString:@"isNeedCache"] && ![[self.configs objectForKey:key] boolValue]) {
            _isNeedCache = NO;
        }
    }
    
    
    [self initTableView];
    
    [self loadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
/**
 * 生成视图，并存放在 sections 中
 */
- (void) initSections
{
    _sections = !_sections ? [NSMutableArray new] : _sections;
    [_sections removeAllObjects];
    _sectionConfigs = [self.configs objectForKey:@"sections"] ? [self.configs objectForKey:@"sections"] : nil;
    
    for (NSDictionary* config in _sectionConfigs) {
        NSMutableDictionary* section = [NSMutableDictionary new];
        NSString* sectionTitle = [self getTitle:@"sectionTitle" from:config];
        if (sectionTitle) {
            [section setObject:sectionTitle forKey:@"sectionTitle"];
        }
        if ([config objectForKey:@"cells"]) {
            NSArray* cells = [self cellslWithConfigs:[config objectForKey:@"cells"]];
            cells ? [section setObject:cells forKey:@"cells"] : nil;
        }
        [section objectForKey:@"cells"] ? [_sections addObject:section] : nil;
        [_tableView reloadData];
    }
}
- (NSArray *) cellslWithConfigs:(NSArray *)configs
{
    NSMutableArray* cells = [NSMutableArray new];
    
    for (NSDictionary* config in configs) {
        ECSectionViewCell* cell = nil;
        NSArray* listCell = nil;
        Class class = NSClassFromString([config objectForKey:@"type"]);
        switch ([self cellType:[config objectForKey:@"type"]]) {
            case 0:
                cell = [self defaultCellWithConfig:config];
                break;
            case 1:
                cell = [self imageCoverWithConfig:config];
                break;
            case 2:
                cell = [self textViewdWithConfig:config];
                break;
            case 3:
                listCell = [self cellListWithConfig:config];
                break;
            default:
                cell = [[class alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 0) config:config dataSource:_dataSource];
//                cell = [[class alloc] init];
//                if ([cell respondsToSelector:@selector(initWithFrame:config:dataSource:)]) {
//                    cell = [cell initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 0) config:config dataSource:_dataSource];
//                }
                
        }
        if ([cell respondsToSelector:@selector(initAction)]) {
            [cell initAction];
        }
        cell.userInteractionEnabled = cell.action && cell.action.length;
        cell ? [cells addObject:cell] : nil;
        
        cell.ID = !cell.ID ? self.requestId : cell.ID;
        
        for (ECSectionViewCell* item in listCell) {
            [item initAction];
        }
        listCell ? [cells addObjectsFromArray:listCell] : nil;
    }
    cells = cells.count ? cells : nil;
    return cells;
}
- (ECSectionViewCell *) defaultCellWithConfig:(NSDictionary *)config
{
    NSString* title = [self getTitle:@"title" from:config];
    if (!title) return nil;
    NSString* subTitle = [self getTitle:@"subTitle" from:config];
    ECSectionViewCell* cell = [[ECSectionViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    cell.config = config;
    cell.ID = self.requestId;
    if ([self getTitle:@"action" from:config]) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    [cell.textLabel setFont:TitleFont];
    cell.textLabel.text = title;
    [cell.detailTextLabel setFont:SubTitleFont];
    cell.detailTextLabel.text = subTitle;
    
    return cell;
}
- (NSArray *) cellListWithConfig:(NSDictionary *)config
{
    NSMutableArray* cellList = [NSMutableArray new];
    // init listData,  insert localData
    NSMutableArray* listData = [NSMutableArray arrayWithArray:[config objectForKey:@"localData"]];
    // insert remoteData
    NSDictionary* remoteDataConfig = [config objectForKey:@"remoteData"];
    NSString* titleKey = [remoteDataConfig objectForKey:@"titleKey"];
    NSString* subTitleKey = [remoteDataConfig objectForKey:@"subTitleKey"];
    NSString* IDKey = [remoteDataConfig objectForKey:@"idKey"];
    NSArray* remoteData = [self getValue:self.dataSource forKey:[remoteDataConfig objectForKey:@"listDataKey"]];
    for (NSDictionary* data in remoteData) {
        NSMutableDictionary* temp = [NSMutableDictionary dictionaryWithObjectsAndKeys:[data objectForKey:titleKey],@"title",[data objectForKey:subTitleKey],@"subTitle",[data objectForKey:IDKey],@"id", nil];
        [temp addEntriesFromDictionary:data];
        [listData addObject:temp];
    }
    // create cells
    for (NSDictionary* data in listData) {
        ECSectionViewCell* cell = [[ECSectionViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
        NSMutableDictionary* tempConfig = [NSMutableDictionary dictionaryWithDictionary:data];
        
        id bundleData = [self getValue:_dataSource forKey:[config objectForKey:@"bundleDataKey"]];
        if (bundleData) {
            [tempConfig setObject:bundleData forKey:@"bundleData"];
        }
        
        cell.config = tempConfig;
        if ([self getTitle:@"action" from:config]) {
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            cell.action = [self getTitle:@"action" from:config];
        }
        if (![data objectForKey:@"title"] || [[data objectForKey:@"title"] isEqualToString:@""]) {
            continue;
        }
        [cell.textLabel setFont:TitleFont];
        cell.textLabel.text = [data objectForKey:@"title"];
        [cell.detailTextLabel setFont:SubTitleFont];
        cell.detailTextLabel.text = [data objectForKey:@"subTitle"];
        cell.ID = [data objectForKey:@"id"];
        
        [cellList addObject:cell];
    }
    return cellList.count ? cellList : nil;
}
- (ECSectionViewCell *) textViewdWithConfig:(NSDictionary *)config
{
    NSString* content = [config objectForKey:@"content"] ? [config objectForKey:@"content"] : [self getValue:_dataSource forKey:[config objectForKey:@"contentKey"]];
    if (!content) return nil;
    ECSectionViewTextView* cell = [[ECSectionViewTextView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 0)];
    cell.content = content;
    cell.config = config;
    cell.ID = self.requestId;
    [cell setBgColor:_tableView.backgroundColor];
    
    return cell;
}
- (ECSectionViewCell *) imageCoverWithConfig:(NSDictionary *)config
{
    NSString* imageUrl = [self getTitle:@"imageUrl" from:config];
    if (!imageUrl) {
        return nil;
    }
    ECSectionViewImageCover* cell = [[ECSectionViewImageCover alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 0)];
    cell.config = config;
    cell.ID = self.requestId;
    [cell setImageUrl:imageUrl];
    return cell;
}

#pragma mark- 重新布局视图
- (void) reloadData
{
    [_tableView reloadData];
}
/**
 *  utils method
 */
- (NSString *) getTitle:(NSString *)title from:(NSDictionary *)config
{
    NSString* titleString = [config objectForKey:title] && ![[config objectForKey:title] isEqualToString:@""] ? [config objectForKey:title] : nil;
    if (titleString && ![titleString isEqualToString:@""]) {
        return titleString;
    }
    NSString* titleKey = [NSString stringWithFormat:@"%@Key",title];
    titleString = [self getValue:self.dataSource forKey:[config objectForKey:titleKey]] ? [self getValue:self.dataSource forKey:[config objectForKey:titleKey]] : nil;
    if (titleString && ![titleString isEqualToString:@""]) {
        return titleString;
    }
    return nil;
}
- (NSInteger) cellType:(NSString *)cellType
{
    if ([cellType isEqualToString:@"cell"])       return 0;
    if ([cellType isEqualToString:@"imageCover"]) return 1;
    if ([cellType isEqualToString:@"text"])       return 2;
    if ([cellType isEqualToString:@"list"])       return 3;
    
    return NSIntegerMax;
}
/**
 * load data
 */
- (void) loadData
{
    if ([[self.configs objectForKey:@"isLocalData"] boolValue]) {
        [self parseSpecialConfig];
        return;
    }
    _netRequestParams = _netRequestParams ? _netRequestParams : [NSMutableDictionary new];
    
    if ([self.netDataRelevant objectForKey:@"requestIdKey"]) {
        NSString* requestId = [self.netDataRelevant objectForKey:@"requestId"] ;
        if ( requestId && requestId.length) {
            [_netRequestParams setObject:[self.netDataRelevant objectForKey:@"requestId"] forKey:[self.netDataRelevant objectForKey:@"requestIdKey"]];
        }else if (self.requestId){
            [_netRequestParams setObject:self.requestId forKey:[self.netDataRelevant objectForKey:@"requestIdKey"]];
        }
    }
    
    
    [self.netDataRelevant objectForKey:@"method"]
    ? [_netRequestParams setObject:[self.netDataRelevant objectForKey:@"method"] forKey:@"method"]
    : nil;
    
    FormDataRequest* request;
    if (_isNeedCache) {
         request = [FormDataRequest requestNetURI:API_URL
                                                           params:_netRequestParams
                                                         delegate:self
                                                 finishedSelector:@selector(requestFindished:)
                                                     failSelector:@selector(webRequestFailed:)
                                                    cacheSelector:@selector(handleRequestData:)];
    }else{
        request = [FormDataRequest requestNetURI:API_URL
                                          params:_netRequestParams
                                        delegate:self
                                finishedSelector:@selector(requestFindished:)
                                    failSelector:@selector(webRequestFailed:)];
    }
    
    if (request) {
        _loadDataFinished = NO;
        [[NetRequestManager sharedInstances] addOperation:request];
        [self showLoading:nil];
    }
}
- (void)handleRequestData:(NSData*)data{
    [super handleRequestData:data];
    
    //    NSLog(@"%@",[[NSString alloc] initWithData:data  encoding:NSUTF8StringEncoding]);
    id tempData = nil;
    //处理数据
    id obj = [ECJsonParser objectWithJsonData:data];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        tempData = [obj valueForKey:@"data"];
    }
    if (tempData && [tempData isNSxxxClass:[NSDictionary class]]) {
        _dataSource = _dataSource ? _dataSource : [NSMutableDictionary new];
        [_dataSource addEntriesFromDictionary:tempData];
    }else{
        
    }
    
    [self requestMore];
    
    if (_loadDataFinished) {
        [self parseSpecialConfig];
        [self removeLoading];
    }
}
- (void) requestMore
{
    NSArray* netrequestparams = [self.netDataRelevant objectForKey:@"addData"];
    if (!_nextRequest) {
        _nextRequest = 0;
    }
    if (!netrequestparams || netrequestparams.count == 0 || netrequestparams.count - 1 < _nextRequest) {
        _loadDataFinished = YES;
        return ;
    }
    NSDictionary* requestConfigs = [netrequestparams objectAtIndex:_nextRequest ++];
    NSMutableDictionary* params = [NSMutableDictionary new];
    if ([requestConfigs objectForKey:@"requestId"] && ![[requestConfigs objectForKey:@"requestId"] isEqualToString:@""]) {
        [params setObject:[requestConfigs objectForKey:@"requestId"] forKey:[requestConfigs objectForKey:@"requestIdKey"]];
    }else{
        [params setObject:self.requestId forKey:[requestConfigs objectForKey:@"requestIdKey"]];
    }
    if (![requestConfigs objectForKey:@"method"] || [[requestConfigs objectForKey:@"method"] isEqualToString:@""]) {
        _loadDataFinished = YES;
        return ;
    }
    [params setObject:[requestConfigs objectForKey:@"method"] forKey:@"method"];
    if ([requestConfigs objectForKey:@"method"] && ![[requestConfigs objectForKey:@"method"] isEqualToString:@""]) {
        [params setObject:[requestConfigs objectForKey:@"apiversion"] forKey:@"apiversion"];
    }
    
    ECLog(@"request more date , item : %i",_nextRequest);
    FormDataRequest* request = [FormDataRequest requestNetURI:API_URL
                                                       params:params
                                                     delegate:self
                                             finishedSelector:@selector(requestFindished:)
                                                 failSelector:@selector(webRequestFailed:)
                                ];
    if (request) {
        [[NetRequestManager sharedInstances] addOperation:request];
    }
}
- (void) parseSpecialConfig
{
    
    NSString* identifier = [NSString stringWithFormat:@"%@",[self getValue:self.dataSource forKey:@"shop.cms_sort_id"]];
    if ([identifier isEqualToString:[NSString stringWithFormat:@"481"]]) {
        for (NSDictionary* item in [self.configs objectForKey:@"specialConfig"]) {
            self.configs = [NSObject replaceObjectForKey:[item objectForKey:@"key"] withObject:[item objectForKey:@"value"] inObject:self.configs];
        }
    }
    
    [self initSections];
}
/**
 * table view 初始化及控制
 */
- (void) initTableView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStyleGrouped];
    _tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    _tableView.backgroundView = nil;
    [_tableView setBackgroundColor:[UIColor colorWithHexString:[[self.configs objectForKey:@"style"] objectForKey:@"viewBg"]]];
    if (IOS7_OR_LATER) {
        _tableView.separatorColor = _tableView.backgroundColor;
        _tableView.separatorInset = UIEdgeInsetsZero;
    }
    _tableView.dataSource = self;
    _tableView.delegate = self;
    
    [self.view addSubview:_tableView];
}
#pragma UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return _sections.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return ((NSArray *)[[_sections objectAtIndex:section] objectForKey:@"cells"]).count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return  [[[_sections objectAtIndex:indexPath.section] objectForKey:@"cells"] objectAtIndex:indexPath.row];
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [[_sections objectAtIndex:section] objectForKey:@"sectionTitle"];
}
#pragma UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return ((ECSectionViewCell *)[[[_sections objectAtIndex:indexPath.section] objectForKey:@"cells"] objectAtIndex:indexPath.row]).frame.size.height;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return [[_sections objectAtIndex:section] objectForKey:@"sectionTitle"] ? HeightForSectionHeader : 10.0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 10.0;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ECSectionViewCell* cell = (ECSectionViewCell *)[_tableView cellForRowAtIndexPath:indexPath];
    NSMutableDictionary* params = [NSMutableDictionary new];
    [params addEntriesFromDictionary:self.netRequestParams];
    [params addEntriesFromDictionary:cell.config];
    self.dataSource ? [params setObject:self.dataSource forKey:@"bundleData"] : nil;
    [cell doAction:params];
}


#pragma mark- Responding to keyboard events
- (void)keyboardWillShow:(NSNotification *)notification {
    if (self != [ECPopViewUtil currentViewController]) {
        return;
    }
    /*
     Reduce the size of the text view so that it's not obscured by the keyboard.
     Animate the resize so that it's in sync with the appearance of the keyboard.
     */
    NSDictionary *userInfo = [notification userInfo];
    // Get the origin of the keyboard when it's displayed.
    NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    // Get the top of the keyboard as the y coordinate of its origin in self's view's coordinate system. The bottom of the text view's frame should align with the top of the keyboard's final position.
    CGRect keyboardRect = [aValue CGRectValue];
    // Get the duration of the animation.
    NSValue *animationDurationValue = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    NSTimeInterval animationDuration;
    [animationDurationValue getValue:&animationDuration];
    // Animate the resize of the text view's frame in sync with the keyboard's appearance.
    
//    [UIView animateKeyframesWithDuration:animationDuration
//                                   delay:0.0
//                                 options:UIViewKeyframeAnimationOptionBeginFromCurrentState
//                              animations:^{
//                                  [_tableView setFrame:CGRectMake(0, 0, validWidth(), validHeight() - keyboardRect.size.height)];
//                              }completion:^(BOOL finished) {
//                                  ;
//                              }];
    [UIView animateWithDuration:animationDuration
                     animations:^{
                         [_tableView setFrame:CGRectMake(0, 0, validWidth(), validHeight() - keyboardRect.size.height)];
                     } completion:^(BOOL finished) {
                         
                     }];
}
- (void)keyboardWillHide:(NSNotification *)notification {
    if (self != [ECPopViewUtil currentViewController]) {
        return;
    }
    NSDictionary* userInfo = [notification userInfo];
    /*
     Restore the size of the text view (fill self's view).
     Animate the resize so that it's in sync with the disappearance of the keyboard.
     */
    NSValue *animationDurationValue = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    NSTimeInterval animationDuration;
    [animationDurationValue getValue:&animationDuration];
    
//    [UIView animateKeyframesWithDuration:animationDuration
//                                   delay:0.0
//                                 options:UIViewKeyframeAnimationOptionBeginFromCurrentState
//                              animations:^{
//                                  [_tableView setFrame:CGRectMake(0, 0, validWidth(), validHeight())];
//                              }completion:^(BOOL finished) {
//                                  ;
//                              }];
    
    [UIView animateWithDuration:animationDuration
                     animations:^{
                         [_tableView setFrame:CGRectMake(0, 0, validWidth(), validHeight())];
                     } completion:^(BOOL finished) {
                         
                     }];
}
@end
