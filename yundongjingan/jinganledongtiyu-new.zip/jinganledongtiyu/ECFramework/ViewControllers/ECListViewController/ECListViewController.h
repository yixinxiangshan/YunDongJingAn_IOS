//
//  ECListViewController.h
//  DemoECEcloud
//
//  Created by EC on 3/6/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECPullingTableViewController.h"

@interface ECListViewController : ECPullingTableViewController

@end
