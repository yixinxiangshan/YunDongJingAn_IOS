//
//  ECListViewController.m
//  DemoECEcloud
//
//  Created by EC on 3/6/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECListViewController.h"
#import "ECOneLineCell.h"
#import "ECStoreCell.h"
#import "Extends.h"
#import "ECViews.h"
#import "ECNewsOneLineCell.h"
#import "ECNewsTwoLineCell.h"
#import "ECGroupCell.h"
#import "ECCommentGenCell.h"
#import "ECTwoLineTextCell.h"
#import "ECRecordCell.h"
#import "ECListViewCell.h"

@interface ECListViewController ()

@end

@implementation ECListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    [self.navigationController setWantsFullScreenLayout:NO];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - Table view data source

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if([self.cellId isEqualToString:@"ECOneLineCell"]) {
        return 44.0;
    }else if([self.cellId isEqualToString:@"ECStoreCell"]){
        return 70.0;
    }else if([self.cellId isEqualToString:@"ECNewsOneLineCell"] || [self.cellId isEqualToString:@"ECNewsTwoLineCell"] || [self.cellId isEqualToString:@"ECRecordCell"]){
        return 66.0;
    }else if ([self.cellId isEqualToString:@"ECGroupCell"] || [self.cellId isEqualToString:@"ECCommentGenCell"]){
        return 60.0;
    }else{
        Class class = NSClassFromString(self.cellId);
        return [class cellHeight];
    }
    return 44.0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    id dataItem = [self.dataSource objectAtIndex:indexPath.row];
    
    //通过配制文件获取表视图 cell 的id 
    NSString *CellIdentifier = nil;
    if (CellIdentifier == nil) {
        CellIdentifier = self.cellId;
    }
    //获取表视图 cell 的布局
    UITableViewCell *cell = nil;
    cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if ([CellIdentifier isEqualToString:@"ECOneLineCell"]) {
        
        if (cell == nil) {
            cell = (ECOneLineCell*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
        }
        ((ECOneLineCell*)cell).itemTitle.text = [dataItem objectForKey:[self.configs objectForKey:@"titleKey"]];
        // set title font
        if (nil != [self.styles objectForKey:@"cellTitleSize"] && nil != [self.styles objectForKey:@"cellTitleFont"]) {
            ((ECOneLineCell*)cell).itemTitle.font = [UIFont fontWithName:[self.styles objectForKey:@"cellTitleFont"] size:[(NSNumber*)[self.styles objectForKey:@"cellTitleSize"] floatValue]];
        }else if(nil != [self.styles objectForKey:@"cellTitleSize"]){
            ((ECOneLineCell*)cell).itemTitle.font = [UIFont systemFontOfSize:[(NSNumber*)[self.styles objectForKey:@"cellTitleSize"] floatValue]];
        }
        // set title color
        if (nil != [self.styles objectForKey:@"cellTitleColor"] ) {
            [((ECOneLineCell*)cell).itemTitle setTextColor:[UIColor colorWithHex:[(NSNumber*)[self.styles objectForKey:@"cellTitleColor"] integerValue]]];
        }
        // set title alignment
        if ([[self.styles objectForKey:@"cellTitleAlignment"] isEqualToString:@"center"]) {
            [((ECOneLineCell*)cell).itemTitle setTextAlignment:NSTextAlignmentNatural];
        }else if([[self.styles objectForKey:@"cellTitleAlignment"] isEqualToString:@"left"]){
            [((ECOneLineCell*)cell).itemTitle setTextAlignment:NSTextAlignmentLeft];
        }else{
            [((ECOneLineCell*)cell).itemTitle setTextAlignment:NSTextAlignmentRight];
        }
        [((ECOneLineCell*)cell).cellBg setImage:[UIImage imageNamed:[self.styles objectForKey:@"cellBg"]]];
    }else
        if ([CellIdentifier isEqualToString:@"ECStoreCell"]){
            if (cell == nil) {
                cell = (ECStoreCell*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
            }
            ((ECStoreCell*)cell).storeTitle.text = [dataItem objectForKey:[self.configs objectForKey:@"titleKey"]];
            
            if (nil != [self.styles objectForKey:@"locationIconName"] && ![@"" isEqualToString:[self.styles objectForKey:@"locationIconName"]]) {
                ((ECStoreCell*)cell).locationIcon.image = [UIImage imageNamed:[self.styles objectForKey:@"locationIconName"]];
            }
            NSString* distanceKey = @"distance";  // default value
            if (nil != [self.configs objectForKey:@"distanceKey"]) {
                distanceKey = [self.configs objectForKey:@"distanceKey"];
            }
            
            if ([dataItem objectForKey:distanceKey] != nil) {
                ((ECStoreCell*)cell).distanceLable.text = [dataItem objectForKey:distanceKey];
            }else{
                ((ECStoreCell*)cell).distanceLable.text = @"";
            }
        }else
            if ([CellIdentifier isEqualToString:@"ECNewsOneLineCell"]){
                if (cell == nil) {
                    cell = (ECNewsOneLineCell*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
                }
                ((ECNewsOneLineCell*)cell).titleLabel.text = [self getValue:dataItem forKey:[self.configs objectForKey:@"titleKey"]];
                
                [((ECNewsOneLineCell*)cell).image setImage:[UIImage imageNamed:kDefaultImage]];
                if ([dataItem objectForKey:[self.configs objectForKey:@"imageKey"]] && ![[dataItem objectForKey:[self.configs objectForKey:@"imageKey"]] isEqual:@""]) {
                    NSString* imageName = [self getValue:dataItem forKey:[self.configs objectForKey:@"imageKey"]];
                    if (imageName) {
                        NSString* imageuri = [ECUriUtil getSmallImageUrl:imageName];
                        [((ECNewsOneLineCell*)cell).image updateWithNormalImageURI:imageuri];
                        [((ECNewsOneLineCell*)cell).image setClipsToBounds:YES];
                    }
                }
                
            }else
                if ([CellIdentifier isEqualToString:@"ECNewsTwoLineCell"]){
                    if (cell == nil) {
                        cell = (ECNewsTwoLineCell*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
                    }
                    ((ECNewsTwoLineCell*)cell).titleLabel.text = [self getValue:dataItem forKey:[self.configs objectForKey:@"titleKey"]];
                    
                    [((ECNewsTwoLineCell*)cell).image setImage:[UIImage imageNamed:kDefaultImage]];
                    NSString* imageName = [self getValue:dataItem forKey:[self.configs objectForKey:@"imageKey"]];
                    if (imageName && ![imageName isEqual:@""]) {
                        NSString* imageuri = [ECUriUtil getSmallImageUrl:imageName];
                        [((ECNewsTwoLineCell*)cell).image updateWithNormalImageURI:imageuri];
                        [((ECNewsTwoLineCell*)cell).image setClipsToBounds:YES];
                    }
                    ((ECNewsTwoLineCell*)cell).timeLabel.text = [self getValue:dataItem forKey:[self.configs objectForKey:@"timeKey"]];
                    ((ECNewsTwoLineCell*)cell).contentLabel.text = [self getValue:dataItem forKey:[self.configs objectForKey:@"contentKey"]];
                }else
                    if ([CellIdentifier isEqualToString:@"ECGroupCell"]){
                        if (cell == nil) {
                            cell = (ECGroupCell*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
                        }
                        ((ECGroupCell*)cell).firstTitle.text = [dataItem objectForKey:[self.configs objectForKey:@"titleKey"]];
                        ((ECGroupCell*)cell).secondTitle.text = [dataItem objectForKey:[self.configs objectForKey:@"contentKey"]];
                    }else
                        if ([self.cellId isEqualToString:@"Cell"]){
                            if (cell == nil) {
                                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                            }
                            cell.textLabel.text = [dataItem objectForKey:[self.configs objectForKey:@"titleKey"]];
                        }else
                            if ([CellIdentifier isEqualToString:@"ECCommentGenCell"]){
                                if (cell == nil) {
                                    cell = (ECCommentGenCell*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
                                }
                                
                                NSString* number = [dataItem objectForKey:[self.configs objectForKey:@"titleKey"]];
                                if (number && number.length == 11) {
                                    number = [number stringByReplacingCharactersInRange:NSMakeRange(3, 4) withString:@"****"];
                                }
                                ((ECCommentGenCell*)cell).titleLabel.text = number;
                                
                                //          [((ECCommentGenCell*)cell).image setImage:[UIImage imageNamed:kDefaultImage]];
                                
                                NSString* imageName = [dataItem objectForKey:[self.configs objectForKey:@"imageKey"]];
                                if (imageName && ![imageName isEqual:@""]) {
                                    NSString* imageuri = [ECUriUtil getSmallImageUrl:imageName];
                                    [((ECCommentGenCell*)cell).image updateWithNormalImageURI:imageuri];
                                    [((ECCommentGenCell*)cell).image setClipsToBounds:YES];
                                }
                                ((ECCommentGenCell*)cell).timeLabel.text = [dataItem objectForKey:[self.configs objectForKey:@"timeKey"]];
                                ((ECCommentGenCell*)cell).contentLabel.text = [dataItem objectForKey:[self.configs objectForKey:@"contentKey"]];
                                
                            }else
                                if ([CellIdentifier isEqualToString:@"ECTwoLineTextCell"]){
                                    if (cell == nil) {
                                        cell = (ECTwoLineTextCell*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
                                    }
                                    ((ECTwoLineTextCell*)cell).titleLabel.text = [self getValue:dataItem forKey:[self.configs objectForKey:@"titleKey"]];
                                    ((ECTwoLineTextCell*)cell).timeLabel.text = [self getValue:dataItem forKey:[self.configs objectForKey:@"timeKey"]];
                                    ((ECTwoLineTextCell*)cell).contentLabel.text = [self getValue:dataItem forKey:[self.configs objectForKey:@"contentKey"]];
                                }
    else if ([CellIdentifier isEqualToString:@"ECRecordCell"])
    {
        if (cell == nil) {
            cell = (ECRecordCell*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
        }
        ((ECRecordCell*)cell).title.text = [self getValue:dataItem forKey:[self.configs objectForKey:@"titleKey"]];
        ((ECRecordCell*)cell).content.text = [self getValue:dataItem forKey:[self.configs objectForKey:@"contentKey"]];
    }else{
        if (cell == nil) {
            Class class = NSClassFromString(CellIdentifier);
            cell = [[class alloc] initWithConfig:self.configs dataSource:dataItem];
        }else{
            [(ECListViewCell *)cell setConfig:self.configs dataSource:dataItem];
        }
    }
    
//    cell.selectionStyle = UITableViewCellSelectionStyleGray;
    return cell;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString* cellTitle ;
    NSString* tag = @"";
    if ([self.cellId isEqualToString:@"Cell"]) {
        
    }else{
        
    }
    
    NSLog(@"Do click......");
    
    NSMutableDictionary* params = [NSMutableDictionary new];
    if (indexPath.section == 0 ) {
        NSDictionary* dataItem = [self.dataSource objectAtIndex:indexPath.row];
        // gen params pass to next ctrl
        cellTitle = [self getValue:dataItem forKey:[self.configs objectForKey:@"titleKey"]];
        [params setObject:[self getValue:dataItem forKey:[self.configs objectForKey:@"contentIdKey"]] forKey:@"requestId"];
        
    }else {
        cellTitle = [tableView cellForRowAtIndexPath:indexPath].textLabel.text;
    }
    [params setObject:cellTitle forKey:@"navTitle"];
    
    NSURL *PlistURL = [[NSBundle mainBundle] URLForResource:@"SpeEventTagConfig" withExtension:@"plist"];
    NSDictionary* speEventTag =  [NSDictionary dictionaryWithContentsOfURL:PlistURL];
    NSEnumerator* enumerator = [speEventTag keyEnumerator];
    for (NSString *key in enumerator) {
        if ([cellTitle rangeOfString:key].location != NSNotFound) {
            tag = [speEventTag objectForKey:key];
        }
    }
    NSLog(@"Message : %@ ",[NSString stringWithFormat:@"%@.%@.itemClick%@",self.instanceName,NSStringFromClass([self class]),tag]);

    [[NSNotificationCenter defaultCenter] postNotificationName:[NSString stringWithFormat:@"%@.%@.itemClick%@",self.instanceName,NSStringFromClass([self class]),tag] object:nil userInfo:params];
    
}

#pragma mark -Pulling Refresh Table view delegate
// pull down to refresh
- (void)pullingTableViewDidStartRefreshing:(PullingRefreshTableView *)tableView{
    [super pullingTableViewDidStartRefreshing:tableView];
}

//Implement this method if headerOnly is false,pull up to loading more
- (void)pullingTableViewDidStartLoading:(PullingRefreshTableView *)tableView{
    [super pullingTableViewDidStartLoading:tableView];
}

@end
