//
//  ECSectionListViewController.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-22.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSectionListViewController.h"
#import "ECTwoLabelCell.h"
#import "ECEventRouter.h"

@interface ECSectionListViewController ()

@property (strong, nonatomic) NSDictionary* localDataConfig;
@property (strong, nonatomic) NSDictionary* staticDataFromServer;

@property (strong, nonatomic) ECImageContainer* imageView;
@property CGFloat imageHeight;
@property BOOL isImageLoaded;

@end

@implementation ECSectionListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
    _stableDataResource = [NSArray arrayWithObjects:@"联系电话",@"地址",nil];
    self.imageHeight = 166;
    self.isImageLoaded = NO;
    [super viewDidLoad];
    
    self.localDataConfig = [[self.configs objectForKey:@"localData"] objectForKey:@"localDataConfig"];
	// Do any additional setup after loading the view.
    
//    [self addFavButton];
    
}

-(void) initNetRequestParams
{
    [super initNetRequestParams];
    
    NSDictionary* netDataRelevant = [self.configs objectForKey:@"netDataRelevant"];
    
    [self.netRequestParams setValue:[netDataRelevant valueForKey:@"method"] forKey:@"method"];
    [self.netRequestParams setValue:self.requestId forKey:[netDataRelevant valueForKey:@"requestIdKey"]];
}


#pragma mark - Table view data source

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{

    if (indexPath.section == 0) {
        return self.imageHeight;
    }else if (indexPath.section == 4){
        return [self tableView:tableView viewForHeaderInSection:indexPath.section].frame.size.height;
    }else if (indexPath.section ==3){
        return 44;
    }
    else{
        return [super tableView:tableView heightForRowAtIndexPath:indexPath];
    }
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView{
    return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    if (section == 1) {
        return [self.dataSource count];
    }else
    if (section == 2) {
        return [_stableDataResource count];
    }else
    if (section == 3) {
        return 1;
    }else
    if (section == 0) {
        return 1;
    }else
        if (section == 4 ) {
            return 1;
        }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"ECTwoLabelCell";
    ECTwoLabelCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = (ECTwoLabelCell*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];;
    }
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    // Configure the cell...
    if (indexPath.section == 1) {
        NSDictionary* dataItem = [self.dataSource objectAtIndex:indexPath.row];
        cell.leftLabel.text = [dataItem objectForKey:[self.configs objectForKey:@"titleKey"]];
        cell.rightLabel.text = [dataItem objectForKey:[self.configs objectForKey:@"propertyKey"]];
        cell.rightLabel.textAlignment = UITextAlignmentCenter;
        
    }else if(indexPath.section == 2){
        
        cell.leftLabel.text = [NSString stringWithFormat:@"%@",[_stableDataResource objectAtIndex:indexPath.row]];
//        NSLog(@"+++++++++++%i",indexPath.row);
        switch (indexPath.row) {
            case 0:
                cell.rightLabel.text = [self.staticDataFromServer objectForKey:@"phone_num"];
                break;
            case 1: cell.rightLabel.text = [self.staticDataFromServer objectForKey:@"address"];
                //是否接受事件
                if ([[self.configs valueForKey:@"isNeedToMap"] boolValue]) {
                    break;
                }
                cell.userInteractionEnabled = NO;
                cell.accessoryType = UITableViewCellAccessoryNone;
                break;
            default:
                break;
        }
    }else if (indexPath.section == 4 ){
        [cell removeAllSubViews];
        
//        UILabel* introduction = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, 300, 24)];
//        introduction.text = [self.staticDataFromServer valueForKey:@"content"];
//        [introduction sizeToFit];

        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.hidden = YES;
//        [cell addSubview:introduction];
    }else if (indexPath.section == 0){
        [cell removeAllSubViews];
        cell.accessoryType = UITableViewCellAccessoryNone;
        NSString* imageName = [self.staticDataFromServer valueForKey:[self.localDataConfig valueForKey:@"imageKey"]];
        if (!self.isImageLoaded) {
            self.imageView = [[ECImageContainer alloc] initWithFrame:CGRectMake(10, 0, validWidth()-20, self.imageHeight)];
            [self.imageView setImage:[UIImage imageNamed:kDefaultImage]];
            if (imageName != nil && ![imageName isEqualToString:@""]) {
                
                [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(imageContainerFrameChanged:) name:kImageContainerFrameChangedNoti object:nil];
                
                [self.imageView updateWithNormalImageURI:[ECUriUtil getDefaultImageUrl:imageName]];
                
            }
            
        }else{
            [self.imageView setFrame:CGRectMake(10, 0, validWidth()-20, self.imageHeight)];
            [self.imageView updateWithNormalImageURI:[ECUriUtil getDefaultImageUrl:imageName]];            
        }
        [cell setFrame:self.imageView.frame];
        [cell addSubview:self.imageView];
    }else if (indexPath.section == 3){
        cell.leftLabel.text = @"查看所有评论";
    }
    
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    return cell;
}
- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 4) {
        NSString* identifier = [NSString stringWithFormat:@"%@",[self.staticDataFromServer valueForKey:@"cms_sort_id"] ];
        NSString *sectionTitle;
        if ([identifier isEqualToString:[NSString stringWithFormat:@"481"]]) {
            sectionTitle = @"加油站介绍";
        }else {
            sectionTitle = @"场馆介绍";
        }
       
        
        UILabel * label = [[UILabel alloc] init];
        label.frame = CGRectMake(10, 0, 300, 22);
    label.backgroundColor = [UIColor clearColor];
        //    label.backgroundColor = [UIColor redColor];
        label.font=[UIFont fontWithName:@"Helvetica-Bold" size:15];
        label.text = sectionTitle;
        
        UILabel* content = [[UILabel alloc] initWithFrame:CGRectMake(10, 30, 300, 44)];
        content.numberOfLines = 0;
        content.backgroundColor = [UIColor clearColor];
        content.font = [UIFont fontWithName:@"Helvetica" size:13];
        content.text = [self.staticDataFromServer valueForKey:[self.localDataConfig valueForKey:@"introductionKey"]];
        [content sizeToFit];
        
        UIView * sectionView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 44+content.frame.size.height)];
        [sectionView setBackgroundColor:[UIColor clearColor]];
        [sectionView addSubview:label];
        [sectionView addSubview:content];
        return sectionView;
    }
    return nil;
}
- (void)imageContainerFrameChanged:(NSNotification*)noti
{
    

    id obj = [noti object];
    if (obj && [obj isEqual:self.imageView]) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
        if (self.imageView.image!=nil) {
            CGFloat showHeight = self.imageView.frame.size.width*self.imageView.image.size.height/self.imageView.image.size.width;
            
            self.imageHeight = showHeight;
            self.isImageLoaded = YES;
            
            [self showTableView];
        } else {
            return;
        }
    }
}
- (void)showTableView{
    self.tableView = [[ECPullingTableView alloc] initWithFrame:CGRectMake(0, 0, validWidth(), validHeight()) style:UITableViewStyleGrouped];
    [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.pullingDelegate = self;
    
    [self.view addSubview:self.tableView];
    
        
}

-(void)setShareAuthCom:(NSDictionary*)params
{
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)handleRequestData:(NSData*)data{

    
    id tempData = nil;
    //处理数据
    id obj = [ECJsonParser objectWithJsonData:data];
    
    //    NSLog(@"%@ : %@",self.class,obj);
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        tempData = [obj valueForKey:@"data"];
    }
    if (tempData && [tempData isNSxxxClass:[NSDictionary class]]) {
        
        id dataArray = [self getValue:tempData forKey:[self.localDataConfig objectForKey:@"dataKey"]];
        
        //        [tempData objectForKey:[self.configs objectForKey:@"listKey"]];
        
        if (dataArray && [dataArray isNSxxxClass:[NSDictionary class]]) {
            self.staticDataFromServer = dataArray;
        }
    }else if (tempData && [tempData isNSxxxClass:[NSArray class]])
    {
        id dataArray = tempData;
        //        NSLog(@"%@ : %@",self.class,dataArray);
        if (dataArray && [dataArray isNSxxxClass:[NSDictionary class]]) {
            self.staticDataFromServer = dataArray;
            
//            [self showTableView];
        }
        
    }
    else{
        //TODO: 弹出数据出错！
    }
        [super handleRequestData:data];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 2 && indexPath.row == 0) {
        
        [[ECEventRouter shareInstance] doAction:[NSString stringWithFormat:@"eccm://eccmc?method=tel&requestId=%@&phoneNumber=%@",self.requestId,[self.staticDataFromServer objectForKey:@"phone_num"]] userInfo:nil];
        return;
    }else
    
    if (indexPath.section == 2 && indexPath.row == 1) {
        
        [[ECEventRouter shareInstance] doAction:[NSString stringWithFormat:@"ecct://addressinmap?configName=ECAddressInMapConfig"] userInfo:self.staticDataFromServer];
        return;
    }else
    if (indexPath.section == 3) {
        
        NSMutableDictionary* params = [NSMutableDictionary new];
        [params setValue:self.requestId forKey:@"requestId"];
        
        [[ECEventRouter shareInstance] doAction:@"ecct://commentList?configName=ECComnentListConfig" userInfo:params];
    }else
    
    if (indexPath.section == 1) {
        [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
        NSString* cellTitle ;
        NSString* tag = @"";
        if ([self.cellId isEqualToString:@"Cell"]) {
            
        }else{
            
        }
        
        NSLog(@"Do click......");
        
        NSMutableDictionary* params = [NSMutableDictionary new];
        if (indexPath.section == 1 ) {
            NSDictionary* dataItem = [self.dataSource objectAtIndex:indexPath.row];
            // gen params pass to next ctrl
            cellTitle = [self getValue:dataItem forKey:[self.configs objectForKey:@"titleKey"]];
            [params setObject:[self getValue:dataItem forKey:[self.configs objectForKey:@"contentIdKey"]] forKey:@"requestId"];
            
        }else {
            cellTitle = [tableView cellForRowAtIndexPath:indexPath].textLabel.text;
        }
        [params setObject:cellTitle forKey:@"navTitle"];
        
        NSURL *PlistURL = [[NSBundle mainBundle] URLForResource:@"SpeEventTagConfig" withExtension:@"plist"];
        NSDictionary* speEventTag =  [NSDictionary dictionaryWithContentsOfURL:PlistURL];
        NSEnumerator* enumerator = [speEventTag keyEnumerator];
        for (NSString *key in enumerator) {
            if ([cellTitle rangeOfString:key].location != NSNotFound) {
                tag = [speEventTag objectForKey:key];
            }
        }
        NSLog(@"Message : %@ ",[NSString stringWithFormat:@"%@.%@.itemClick%@",self.instanceName,NSStringFromClass([self class]),tag]);
        if (![[NSString stringWithFormat:@"%@",[self.staticDataFromServer valueForKey:@"cms_sort_id"]] isEqual:@"481"]) {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"showCourseCoupon" object:nil userInfo:params];
            return;
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:[NSString stringWithFormat:@"%@.%@.itemClick%@",self.instanceName,NSStringFromClass([self class]),tag] object:nil userInfo:params];
        

    }
}
-(void) addFavButton
{
    if (![[self.localDataConfig valueForKey:@"isWithFavButton"] boolValue]) {
        return;
    }
    UIButton* favButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [favButton setImage:[UIImage imageNamed:@"star.png"] forState:UIControlStateNormal];
    [favButton setFrame:CGRectMake(0, 0, 44, 44)];
    
    [favButton addTarget:self action:@selector(addFav:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem* rightItem = [[UIBarButtonItem alloc] initWithCustomView:favButton];
    [self.navigationItem setRightBarButtonItem:rightItem];
}
-(void)addFav:(id)sender
{
    [[ECEventRouter shareInstance] doAction:[NSString stringWithFormat:@"eccm://eccmc?method=addfav&requestId=%@",self.requestId] userInfo:nil];
}
@end
