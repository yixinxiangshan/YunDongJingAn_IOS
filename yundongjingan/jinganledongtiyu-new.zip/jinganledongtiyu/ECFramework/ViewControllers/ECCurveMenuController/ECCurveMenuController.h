//
//  ECCurveMenuController.h
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-6-24.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "ECBaseViewExtendController.h"
#import "QuadCurveMenu.h"

@interface ECCurveMenuController : ECBaseViewExtendController <QuadCurveMenuDelegate>

@property (nonatomic, strong) QuadCurveMenu *menu;
@property (nonatomic, strong) UIView* containerView;
@property (nonatomic, strong) NSMutableArray* viewControllersConfig;
@property (nonatomic, strong) NSMutableArray* itemsConfig;
@property (nonatomic, assign) NSInteger count;


@end
