//
//  ECCurveMenuController.m
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-6-24.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "ECCurveMenuController.h"

#define TAG "ECCurveMenuController"

@implementation ECCurveMenuController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //  R.oshan  Label
    NSLog(@"%s : Data init Done",TAG);
    
    //    [self.navigationController setNavigationBarHidden:YES];
	// Do any additional setup after loading the view.
    
//    [self showBackGround];
    [self backgroundAnimations];
    
    // parsing config file
    _itemsConfig = [self.configs objectForKey:@"MenuItems"];
    _count = _itemsConfig.count;
    
    [self initMenu];
    [self.view addSubview:self.menu];
    
}

- (void) initMenu
{  
    NSMutableArray *menus = [[NSMutableArray alloc] init];
   

    for (int i = 0 ; i < _count ; i ++) { 
        
        // Camera MenuItem.
        NSDictionary *menuItem = [_itemsConfig objectAtIndex:i];
        QuadCurveMenuItem *MenuItem = [[QuadCurveMenuItem alloc] initWithImage:[UIImage imageNamed:@"mainmenuitembackground"]
                                                              highlightedImage:nil
                                                                  ContentImage:[UIImage imageNamed:[menuItem objectForKey:@"image"]]
                                                       highlightedContentImage:nil
                                                                         label:[menuItem objectForKey:@"title"]];
        [menus addObject:MenuItem];
    }
    
    // Camera MenuItem.
    NSLog(@"MenuItem count : %i",menus.count);
    self.menu = [[QuadCurveMenu alloc] initWithFrame:[[UIScreen mainScreen] bounds] menus:menus];
    self.menu.delegate = self;
}

#pragma mark QuadCurveMenuDelegate
- (void)quadCurveMenu:(QuadCurveMenu *)menu didSelectIndex:(NSInteger)idx
{
//    self.navTitle = [[_itemsConfig objectAtIndex:idx] objectForKey:@"title"];
//    [self.navigator openURL:[NSURL URLWithString:[[self.viewControllersConfig objectAtIndex:idx] valueForKey:@"viewUrl"]]];
//    NSLog(@"Select the index : %@",[[self.viewControllersConfig objectAtIndex:idx] valueForKey:@"viewUrl"]);
   
    NSDictionary* menuItem = [_itemsConfig objectAtIndex:idx];
    NSMutableDictionary* params = [NSMutableDictionary new];
    [params setObject:[menuItem objectForKey:@"title"] forKey:@"navTitle"];
    
    [[ECEventRouter shareInstance] doAction:[menuItem valueForKey:@"action"] userInfo:params];
    
}

-(void) showBackGround
{
    [self.view setBackgroundColor:[UIColor colorWithRed:0.15 green:0.56 blue:0.74 alpha:1.00]];
    
    UIImageView* splash_uper = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"splash_uper"]];
    [splash_uper setFrame:CGRectMake((validWidth()-splash_uper.frame.size.width)/2, (validHeight()/11), splash_uper.frame.size.width, splash_uper.frame.size.height)];
    [self.view addSubview:splash_uper];
    
    UIImageView* splash_under = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"splash_under"]];
    [splash_under setFrame:CGRectMake((validWidth() - splash_under.frame.size.width)/2, splash_uper.frame.origin.y+splash_uper.frame.size.height+validHeight()/20, splash_under.frame.size.width, splash_under.frame.size.height)];
    [self.view addSubview:splash_under];
    
}

//动画效果
-(void) backgroundAnimations
{
    [self.view setBackgroundColor:[UIColor colorWithRed:0.15 green:0.56 blue:0.74 alpha:1.00]];
    
    UIImageView* splash_uper = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"splash_uper"]];
    [splash_uper setFrame:CGRectMake((validWidth()-splash_uper.frame.size.width)/2, (validHeight()/5), splash_uper.frame.size.width, splash_uper.frame.size.height)];
    [self.view addSubview:splash_uper];
    
    UIImageView* splash_under = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"splash_under"]];
    [splash_under setFrame:CGRectMake((validWidth() - splash_under.frame.size.width)/2, splash_uper.frame.origin.y+splash_uper.frame.size.height+validHeight()/10, splash_under.frame.size.width, splash_under.frame.size.height)];
    [self.view addSubview:splash_under];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:2.0];
    CGAffineTransform moveTransform_uper = CGAffineTransformMakeTranslation(0, validHeight()/11-validHeight()/5);
    CGAffineTransform moveTransform_under = CGAffineTransformMakeTranslation(0, validHeight()/11-validHeight()/5-validHeight()/20);
    [splash_uper.layer setAffineTransform:moveTransform_uper];
    [splash_under.layer setAffineTransform:moveTransform_under];
    [UIView commitAnimations];
    
}

@end
