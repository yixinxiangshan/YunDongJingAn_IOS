//
//  ECLoginView.m
//  JingAnWeekly
//
//  Created by EC on 3/20/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECLoginView.h"

@implementation ECLoginView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [[NSBundle mainBundle] loadNibNamed:@"ECLoginView" owner:self options:nil];
        [self addSubview:_userName];
        [self addSubview:_secretlabel];
        [self addSubview:_confirmSecret];
        [self addSubview:_loginBt];
        [self addSubview:_registerBt];
        
        [_userName setReturnKeyType:UIReturnKeyNext];
        
        [_confirmSecret setReturnKeyType:UIReturnKeyDone];
        
        [self setBackgroundColor:[UIColor whiteColor]];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (IBAction)loginConfirm:(UIButton *)sender {
    if (_loginDelegate && [_loginDelegate respondsToSelector:@selector(submitLogin:)]) {
        [_loginDelegate submitLogin:self];
    }
}

- (IBAction)registerConfirm:(UIButton *)sender {
    if (_loginDelegate && [_loginDelegate respondsToSelector:@selector(submitRegister:)]) {
        [_loginDelegate submitRegister:self];
    }
}

- (void) drawRect:(CGRect)rect
{
    self.userName.layer.borderColor = [[UIColor darkGrayColor] CGColor];
    self.secretlabel.layer.borderColor = [[UIColor darkGrayColor] CGColor];
    self.confirmSecret.layer.borderColor = [[UIColor darkGrayColor] CGColor];
    
    self.userName.layer.cornerRadius = 5.0;
    self.secretlabel.layer.cornerRadius = 5.0;
    self.confirmSecret.layer.cornerRadius = 5.0;
    
    self.userName.layer.borderWidth = 1.0;
    self.secretlabel.layer.borderWidth = 1.0;
    self.confirmSecret.layer.borderWidth = 1.0;
    
}
@end
