//
//  ECLoginView.h
//  JingAnWeekly
//
//  Created by EC on 3/20/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ECLoginView;
@protocol ECLoginViewDelegate <NSObject>

@required
-(void)submitLogin:(ECLoginView*)loginView;
-(void)submitRegister:(ECLoginView *)loginView;

@end

@interface ECLoginView : UIView

@property (strong, nonatomic) id <ECLoginViewDelegate> loginDelegate;

@property (weak, nonatomic) IBOutlet UITextField *userName;
@property (weak, nonatomic) IBOutlet UITextField *secretlabel;
@property (weak, nonatomic) IBOutlet UITextField *confirmSecret;
@property (weak, nonatomic) IBOutlet UIButton *loginBt;
@property (weak, nonatomic) IBOutlet UIButton *registerBt;

- (IBAction)loginConfirm:(UIButton *)sender;
- (IBAction)registerConfirm:(UIButton *)sender;


@end
