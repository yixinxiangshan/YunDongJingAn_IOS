//
//  ECStoreCell.h
//  DemoECEcloud
//
//  Created by EC on 3/13/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ECStoreCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *locationIcon;
@property (weak, nonatomic) IBOutlet UILabel *distanceLable;
@property (weak, nonatomic) IBOutlet UILabel *storeTitle;
@end
