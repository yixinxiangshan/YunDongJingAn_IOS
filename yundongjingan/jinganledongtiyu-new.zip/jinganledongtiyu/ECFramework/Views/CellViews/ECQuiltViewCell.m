//
//  ECQuiltViewCell.m
//  JingAnWeekly
//
//  Created by Angel on 13-5-22.
//  Copyright (c) 2013年 ecloud. All rights reserved.
//

#import "ECQuiltViewCell.h"


@implementation ECQuiltViewCell

@synthesize imageContainer ;
@synthesize titleLabel ;
@synthesize contentLabel ;
@synthesize QuiltCellViewMargin ;
- (void)dealloc {
     imageContainer = nil;
    titleLabel = nil;
    contentLabel = nil;
}

- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithReuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

//- (ECImageContainer *)imageContainer {
//    
//    if (!imageContainer) {
//        imageContainer = [[ECImageContainer alloc] init];
////        imageContainer.contentMode = UIViewContentModeScaleAspectFill;
////        imageContainer.clipsToBounds = YES;
//        [self addSubview:imageContainer];
//    }
//    return imageContainer;
//}

- (UILabel *)titleLabel {
    if (!titleLabel) {
        titleLabel = [[UILabel alloc] init];
        titleLabel.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
        titleLabel.textColor = [UIColor whiteColor];
        titleLabel.textAlignment = UITextAlignmentCenter;
        [self addSubview:titleLabel];
    }
    return titleLabel;
}

- (void)layoutSubviews {
    self.imageContainer.frame = CGRectInset(self.bounds, QuiltCellViewMargin, QuiltCellViewMargin);
    self.titleLabel.frame = CGRectMake(QuiltCellViewMargin, self.bounds.size.height - 20 - QuiltCellViewMargin,
                                       self.bounds.size.width - 2 * QuiltCellViewMargin, 20);
}

@end
