//
//  ECRecordCell.h
//  jinganledongtiyu
//
//  Created by cww on 13-7-18.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ECRecordCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *content;

@property (weak, nonatomic) IBOutlet UIView *containerView;
@end
