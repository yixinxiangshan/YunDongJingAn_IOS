//
//  ECRecordCell.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-18.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECRecordCell.h"
#import <QuartzCore/QuartzCore.h>

@implementation ECRecordCell
@synthesize containerView;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
    //设置圆角边框
    containerView.layer.cornerRadius = 3;
    containerView.layer.masksToBounds = YES;
    //设置边框及边框颜色
    containerView.layer.borderWidth = 1;
    containerView.layer.borderColor =[ [UIColor lightGrayColor] CGColor];
    
}
@end
