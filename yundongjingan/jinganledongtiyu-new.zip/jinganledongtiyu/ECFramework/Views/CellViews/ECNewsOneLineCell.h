//
//  ECNewsOneLineCell.h
//  DemoECEcloud
//
//  Created by EC on 3/4/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ECImageContainer.h"
#import "ECBadgeView.h"

@interface ECNewsOneLineCell : UITableViewCell

@property (strong, nonatomic) IBOutlet ECImageContainer* image;
@property (strong, nonatomic) IBOutlet UILabel*     titleLabel;

@property (strong, nonatomic) IBOutlet ECBadgeView* badgeView;

@end
