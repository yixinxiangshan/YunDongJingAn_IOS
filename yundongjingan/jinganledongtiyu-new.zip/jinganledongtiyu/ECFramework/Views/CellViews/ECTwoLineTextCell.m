//
//  ECTwoLineTextCell.m
//  JingAnWeekly
//
//  Created by EC on 5/3/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECTwoLineTextCell.h"

@implementation ECTwoLineTextCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

+ (CGFloat) cellHeight
{
    return 44.0;
}
@end
