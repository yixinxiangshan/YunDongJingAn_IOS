//
//  ECTwoLineTextCell.h
//  JingAnWeekly
//
//  Created by EC on 5/3/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ECTwoLineTextCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;

+ (CGFloat) cellHeight;
@end
