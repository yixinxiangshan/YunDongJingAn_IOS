//
//  ECNewsTwoLineCell.m
//  JingAnWeekly
//
//  Created by EC on 3/18/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECTwoLineImageCell.h"

@implementation ECTwoLineImageCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (id) init
{
    self = [[[NSBundle mainBundle] loadNibNamed:@"ECTwoLineImageCell" owner:self options:nil] lastObject];
    return self;
}

- (void) initContent
{
    self.titleLabel.text = [self getValue:self.dataSource forKey:[self.config objectForKey:@"titleKey"]];
    
    [self.image setImage:[UIImage imageNamed:kDefaultImage]];
    NSString* imageName = [self getValue:self.dataSource forKey:[self.config objectForKey:@"imageKey"]];
    if (imageName && ![imageName isEqual:@""]) {
        NSString* imageuri = [ECUriUtil getSmallImageUrl:imageName];
        [self.image updateWithNormalImageURI:imageuri];
        [self.image setClipsToBounds:YES];
    }
    self.timeLabel.text = [self getValue:self.dataSource forKey:[self.config objectForKey:@"timeKey"]];
    self.contentLabel.text = [self getValue:self.dataSource forKey:[self.config objectForKey:@"contentKey"]];
}

+ (CGFloat) cellHeight
{
    return 66.0;
}
@end
