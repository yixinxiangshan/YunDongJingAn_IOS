//
//  ECListViewCell.m
//  jinganledongtiyu
//
//  Created by cheng on 13-12-18.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECListViewCell.h"

@implementation ECListViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (id) initWithConfig:(NSDictionary *)config dataSource:(NSDictionary *)dataSource
{
    self = [[[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil] lastObject];
    self.config = config;
    self.dataSource = dataSource;
    
    [self initContent];
    return self;
}
- (void) setConfig:(NSDictionary *)config dataSource:(NSDictionary *)dataSource
{
    self.config = config;
    self.dataSource = dataSource;
    
    [self initContent];
}

- (void) initContent
{
}

-(id)getValue:(NSDictionary *)data forKey:(NSString *)key
{
    if (nil == key || [key isEqual:@""]) {
        return nil;
    }
    int location = [key rangeOfString:@"."].location;
    
    if (location == NSNotFound) {
        NSLog(@"value %@ fromkey : %@",[data valueForKey:key],key);
        return [data valueForKey:key];
    }else{
        NSString* forwardKey = [key substringToIndex:location];
        NSString* behandkey = [key substringFromIndex:location+1];
        //递归
        NSDictionary* subData = [data valueForKey:forwardKey];
        return [self getValue:subData forKey:behandkey];
    }
    return nil;
}


+ (CGFloat) cellHeight
{
    return 44.0;
}
@end
