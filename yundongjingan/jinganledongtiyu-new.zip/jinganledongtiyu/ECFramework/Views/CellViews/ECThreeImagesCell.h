//
//  ECThreeImagesCell.h
//  DemoECEcloud
//
//  Created by EC on 3/5/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ECImageContainer.h"
#import "ECIndexPath.h"

@protocol GridViewDelegate <NSObject>

@required
- (void) selectImage:(ECIndexPath*)indexPath;

@end

@interface ECThreeImagesCell : UITableViewCell

@property (strong, nonatomic) id<GridViewDelegate> delegate;
@property (strong, nonatomic) ECIndexPath* indexPath;

@property (weak, nonatomic) IBOutlet ECImageContainer *itemImage1;
@property (weak, nonatomic) IBOutlet UIImageView *image1;
@property (weak, nonatomic) IBOutlet UILabel *itemLabel1;
@property (weak, nonatomic) IBOutlet ECImageContainer *itemImage2;
@property (weak, nonatomic) IBOutlet UIImageView *image2;
@property (weak, nonatomic) IBOutlet UILabel *itemLabel2;
@property (weak, nonatomic) IBOutlet ECImageContainer *itemImage3;
@property (weak, nonatomic) IBOutlet UIImageView *image3;
@property (weak, nonatomic) IBOutlet UILabel *itemLabel3;

@end
