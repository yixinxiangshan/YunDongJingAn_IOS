//
//  ECThreeImagesCell.m
//  DemoECEcloud
//
//  Created by EC on 3/5/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECThreeImagesCell.h"
#import "Utils.h"
#import <objc/runtime.h>
#import <objc/message.h>
#import <QuartzCore/QuartzCore.h>

@implementation ECThreeImagesCell


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
    
    ECLog(@"设置点击事件");
    _itemImage1.userInteractionEnabled = YES;  //必须为YES才能响应事件
    _itemImage2.userInteractionEnabled = YES;  //必须为YES才能响应事件
    _itemImage3.userInteractionEnabled = YES;  //必须为YES才能响应事件
    
    [self setShadowAndCorlor:_itemImage1];
    [self setShadowAndCorlor:_itemImage2];
    [self setShadowAndCorlor:_itemImage3];
    
    
    UITapGestureRecognizer* singleTouch=[[UITapGestureRecognizer alloc] initWithTarget:self
                                                                                action:@selector(imageOneClicked:)];
    [_itemImage1 addGestureRecognizer:singleTouch];
    
    singleTouch = nil;
    singleTouch=[[UITapGestureRecognizer alloc] initWithTarget:self
                                                        action:@selector(imageTwoClicked:)];
    [_itemImage2 addGestureRecognizer:singleTouch];
    
    singleTouch = nil;
    singleTouch=[[UITapGestureRecognizer alloc] initWithTarget:self
                                                        action:@selector(imageThreeClicked:)];
    [_itemImage3 addGestureRecognizer:singleTouch];
    
    singleTouch = nil;

}

- (void) imageOneClicked:(UITapGestureRecognizer*) sender{
    if(_delegate && [_delegate respondsToSelector:@selector(selectImage:)]){
        [_indexPath setColumn:0];
        //        _indexPath.column = 0;
        objc_msgSend(_delegate,@selector(selectImage:),_indexPath);
    }
}

- (void) imageTwoClicked:(UITapGestureRecognizer*) sender{
    if(_delegate && [_delegate respondsToSelector:@selector(selectImage:)]){
        _indexPath.column = 1;
        objc_msgSend(_delegate,@selector(selectImage:),_indexPath);
    }
}

- (void) imageThreeClicked:(UITapGestureRecognizer*) sender{
    if(_delegate && [_delegate respondsToSelector:@selector(selectImage:)]){
        _indexPath.column = 2;
        objc_msgSend(_delegate,@selector(selectImage:),_indexPath);
    }
}

- (void)setShadowAndCorlor:(UIView*)view{
    //设置圆角
//    view.layer.masksToBounds = YES;
//    view.layer.cornerRadius = 6.0f;
//    //设置阴影，无效
//    view.layer.shadowColor = [UIColor blackColor].CGColor;
//    view.layer.shadowOffset = CGSizeMake(2, -3);
//    view.layer.shadowOpacity = 1;
//    view.layer.shadowRadius = 5.0;
    
    //    view.layer.borderColor = [UIColor blackColor].CGColor;
    //    view.layer.borderWidth = 0.5;
    
}


@end
