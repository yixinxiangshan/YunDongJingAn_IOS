//
//  ECGroupCell.m
//  JingAnWeekly
//
//  Created by EC on 3/21/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECGroupCell.h"
#import <QuartzCore/QuartzCore.h>

@implementation ECGroupCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
    [self setShadowAndCorlor:_bgView];
}

- (void)setShadowAndCorlor:(UIView*)view{
    //设置圆角
    view.layer.masksToBounds = YES;
    view.layer.cornerRadius = 6.0f;
    
    //设置阴影，无效
    view.layer.shadowColor = [UIColor blackColor].CGColor;
    view.layer.shadowOffset = CGSizeMake(2, -3);
    view.layer.shadowOpacity = 1;
    view.layer.shadowRadius = 5.0;
    
    //设置 边框
    view.layer.borderColor = [UIColor blackColor].CGColor;
    view.layer.borderWidth = 0.5;
    
}



@end
