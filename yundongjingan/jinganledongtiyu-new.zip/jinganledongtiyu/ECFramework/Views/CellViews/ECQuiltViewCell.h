//
//  ECQuiltViewCell.h
//  JingAnWeekly
//
//  Created by Angel on 13-5-22.
//  Copyright (c) 2013年 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TMQuiltView.h"
#import "ECImageContainer.h"

@interface ECQuiltViewCell : TMQuiltViewCell

@property (nonatomic, retain) ECImageContainer *imageContainer;
@property (nonatomic, retain) UILabel *titleLabel;
@property (nonatomic, retain) UILabel *contentLabel;
@property CGFloat QuiltCellViewMargin ;
@end
