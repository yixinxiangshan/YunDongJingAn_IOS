//
//  ECListViewCell.h
//  jinganledongtiyu
//
//  Created by cheng on 13-12-18.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utils.h"

@interface ECListViewCell : UITableViewCell

@property (strong, nonatomic) NSDictionary* config;
@property (strong, nonatomic) NSDictionary* dataSource;

- (id) initWithConfig:(NSDictionary *)config dataSource:(NSDictionary *)dataSource;
- (void) setConfig:(NSDictionary *)config dataSource:(NSDictionary *)dataSource;

- (void) initContent;

-(id)getValue:(NSDictionary *)data forKey:(NSString *)key;

+ (CGFloat) cellHeight;
@end
