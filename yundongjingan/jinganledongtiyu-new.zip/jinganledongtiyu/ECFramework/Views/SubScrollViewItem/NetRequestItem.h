//
//  NetRequestItem.h
//  jinganledongtiyu
//
//  Created by cww on 13-7-22.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NetRequestItem : NSObject
+ (NetRequestItem*)shareInstance;
@property BOOL isBusy;
@property (strong, nonatomic) NSDictionary* currentConfig;
@property (strong, nonatomic) NSMutableArray* requestList;

@property (strong, nonatomic) NSMutableDictionary* dataList;

-(NSDictionary *)getData:(NSDictionary *)config;
@end
