//
//  noTitleLabel.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-22.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "noTitleLabel.h"

@implementation noTitleLabel

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
-(void) initView:(NSDictionary *)content withConfig:(NSDictionary *)config
{
    [super initView:content withConfig:config];
    
    self.label.text = [self getContent:@"text"];
    
    [self.label sizeToFit];
    [self setFrame:CGRectMake(0, 0, 320, self.label.frame.size.height+10)];
}

@end
