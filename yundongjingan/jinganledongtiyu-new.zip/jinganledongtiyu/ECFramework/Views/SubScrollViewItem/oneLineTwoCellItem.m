//
//  oneLineTwoCellItem.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-19.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "oneLineTwoCellItem.h"

@implementation oneLineTwoCellItem

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
-(void) initView:(NSDictionary *)content withConfig:(NSDictionary *)config
{
    
    [super initView:content withConfig:config];
    
    self.leftLabel.text = [self getContent:@"leftLabel"];
    self.rightLabel.text = [self getContent:@"rightLabel"];

}
-(void)setStyle
{
    if (self.style == nil) {
        return;
    }

}
@end
