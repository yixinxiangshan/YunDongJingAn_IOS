//
//  imageCover.h
//  jinganledongtiyu
//
//  Created by cww on 13-7-25.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "SubScrollViewItem.h"
#import "ECImageContainer.h"

@interface imageCover : SubScrollViewItem
@property (strong, nonatomic)  ECImageContainer *imageContainer;

@end
