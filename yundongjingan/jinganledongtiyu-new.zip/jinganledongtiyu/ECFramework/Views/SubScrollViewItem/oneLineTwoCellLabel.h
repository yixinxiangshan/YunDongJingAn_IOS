//
//  oneLineTwoCellLabel.h
//  jinganledongtiyu
//
//  Created by cww on 13-7-25.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "SubScrollViewItem.h"

@interface oneLineTwoCellLabel : SubScrollViewItem

@property (weak, nonatomic) IBOutlet UILabel *leftLabel;
@property (weak, nonatomic) IBOutlet UILabel *rightLabel;

@end
