//
//  buttonItem.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-22.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "buttonItem.h"
#import "ECEventRouter.h"

@implementation buttonItem
//@synthesize button;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void) initView:(NSDictionary *)content withConfig:(NSDictionary *)config
{
    [super initView:content withConfig:config];
    
    [self.button  setTitle: [self getContent:@"title"] forState:UIControlStateNormal];
    [self.button addTarget:self action:@selector(doAction:) forControlEvents:UIControlEventTouchUpInside];
    
    //针对项目的特殊处理
    if ([[self getContent:@"isNormalCourseDetailApplyButton"] boolValue]) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateButtonTitle:) name:@"applyCoupon.success" object:nil];
    }
    //针对项目的特殊处理
//    NSDictionary* data = [self.config objectForKey:@"data"];
//    NSString* couponOrderNum = [self getValue:content forKey:[data valueForKey:@"titleKey"]];
//    
//    if (couponOrderNum && [couponOrderNum integerValue] == 1) {
////        [button setTitle:sButtonTitle forState:UIControlStateNormal];
////        [button addTarget:self action:@selector(actionGetECode:) forControlEvents:UIControlEventTouchUpInside];
//        
//        
//        
//    } else if(couponOrderNum && ([couponOrderNum length] >2)) {
//        [self.button setTitle:[NSString stringWithFormat:@"验证码:%@", couponOrderNum] forState:UIControlStateNormal];
//        [self.button setUserInteractionEnabled:YES];
//        [self.button removeTarget:self action:@selector(doAction:) forControlEvents:UIControlEventTouchUpInside];
//    } else if(couponOrderNum){
//        if([self isStart]){
//            [self.button setTitle:@"活动尚未开始" forState:UIControlStateNormal];
//        }else{
//            [self.button setTitle:@"该活动已结束" forState:UIControlStateNormal];
//        }
//    }
}

-(void)updateButtonTitle:(NSNotification *)noti
{
    NSLog(@"%@ : %@",self.class,noti.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"applyCoupon.success" object:nil];
    [self.button setTitle:[NSString stringWithFormat:@"验证码:%@",[[noti.userInfo valueForKey:@"Success"] objectForKey:@"code"]] forState:UIControlStateNormal];
    [self.button removeTarget:self action:@selector(doAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.button setUserInteractionEnabled:YES];
    
    [[ECEventRouter shareInstance] doAction:[NSString stringWithFormat:@"ecct://subscrollview?configName=ECMyCourseDetailConfig&requestId=%@",self.requestId]];
}
- (BOOL)isStart {
    NSDate *startDate = [self dateFromString:[self.content valueForKey:@"apply_start_time"]];
    if ([[startDate earlierDate:[NSDate date]] isEqualToDate:startDate])
        return false ;
    else
        return true ;
}
- (NSDate *)dateFromString:(NSString *)dateString{
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat: @"yyyy-MM-dd HH:mm:ss"];
    
    NSDate *destDate= [dateFormatter dateFromString:dateString];
    
    return destDate;
    
}
@end
