//
//  imageCover.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-25.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "imageCover.h"
#import "ECUriUtil.h"

@implementation imageCover

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void) initView:(NSDictionary *)content withConfig:(NSDictionary *)config
{
    
    [super initView:content withConfig:config];
    
    
    NSString* imageURL = [self getContent:@"image"];
    imageURL = [ECUriUtil getWholeImageUrl:imageURL];
    
    self.imageContainer = [[ECImageContainer alloc] initWithFrame:self.frame];
    [self addSubview:self.imageContainer];
    
    [self.imageContainer updateWithNormalImageURI:imageURL];
}

@end
