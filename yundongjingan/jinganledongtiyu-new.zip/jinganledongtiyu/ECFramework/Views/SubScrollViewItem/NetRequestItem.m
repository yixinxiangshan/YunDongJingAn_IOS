//
//  NetRequestItem.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-22.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "NetRequestItem.h"
#import "NSStringExtends.h"
#import "ECNetRequest.h"
#import "ECKeyChain.h"
#import "NSObjectExtends.h"
#import "Extends.h"
#import "ECPopViewUtil.h"
#import "ECClearApp.h"
#import "Utils.h"
#import "Extends.h"
#import "ECViews.h"

@implementation NetRequestItem


+ (NetRequestItem*)shareInstance{
    static NetRequestItem* netRequestItem = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        netRequestItem = [[NetRequestItem alloc] init];
        netRequestItem.isBusy = NO;
        netRequestItem.requestList = [NSMutableArray new];
        netRequestItem.dataList = [NSMutableDictionary new];
        netRequestItem.currentConfig = [NSDictionary new];
    });
    return netRequestItem;
}

-(NSDictionary *)getData:(NSDictionary *)config
{
    NSString* flag = [NSString stringWithFormat:@"%@",[self md5Hash:config]];
    
    if ([self.dataList objectForKey:flag] != nil) {
        return [self.dataList objectForKey:flag];
    }
    
    [self requestData:config];
    return nil;
}

-(void)requestData:(NSDictionary *)config
{
    NSLog(@"%@ : requestData flag = %@\nconfig = \n%@",self.class,[self md5Hash:config],config);
    
    if (self.isBusy) {
        [self.requestList setValue:config forKey:[self md5Hash:config]];
        return;
    }
    self.isBusy = YES;
    self.currentConfig = config;
    NSMutableDictionary* params = [NSMutableDictionary new];
    [params setObject:[config valueForKey:@"requestId"] forKey:[config valueForKey:@"requestIdKey"]];
    [params setObject:[config valueForKey:@"method"] forKey:@"method"];
    
    FormDataRequest* request = [FormDataRequest requestNetURI:API_URL
                                                       params:params delegate:self
                                             finishedSelector:@selector(requestFinished:)
                                                 failSelector:@selector(webRequestFailed:)];
    
    
    [[NetRequestManager sharedInstances] addOperation:request];

}

-(void)requestFinished:(FormDataRequest *)request{
    NSString* reponseString = [request responseString];
    
    NSLog(@"%@ : reponseString \n%@", self.class,reponseString);
    if ([reponseString rangeOfString:@"\"error\""].location != NSNotFound || [reponseString rangeOfString:@"\"Error\""].location != NSNotFound) {
        [[ECSpecRequest shareInstance] showError:reponseString];
        return;
        //        NSLog(@"response error:%@",reponseString);
    }
    else{
         [self handleRequestData:request.responseData];
    }
}

- (void)handleRequestData:(NSData*)data{

    id tempData = nil;
    //处理数据
    id obj = [ECJsonParser objectWithJsonData:data];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        tempData = [obj valueForKey:@"data"];
    }
    if (tempData && [tempData isNSxxxClass:[NSDictionary class]]) {
        
        [self.dataList setObject:tempData forKey:[self md5Hash:self.currentConfig]];
        [self.requestList removeObject:self.currentConfig];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"freshScrollView" object:nil userInfo:nil];
        [self nextRequest];
        
    }else{
        NSLog(@"%@ : Data format is error .",self.class);
    }
    
}
-(void) nextRequest
{
    
   
    if (nil != self.requestList && ![self.requestList isEmpty]) {
        self.currentConfig = [self.requestList objectAtIndex:0];
        [self requestData:self.currentConfig]; 
    }
    self.isBusy = NO;
    
}
-(NSString *)md5Hash:(NSDictionary *)config
{
    return [[NSString stringWithFormat:@"%@",config] md5Hash];
}
@end
