//
//  SubScrollViewItem.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-19.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "SubScrollViewItem.h"

#import "ECEventRouter.h"

@interface SubScrollViewItem ()



@end
@implementation SubScrollViewItem
@synthesize itemContainer;

@synthesize requestId;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    //设置圆角边框
    itemContainer.layer.cornerRadius = 3;
    itemContainer.layer.masksToBounds = YES;
    //设置边框及边框颜色
    itemContainer.layer.borderWidth = 1;
    itemContainer.layer.borderColor =[ [UIColor grayColor] CGColor];
}

-(void)initView:(NSDictionary *)content withConfig:(NSDictionary *)config
{
    self.content = content;
    self.config = config;
    self.style = [config objectForKey:@"style"];
    
    //add GestureRecognizer
    UITapGestureRecognizer* singleGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doAction:)];
    [self.itemContainer addGestureRecognizer:singleGestureRecognizer];
    
    
}

- (void)doAction:(id)sender {
    NSString* action = [self.config valueForKey:@"action"];
    
    NSMutableDictionary* params = [NSMutableDictionary new];
    [params setValue:self.requestId forKey:@"requestId"];
    [params setValue:self.title forKey:@"navTitle"];
    
    
        [params setValue:self.title forKey:@"title"];

    
    
    NSLog(@"%@ doAction : %@  userInfo :%@",self.class,action,params);
    
    [[ECEventRouter shareInstance] doAction:action userInfo:params];
    
}

-(NSString *) getContent:(NSString *)name
{
    
    NSDictionary* data = [self.config objectForKey:@"data"];
    if (![[data valueForKey:name] isEqual:@""]) {
        return [self getValue:data forKey:name];
    }
    
    return [self getValue:self.content forKey:[data valueForKey:[NSString stringWithFormat:@"%@Key",name]]];
}

-(id)getValue:(NSDictionary *)data forKey:(NSString *)key
{
    if (key == nil || key == NULL || data == nil || data == NULL) {
        NSLog(@"getValue : key or data is error .\n key = %@ \n data = %@",key,data);
        return nil;
    }
    int location = [key rangeOfString:@"."].location;
    
    if (location == NSNotFound) {
//        NSLog(@"value %@ fromkey : %@",[data valueForKey:key],key);
        return [data valueForKey:key];
    }else{
        NSString* forwardKey = [key substringToIndex:location];
        NSString* behandkey = [key substringFromIndex:location+1];
        //递归
        NSDictionary* subData = [data valueForKey:forwardKey];
        return [self getValue:subData forKey:behandkey];
    }
    return nil;
}


@end
