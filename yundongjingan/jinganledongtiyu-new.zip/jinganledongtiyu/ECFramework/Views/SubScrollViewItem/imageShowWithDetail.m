//
//  imageShowWithDetail.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-23.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "imageShowWithDetail.h"
#import "ECImageContainer.h"
#import "ECUriUtil.h"

@interface imageShowWithDetail ()

@property (strong, nonatomic) NSArray* dataList;

@end

@implementation imageShowWithDetail
@synthesize dataList;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
-(void) initView:(NSDictionary *)content withConfig:(NSDictionary *)config
{
    
    [super initView:content withConfig:config];
    
    self.titleLabel.text = [self getContent:@"title"];
    [self showDetail];
}

-(void)showDetail
{
    if (self.content == nil) {
        return;
    }
    NSMutableString* str = [NSMutableString new];
    
    dataList = [self.content objectForKey:[self.config valueForKey:@"dataKey"]];
    CGFloat imageViewWidth = 0 ;
    
    for (NSDictionary* item in dataList) {
        self.content = item;
        
        NSString* buffer = [self getContent:@"content"];
        if (buffer != nil) {
            [str appendString:[self getContent:@"content"]];
            [str appendString:@" "];
        }

        
        ECImageContainer* image = [[ECImageContainer alloc] initWithFrame:CGRectMake(imageViewWidth, 0, 72, 72)];
        [image updateWithNormalImageURI:[ECUriUtil getSmallImageUrl:[self getContent:@"image"]]];
        [image setClipsToBounds:YES];
        [self.imageContainer addSubview:image];
        
        imageViewWidth += 72;
    }
    
    self.detailLabel.text = str;
    
    UITapGestureRecognizer* singleGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doAction:)];
    [self addGestureRecognizer:singleGestureRecognizer];
}
@end
