//
//  messageBoard.h
//  jinganledongtiyu
//
//  Created by cww on 13-7-23.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "SubScrollViewItem.h"

@interface messageBoard : SubScrollViewItem
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (weak, nonatomic) IBOutlet UILabel *messageLabel;
@end
