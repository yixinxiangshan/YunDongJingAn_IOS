//
//  oneLineTwoCellItem.h
//  jinganledongtiyu
//
//  Created by cww on 13-7-19.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "SubScrollViewItem.h"

@interface oneLineTwoCellItem : SubScrollViewItem

@property (weak, nonatomic) IBOutlet UIControl *itemContainer;
@property (weak, nonatomic) IBOutlet UILabel *leftLabel;
@property (weak, nonatomic) IBOutlet UILabel *rightLabel;
@property (weak, nonatomic) IBOutlet UIImageView *actionFlag;
@end
