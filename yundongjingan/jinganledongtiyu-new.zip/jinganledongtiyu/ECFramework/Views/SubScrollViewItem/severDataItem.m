//
//  severDataItem.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-22.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "severDataItem.h"
#import "SubScrollViewHeader.h"

@interface severDataItem ()

@property CGFloat viewHeight;

@end

@implementation severDataItem
@synthesize viewHeight;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void) initView:(NSDictionary *)content withConfig:(NSDictionary *)config withId:(NSString *)requestId
{
    [super initView:content withConfig:config];
    if (requestId == nil || requestId == NULL) {
        NSLog(@"%@ : requestId is null .",self.class);
        return;
    }
    self.requestId = requestId;

    NSLog(@"%@ : %@",self.class,self.config);
    NSMutableDictionary* netRequestConfigs = [NSMutableDictionary new];
    [netRequestConfigs addEntriesFromDictionary:[config objectForKey:@"netDataRelevant"]];
    [netRequestConfigs setValue:self.requestId forKey:@"requestId"];
    
    self.content = [[NetRequestItem shareInstance] getData:netRequestConfigs];
                    
    if (self.content == nil) {
        NSLog(@"Loading ......");
        return;
    }
    
//    NSLog(@"%@ : %@",self.class,self.content);
    
    [self showContentView];
}
-(void) showContentView
{
    NSArray* contents = [self.content objectForKey:[self getValue:self.config forKey:@"dataListKey"]];
    NSDictionary* itemConfig = [self.config valueForKey:@"adapter"];
//    NSDictionary* itemContent = [NSDictionary new];
    
    self.viewHeight = 0;
    
    for (int i = 0 ; i < contents.count ; i ++ ) {
       NSDictionary*  itemContent = [contents objectAtIndex:i];
        
        
        UIView* cell =nil;
        NSString* CellIdentifier = [itemConfig valueForKey:@"itemtype"];
        
        if ([CellIdentifier isEqualToString:@"oneLineTwoCellItem"])
        {
            cell = (oneLineTwoCellItem*)[[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
            [(oneLineTwoCellItem*)cell initView:itemContent withConfig:itemConfig];
            NSLog(@"%@ : itemContent %@",itemContent.class,itemContent);
        }
        
        
        
        [cell setFrame:CGRectMake(0, viewHeight, 320, cell.frame.size.height)];
        viewHeight += cell.frame.size.height;
        [self addSubview:cell];
    }
    [self setFrame:CGRectMake(0, 0, 320, viewHeight)];
    
}
@end
