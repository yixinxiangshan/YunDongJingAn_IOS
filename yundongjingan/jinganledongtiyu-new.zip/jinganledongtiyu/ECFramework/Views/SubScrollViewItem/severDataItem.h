//
//  severDataItem.h
//  jinganledongtiyu
//
//  Created by cww on 13-7-22.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "SubScrollViewItem.h"

@interface severDataItem : SubScrollViewItem

-(void) initView:(NSDictionary *)content withConfig:(NSDictionary *)config withId:(NSString *)requestId;

@end
