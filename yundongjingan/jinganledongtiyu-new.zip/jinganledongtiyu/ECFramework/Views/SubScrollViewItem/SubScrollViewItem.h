//
//  SubScrollViewItem.h
//  jinganledongtiyu
//
//  Created by cww on 13-7-19.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NetRequestItem.h"
#import <QuartzCore/QuartzCore.h>

@interface SubScrollViewItem : UITableViewCell

@property (weak, nonatomic) IBOutlet UIControl *itemContainer;
@property (strong, nonatomic) NSDictionary* config;
@property (strong, nonatomic) NSDictionary* content;
@property (strong, nonatomic) NSDictionary* style;

@property (strong, nonatomic) NSString* requestId;
@property (strong, nonatomic) NSString* title;

-(void)initView:(NSDictionary *)content withConfig:(NSDictionary *)config;

-(NSString *)getContent:(NSString *)name;
-(id)getValue:(NSDictionary *)data forKey:(NSString *)key;
@end
