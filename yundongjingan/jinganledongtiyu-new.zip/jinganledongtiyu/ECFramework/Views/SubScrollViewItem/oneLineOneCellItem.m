//
//  oneLineOneCellItem.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-23.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "oneLineOneCellItem.h"

@implementation oneLineOneCellItem

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
-(void) initView:(NSDictionary *)content withConfig:(NSDictionary *)config
{
    
    [super initView:content withConfig:config];
    
    self.label.text = [self getContent:@"label"];
    
    UITapGestureRecognizer* singleGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doAction:)];
    [self addGestureRecognizer:singleGestureRecognizer];

}
@end
