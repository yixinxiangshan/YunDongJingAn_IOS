//
//  buttonItem.h
//  jinganledongtiyu
//
//  Created by cww on 13-7-22.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "SubScrollViewItem.h"

@interface buttonItem : SubScrollViewItem
@property (weak, nonatomic) IBOutlet UIControl *itemContainer;

@property (weak, nonatomic) IBOutlet UIButton *button;
@end
