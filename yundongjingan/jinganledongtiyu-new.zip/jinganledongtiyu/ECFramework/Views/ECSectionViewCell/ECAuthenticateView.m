//
//  ECAuthenticateView.m
//  jinganledongtiyu
//
//  Created by cheng on 13-11-14.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECAuthenticateView.h"
#import "ECPopViewUtil.h"
#import "DisplayUtil.h"
#import "NSStringExtends.h"
#import "ECCMController.h"
#import "UIImage+Resize.h"
#include "sys/stat.h"

#import "ASIHTTPRequest.h"

@interface ECAuthenticateView ()

@property (strong, nonatomic) NSMutableArray* subCells;

@property (strong, nonatomic) ASINetworkQueue* operationQueue;

@end

@implementation ECAuthenticateView

- (id) initWithFrame:(CGRect) frame
{
    static ECAuthenticateView *authenticateView = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        authenticateView = [super initWithFrame:frame];
    });
    return authenticateView;
}

- (void) initContent
{
    self.inputForm = [self.config objectForKey:@"inputForm"];
    self.subCells = [NSMutableArray new];
}

- (void) initView
{
    for (NSDictionary* cellConfig in self.inputForm) {
        Class class = NSClassFromString([cellConfig objectForKey:@"type"]);
        ECAuthenticateViewCell* cell = [[class alloc] initWithConfig:cellConfig];
        
        [self.subCells addObject:cell];
        [self addSubview:cell];
    }
    [self layoutCells];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(layoutCells) name:@"ECAuthenticateView.layoutSubViews" object:nil];
}

#pragma mark- layout subCells

- (void) layoutCells
{
    CGRect frame = CGRectMake(0, 0, 320, 0);
    
    for (UIView* view in self.subCells) {
        
        frame.size.height = view.frame.size.height;
        [view setFrame:frame];
        
        frame.origin.y += frame.size.height;
    }
    [self setFrame:CGRectMake(0, 0,self.frame.size.width, frame.origin.y)];
    
    UITableView* superView = [self getTableViewFor:self];
    if (superView) {
        [superView reloadData];
    }
}

#pragma mark- override
- (void) doAction:(NSDictionary *)params
{
    
}

#pragma mark- submit 
- (void) submit
{
    
    NSLog(@"submit ...");
    NSString* urlString = [NSString stringWithFormat:@"%@/%@/%@",API_URL,[[self.config objectForKey:@"netDataRelevant"] objectForKey:@"apiversion"],[[self.config objectForKey:@"netDataRelevant"] objectForKey:@"method"]];
    
    NSURL* url = [NSURL URLWithString:urlString];
    NSLog(@"url : %@",url);
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    
    NSMutableDictionary* params = [NSMutableDictionary new];
    
    [params setObject:[[self.config objectForKey:@"netDataRelevant"] objectForKey:@"method"] forKey:@"method"];
    [params setObject:[[self.config objectForKey:@"netDataRelevant"] objectForKey:@"apiversion"] forKey:@"apiversion"];
    
    
    
    NSString* idKey;
    for (ECAuthenticateViewCell* cell in self.subCells) {
        
        idKey = [cell.config objectForKey:@"idKey"];
        if (idKey && idKey.length) {
            if (!cell.content || !cell.content.value) {
                [ECPopViewUtil toast:[NSString stringWithFormat:@"%@，不能为空",[cell.config objectForKey:@"title"]] position:@"center"];
                return;
            }
            //根据配制文件，把需要提交的信息格式化
            
            switch (cell.content.type) {
                case AuthenticateDataString:
                    [params setObject:cell.content.value forKey:[cell.config objectForKey:@"idKey"]];
                    //                [request addPostValue:cell.content forKey:[cell.config objectForKey:@"idKey"]];
                    break;
                case AuthenticateDataImage:
                    break;
                case AuthenticateDataImagePath:
                    [request setFile:cell.content.value forKey:[cell.config objectForKey:@"idKey"]];
                    NSLog(@"iamgepath : %@",cell.content.value);
                    break;
                default:
                    break;
            }

        }
    }
    NSLog(@"%@",[params newParams]);
    
    NSDictionary* newParams = [params newParams];
    NSEnumerator* enumerator = [newParams keyEnumerator];
    id key;
    
    while (key = [enumerator nextObject]) {
        [request addPostValue:[newParams objectForKey:key] forKey:key];
    }
    
    [request setDefaultResponseEncoding:NSUTF8StringEncoding];
	[request setTimeOutSeconds:120];
    [request setRequestMethod:@"POST"];
	[request addRequestHeader:@"Content-Type" value:@"application/x-www-form-urlencoded; charset=UTF-8;"];
    
    //设置成功后的回调
    request.delegate = self;
    [request setDidFinishSelector:@selector(submitFinished:)];
    [request setDidFailSelector:@selector(submitFailed:)];
    
    
    if (request) {
        NSLog(@"start request ...");
        [self showLoading:nil];
        if (!_operationQueue) {
            _operationQueue = [ASINetworkQueue new];
        }
        [_operationQueue cancelAllOperations];
        _operationQueue.maxConcurrentOperationCount = 1;
        [_operationQueue go];
        
        [_operationQueue addOperation:request];
    }
}

- (void) submitFinished:(ASIHTTPRequest *)request
{
    NSString* requestSuccessString = nil;
    requestSuccessString = request.responseString;
    // responseString
    NSLog(@"Authentication request response : %@",requestSuccessString);
    if ([requestSuccessString rangeOfString:@"\"error\""].location == NSNotFound
        && [requestSuccessString rangeOfString:@"\"Error\""].location == NSNotFound && [requestSuccessString rangeOfString:@"\"error_num\""].location == NSNotFound) {
        NSLog(@"authenticate submit successed : %@",requestSuccessString);
        [self removeLoading];
        
        [[[ECPopViewUtil currentViewController] navigationController] popViewControllerAnimated:YES];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ECAuthenticateView.submitSuccess" object:nil];
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:nil message:@"提交成功！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alert show];
    }else{
        [self submitFailed:request];
    }
    
}
- (void) submitFailed:(ASIHTTPRequest *)request
{
    // responseString
    NSLog(@"Authentication request response : %@",request.responseString);
    [self removeLoading];
    UIAlertView* alert = [[UIAlertView alloc] initWithTitle:nil message:@"提交失败，请稍后重新操作！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alert show];
}
#pragma mark - 显示弹出框
- (void)showLoading:(NSString*)message{
    if ([NetRequestManager networdEnabled]) {
        [ECPopViewUtil showLoading:message view:[ECPopViewUtil currentViewController].view];
    }
}
- (void)removeLoading{
    [ECLoadingBezelActivityView removeViewAnimated:YES];
}
@end



@implementation ECAuthenticateViewCell

- (id) initWithConfig:(NSDictionary *)config
{
    self = [super init];
    self.config = config;
    [self initView];
    
    return self;
}
- (void) initView
{
    
}

- (ECAuthenticateView *) getSuperViewFor:(UIView *)view
{
    UIView* superView = [view superview];
    if (!superView) {
        return nil;
    }
    if ([superView isKindOfClass:[ECAuthenticateView class]]) {
        return (ECAuthenticateView *)superView;
    }
    return [self getSuperViewFor:superView];
}
@end


// submit button
@implementation SubmitButton

- (void) initView
{
    [self setFrame:CGRectMake(0, 0, 320, 66)];
    
    UIButton* submitButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [submitButton setFrame:CGRectMake(10, 11, 300, 44)];
    [submitButton setTitle:@"提    交" forState:UIControlStateNormal];
    if (!IOS7_OR_LATER) {
        [submitButton setBackgroundImage:[UIImage imageNamed:@"jingan-35.png"] forState:UIControlStateNormal];
        [submitButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
    
    [self addSubview:submitButton];
    
    [submitButton addTarget:self action:@selector(submit) forControlEvents:UIControlEventTouchUpInside];
}

- (void) submit
{
    ECAuthenticateView* superView = [self getSuperViewFor:self];
    if (superView) {
        [superView submit];
    }
}
@end


@implementation TextInputView

- (void) initView
{
    self.backgroundColor = [UIColor whiteColor];
    [self setFrame:CGRectMake(0, 0, 320, 44)];
    UILabel* titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 90, 44)];
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.text = [self.config objectForKey:@"title"];
    
    [self addSubview:titleLabel];
    
    //inputField
    self.inputField = [[UITextField alloc] initWithFrame:CGRectMake(110, 0, 200, 44)];
    self.inputField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.inputField.delegate = self;
    self.inputField.placeholder = [NSString stringWithFormat:@"请输入%@",[self.config objectForKey:@"title"]];
    self.inputField.returnKeyType = UIReturnKeyDone;
    [[NSNotificationCenter defaultCenter] addObserver:self.inputField selector:@selector(resignFirstResponder) name:@"resignFirstResponder" object:nil];
    
    [self addSubview:self.inputField];
    
    UIView* dividerLine = [[UIView alloc] initWithFrame:CGRectMake(0, 43, 320, 1)];
    [dividerLine setBackgroundColor:[UIColor lightGrayColor]];
    [self addSubview:dividerLine];
    
}

#pragma mark- UITextFieldDelegate
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    self.content = [AuthenticateData initWithType:AuthenticateDataString value:textField.text];
}
- (BOOL) textFieldShouldReturn:(UITextField *)textField
{
    [self.inputField resignFirstResponder];
    return YES;
}
@end

@implementation ECAuthenticateViewCellTextLabel

- (void) initView
{
    self.backgroundColor = [UIColor clearColor];

    UILabel *label = [[UILabel alloc] init];
    label.backgroundColor = self.backgroundColor;
    label.lineBreakMode = NSLineBreakByCharWrapping;
    [label setNumberOfLines:0];
    
    label.text = [self.config objectForKey:@"text"];
    
    CGSize sizeMax = CGSizeMake(300, 2000);
    CGSize size = [label.text sizeWithFont:label.font constrainedToSize:sizeMax lineBreakMode:label.lineBreakMode];
    
    [label setFrame:CGRectMake(0, 0, 300, size.height)];
    [self setFrame:CGRectMake(0, 0, 320, label.frame.size.height + 20)];
    [label setCenter:CGPointMake(160, self.frame.size.height/2)];
    [self addSubview:label];
    
    
    UIView* dividerLine = [[UIView alloc] initWithFrame:CGRectMake(0, self.frame.size.height - 1, 320, 1)];
    [dividerLine setBackgroundColor:[UIColor lightGrayColor]];
    [self addSubview:dividerLine];
}

@end

@interface ImageSeletView () <ImageSelectorDelegate>
@property (strong, nonatomic) UILabel* titleLabel;
@property (strong, nonatomic) UIView* dividerLine;
@end
@implementation ImageSeletView

- (void) initView
{
    self.backgroundColor = [UIColor whiteColor];
    
    CGFloat height = 0;
    
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 310, 33)];
    _titleLabel.text = [self.config objectForKey:@"title"];
    [self addSubview:_titleLabel];
    height += _titleLabel.frame.size.height;
    
    //已选择图片
    UIImage* image = [UIImage imageNamed:@"defaultImage.jpg"];
    self.selectedImage = [[UIButton alloc] initWithFrame:CGRectMake((320 - image.size.width)/2, 33, image.size.width, image.size.height)];
    [self.selectedImage setBackgroundImage:image forState:UIControlStateNormal];
    [self addSubview:self.selectedImage];
    height += self.selectedImage.frame.size.height;
    
    //选择按钮
    self.selectButton = [[UILabel alloc] initWithFrame:CGRectMake(0, height, 320, 44)];
    [self.selectButton setFont:[UIFont systemFontOfSize:13]];
    self.selectButton.textColor = [UIColor darkGrayColor];
    self.selectButton.text = @"请选择照片";
    [self.selectButton sizeToFit];
    [self.selectButton setFrame:CGRectMake((320 - self.selectButton.frame.size.width)/2, height, self.selectButton.frame.size.width, 33)];
    
    [self addSubview:self.selectButton];
    height += self.selectButton.frame.size.height;
    
    //分割线
    self.dividerLine = [[UIView alloc] initWithFrame:CGRectMake(0, height, 320, 1)];
    [self.dividerLine setBackgroundColor:[UIColor lightGrayColor]];
    [self addSubview:self.dividerLine];
    height += 1;
    
    [self setFrame:CGRectMake(0, 0, 320, height)];
    
    
    //设置点击事件
    
    [self.selectedImage addTarget:self action:@selector(selectImage:) forControlEvents:UIControlEventTouchUpInside];
}

#pragma mark- 图片选择
- (void) selectImage:(id)sender
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"resignFirstResponder" object:nil];
    [ImageSelector popWithDelegate:self];
}
#pragma mark- ImageSelectorDelegate
- (void) imageSelector:(ImageSelector *)selector didSelectImage:(UIImage *)image
{
    NSLog(@"image picked : %@   width : %f  height :%f",image,image.size.width,image.size.height);
    
    //调整图片大小
    image = [image fitToWidth:640.0];
    
    NSLog(@"image resized : %@   width : %f  height :%f",image,image.size.width,image.size.height);
    
    //缓存图片，并获得file
    NSString  *jpgPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/ECAuthenticationImage.jpg"];
    [UIImageJPEGRepresentation(image, 0.8) writeToFile:jpgPath atomically:YES];
    
    //输出图片文件大小
    struct stat st;
    if(lstat([jpgPath cStringUsingEncoding:NSUTF8StringEncoding], &st) == 0){
        NSLog(@"jpg image length : %lld",st.st_size);
    }
    
    self.content = [AuthenticateData initWithType:AuthenticateDataImagePath value:jpgPath];
    // continue
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.selectedImage setBackgroundImage:image forState:UIControlStateNormal];
        
        CGFloat imageWidth = image.size.width <= 300 ? image.size.width : 300;
        CGFloat imageHeight = 300 * image.size.height / image.size.width;
        
        [self.selectedImage setFrame:CGRectMake((320 - imageWidth)/2, 33, imageWidth, imageHeight)];
        
        [self.selectButton setFrame:CGRectMake((320 - self.selectButton.frame.size.width)/2, 33 + imageHeight, self.selectButton.frame.size.width, 33)];
        
        [self.dividerLine setFrame:CGRectMake(0, 33 + self.selectedImage.frame.size.height + 33, 320, 1)];
        
        [self setFrame:CGRectMake(0, 0, 320, 33 + self.selectedImage.frame.size.height + 34)];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ECAuthenticateView.layoutSubViews" object:nil];
    });
}
@end


@implementation ImageSelector

+ (id) shareInstance
{
    static ImageSelector* selector = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        selector = [[ImageSelector alloc] init];
        [[NSNotificationCenter defaultCenter] addObserver:selector selector:@selector(dismiss) name:UIKeyboardWillShowNotification object:nil];
    });
    return selector;
}

- (id) init
{
    self = [super init];
    if (self) {
        [self setFrame:CGRectMake(0, 0, 320, 172)];
        [self setBackgroundColor:[[UIColor clearColor] colorWithAlphaComponent:0.7]];
        
        UIButton* imageFromCamera = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [imageFromCamera setFrame:CGRectMake(10, 10, 300, 44)];
        [imageFromCamera setTitle:@"启动照像机" forState:UIControlStateNormal];
        [self addSubview:imageFromCamera];
        [imageFromCamera addTarget:self action:@selector(startCamera) forControlEvents:UIControlEventTouchUpInside];
        
        UIButton* imageFromGallery = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [imageFromGallery setFrame:CGRectMake(10, 64, 300, 44)];
        [imageFromGallery setTitle:@"打开相册" forState:UIControlStateNormal];
        [self addSubview:imageFromGallery];
        [imageFromGallery addTarget:self action:@selector(openGallery) forControlEvents:UIControlEventTouchUpInside];
        
        UIButton* cancelButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [cancelButton setFrame:CGRectMake(10, 118, 300, 44)];
        [cancelButton setTitle:@"取消" forState:UIControlStateNormal];
        [self addSubview:cancelButton];
        [cancelButton addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return self;
}
+ (void) popWithDelegate:(id)delegate
{
    ImageSelector* selector = [ImageSelector shareInstance];
    selector.delegate = delegate;
    if ([selector superview]) {
        return;
    }
    
    [selector setFrame:CGRectMake(0, [ECPopViewUtil currentViewController].view.frame.size.height, 320, 172)];
    [[ECPopViewUtil currentViewController].view addSubview:selector];
//    [UIView animateKeyframesWithDuration:0.3
//                                   delay:0.0
//                                 options:UIViewKeyframeAnimationOptionBeginFromCurrentState
//                              animations:^{
//                                  [selector setFrame:CGRectMake(0, [ECPopViewUtil currentViewController].view.frame.size.height - 172, 320, 172)];
//                              }completion:^(BOOL finished){
//                                  
//                              }];
    [UIView animateWithDuration:0.3
                     animations:^{
                         [selector setFrame:CGRectMake(0, [ECPopViewUtil currentViewController].view.frame.size.height - 172, 320, 172)];
                     } completion:^(BOOL finished) {
                     }];
}

// 隐藏
- (void) dismiss
{
//    [UIView animateKeyframesWithDuration:0.3
//                                   delay:0.0
//                                 options:UIViewKeyframeAnimationOptionBeginFromCurrentState
//                              animations:^{
//                                  [self setFrame:CGRectMake(0, [ECPopViewUtil currentViewController].view.frame.size.height, 320, 172)];
//                              }completion:^(BOOL finished){
//                                  [self removeFromSuperview];
//                              }];
    
    [UIView animateWithDuration:0.3
                     animations:^{
                         [self setFrame:CGRectMake(0, [ECPopViewUtil currentViewController].view.frame.size.height, 320, 172)];
                     } completion:^(BOOL finished) {
                         [self removeFromSuperview];
                     }];
}
#pragma mark- 启动照像机
- (void) startCamera
{
    [self imagePickerWithOption:UIImagePickerControllerSourceTypeCamera];
}
#pragma mark- 打开相册
- (void) openGallery
{
    [self imagePickerWithOption:UIImagePickerControllerSourceTypePhotoLibrary];
}
#pragma mark- 调用 UIImagePickerController
- (void) imagePickerWithOption:(UIImagePickerControllerSourceType)sourceType
{
    [self dismiss];
    
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.delegate = self;
    imagePickerController.allowsEditing = NO;
    imagePickerController.sourceType = sourceType;
    
    [[ECPopViewUtil currentViewController] presentViewController:imagePickerController animated:YES completion:^{}];
}

#pragma mark - UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{
    [picker dismissViewControllerAnimated:YES completion:^{
        
        if ([self.delegate respondsToSelector:@selector(imageSelector:didSelectImage:)]) {
            [self.delegate imageSelector:self didSelectImage:image];
            self.delegate = nil;
        }
    }];
}
@end

@implementation AuthenticateData
+ (AuthenticateData *) initWithType:(AuthenticateDataType)type value:(id)value
{
    AuthenticateData* authData = [[AuthenticateData alloc] init];
    authData.type = type;
    authData.value = value;
    
    return authData;
}
@end