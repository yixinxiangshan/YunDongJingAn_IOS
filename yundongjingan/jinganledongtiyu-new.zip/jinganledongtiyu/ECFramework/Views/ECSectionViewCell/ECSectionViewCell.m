//
//  ECSectionViewCell.m
//  jinganledongtiyu
//
//  Created by cheng on 13-11-12.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSectionViewCell.h"
#import "ECEventRouter.h"
#import "NSString+SBJSON.h"
#import "NSObjectExtends.h"
#import "ECUriUtil.h"
#import "DisplayUtil.h"
#import "Utils.h"

@implementation ECSectionViewCell

- (id) initWithFrame:(CGRect)frame
{
    self = [self initWithFrame_pravite:frame];
    
    [self initContent];
    [self initView];
    
    return self;
}

- (id) initWithFrame_pravite:(CGRect)frame
{
    self = [super initWithFrame:frame];
    self.backgroundView ? [self.backgroundView removeFromSuperview] : nil;
    self.backgroundView = [[UIView alloc] initWithFrame:CGRectZero];
    [self.backgroundView setBackgroundColor:[UIColor clearColor]];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return self;
}

- (id) initWithFrame:(CGRect)frame config:(NSDictionary *)config dataSource:(NSDictionary *)dataSource
{
    _config = config;
    _dataSource = dataSource;
    return [self initWithFrame:frame];
}
- (void) initAction
{
    self.action = !self.action ? [self.config objectForKey:@"action"] : self.action;
    if (self.ID) {
        self.action = [self.action rangeOfString:@"?"].location == NSNotFound ? [NSString stringWithFormat:@"%@?requestId=%@",self.action,self.ID] : [NSString stringWithFormat:@"%@&requestId=%@",self.action,self.ID];
    }
}
- (void) initView
{
    
}
- (void) initContent
{
    
}
- (void) doAction:(NSDictionary *)params
{
    [[ECEventRouter shareInstance] doAction:self.action userInfo:params];
}
/**
 *  utils method
 */
- (NSString *) getContent:(NSString *)content
{
    NSString* contentString = [_config objectForKey:content] && ![[_config objectForKey:content] isEqualToString:@""] ? [_config objectForKey:content] : nil;
    if (contentString && ![contentString isEqualToString:@""]) {
        return contentString;
    }
    NSString* contentKey = [NSString stringWithFormat:@"%@Key",content];
    contentString = [self getValue:self.dataSource forKey:[_config objectForKey:contentKey]] ? [self getValue:self.dataSource forKey:[_config objectForKey:contentKey]] : nil;
    if (contentString && ![contentString isEqualToString:@""]) {
        return contentString;
    }
    return nil;
}
-(id)getValue:(NSDictionary *)data forKey:(NSString *)key
{
    if (key == nil || key == NULL || data == nil || data == NULL) {
        return nil;
    }
    int location = [key rangeOfString:@"."].location;
    if (location == NSNotFound) {
        return [data valueForKey:key];
    }else{
        NSString* forwardKey = [key substringToIndex:location];
        NSString* behandkey = [key substringFromIndex:location+1];
        //递归
        NSDictionary* subData = [data valueForKey:forwardKey];
        return [self getValue:subData forKey:behandkey];
    }
    return nil;
}

- (UITableView *) getTableViewFor:(UIView *)view
{
    UIView* superView = [view superview];
    
    if (!superView) {
        return nil;
    }
    
    if ([superView isKindOfClass:[UITableView class]]) {
        return (UITableView *)superView;
    }
    
    return [self getTableViewFor:superView];
}
@end

@implementation ECSectionViewTextView
- (id) initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.textView = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, frame.size.width - 20, 0)];
        [self.textView setBackgroundColor:[UIColor clearColor]];
        self.textView.numberOfLines = 0;
        [self.textView setFont:TextFieldFont];
    }
    return self;
}
- (void) setContent:(NSString *)content
{
    self.textView.text = content;
    CGRect frame = self.textView.frame;
    frame.size.width = self.frame.size.width - 20;
    [self.textView setFrame:frame];
    [self.textView sizeToFit];
    
    
    frame.size.height = self.textView.frame.size.height+10;
    frame.origin.x = IOS7_OR_LATER ? 10 : 0;
    [self.textView setFrame:frame];
    [self setFrame:frame];
    
    [self.backgroundView addSubview:self.textView];
    [self addSubview:self.backgroundView];
}
- (void) setBgColor:(UIColor *)backgroundColor
{
    [self.backgroundView setBackgroundColor:backgroundColor];
}
@end


@implementation ECSectionViewImageCover
- (void) setImageUrl:(NSString *)imageUrl
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(imageContainerFrameChanged:) name:kImageContainerFrameChangedNoti object:nil];
    UIImage* defaultImage = [UIImage imageNamed:kDefaultImage];
    self.imageCover = self.imageCover ? self.imageCover : [[ECImageContainer alloc] initWithFrame:self.frame];
    [self.imageCover updateWithNormalImage:defaultImage hightedImage:nil];
    self.imageCover.tag = arc4random() % 100000;
    self.tag = self.imageCover.tag;
    [self.imageCover updateWithNormalImageURI:[ECUriUtil getDefaultImageUrl:imageUrl]];
    [self addSubview:self.imageCover];
}
- (void)imageContainerFrameChanged:(NSNotification*)noti
{
    id obj = [noti object];
    if (obj && ((ECImageContainer *)obj).tag == self.tag) {
        [self.imageCover setFrame:CGRectMake(0,0, self.imageCover.imageView.frame.size.width, self.imageCover.imageView.frame.size.height)];
        [self.imageCover.imageView setFrame:self.imageCover.frame];
        [self setFrame:self.imageCover.frame];
    }
    UITableView* superView = [self getTableViewFor:self];
    if (superView) {
        [superView reloadData];
    }
}
@end

#import "ECKeyChain.h"
@implementation ECSectionUserInfo

- (id) initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(initContent) name:@"logoutCmd.logoutSuccess" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(initContent) name:@"ECLoginController.loginSuccess" object:nil];
    return self;
}
- (void) initContent
{
    if (self.config) {
        _userInfo.text = [ECKeyChain userName] ? [ECKeyChain userName] : @"尚未登录";
        [_header updateWithNormalImageURI:[ECUriUtil getSmallImageUrl:[self getContent:@"headerImageKey"]]];
    }
    [self setActionButtonStatus];
}
- (void) initView
{
    [self setFrame:CGRectMake(0, 0, self.frame.size.width, 66)];
    //    [self setBackgroundColor:[UIColor clearColor]];
    self.header = _header ? _header :[[ECImageContainer alloc] initWithFrame:CGRectMake(10, 8, 50, 50)];
    [self.header setBackgroundColor:[UIColor clearColor]];
    [_header updateWithNormalImage:[UIImage imageNamed:@"mine.png"] hightedImage:nil];
    [self addSubview:_header];
    self.userInfo = _userInfo ?_userInfo : [[UILabel alloc] initWithFrame:CGRectMake(70, 18, 130, 30)];
    [self.userInfo setBackgroundColor:[UIColor clearColor]];
    [self addSubview:_userInfo];
    
    self.actionButton = _actionButton ? _actionButton : [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [self.actionButton setFrame:CGRectMake(244, 11, 66, 44)];
    [self.actionButton setBackgroundColor:[UIColor clearColor]];
//    [self addSubview:_actionButton];
    
    
    [self initContent];
}
- (void) setActionButtonStatus
{
//    self.action = nil;
    if ([ECKeyChain userName]) {
        _buttonAction = @"eccm://logout";
        [_actionButton setTitle:@"注 销" forState:UIControlStateNormal];
    }else{
        _buttonAction = @"ecct://login?configName=ECLoginConfig";
        [_actionButton setTitle:@"登 录" forState:UIControlStateNormal];
    }
    [_actionButton addTarget:self action:@selector(doAction:) forControlEvents:UIControlEventTouchUpInside];
}
#pragma mark - override
//- (void) doAction:(id)sender
//{
//    if ([sender isKindOfClass:[UIButton class]]) {
//        [[ECEventRouter shareInstance] doAction:_buttonAction];
//    }
//}
@end

@interface ECCountDownView ()
@property (nonatomic) long secondsLeft;
@property (nonatomic, strong) NSTimer* timer;
@property (strong, nonatomic) UILabel* countDownLabel;
@end

@implementation ECCountDownView
#define LabelFormat @"<font color = \"red\">%i</font> 天 <font color = \"red\">%i</font> 小时 <font color = \"red\">%i</font> 分 <font color = \"red\">%i</font> 秒"

#import "NSDataExtends.h"

- (id) initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, 44)];
    if (self) {
        _countDownLabel = [[UILabel alloc] init];
        [_countDownLabel setBackgroundColor:[UIColor clearColor]];
        [self addSubview:_countDownLabel];
    }
    return self;
}
- (void) initContent
{
    _endTime = [NSDate dateFromString:[self getValue:self.dataSource forKey:[self.config objectForKey:@"endTimeKey"]] formate:@"yyyy-MM-dd HH:mm:ss"];
    [self setEndTime:_endTime];
}
- (void) setEndTime:(NSDate *)endTime
{
    _endTime = endTime;
    _secondsLeft = [[NSDate new] isEarlierWithDate:_endTime] ? [endTime timeIntervalSinceNow] : 0;
    [self updateStatus];
    if (_timer) {
        return;
    }
    _timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(updateStatus) userInfo:nil repeats:YES];
}

- (void)updateStatus
{
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if (_secondsLeft == 0) {
            [_timer invalidate];
            return;
        }
        _secondsLeft --;
        _countDownLabel.attributedText = [NSAttributedString attributedStringWithHtmlString:[NSString stringWithFormat:LabelFormat,[self getDay],[self getHour],[self getMimute],[self getSecond]] defaultFont:[_countDownLabel font]];
        
        [_countDownLabel sizeToFit];
        [_countDownLabel setFrame:CGRectMake((self.frame.size.width - _countDownLabel.frame.size.width) / 2.0, (self.frame.size.height - _countDownLabel.frame.size.height) / 2.0, _countDownLabel.frame.size.width, _countDownLabel.frame.size.height)];
    });
    
}
#pragma mark- utils
- (NSInteger) getDay
{
    return  _secondsLeft / 86400;
}
- (NSInteger) getHour
{
    return _secondsLeft % 86400 / 3600;
}
- (NSInteger) getMimute
{
    return _secondsLeft % 3600 / 60;
}
- (NSInteger) getSecond
{
    return _secondsLeft % 60;
}
@end

#import "ECCMController.h"
@implementation ECApplyCouponButton

#define ECApplyCouponButtonBackGroundImageEnable @"jingan-35.png"
#define ECApplyCouponButtonBackGroundImageDisable @"apply-button.png"
- (void) initView
{
    UIImage* image = [UIImage imageNamed:ECApplyCouponButtonBackGroundImageEnable];
    _applyButton = [[UIButton alloc] initWithFrame:CGRectMake((self.frame.size.width - image.size.width) / 2.0, 0, image.size.width, image.size.height)];
    
    [self setFrame:CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, _applyButton.frame.size.height)];
    [self setBackgroundColor:[UIColor clearColor]];
    [self addSubview:_applyButton];
    [self updateApplyState];
}
- (void) initContent
{
    _applyCode = [self getValue:self.dataSource forKey:[self.config objectForKey:@"applyCodeKey"]];
    _itemId = [self getValue:self.dataSource forKey:[self.config objectForKey:@"couponidKey"]];
    [self updateApplyState];
}
- (void) updateApplyState
{
    switch ([_applyCode integerValue]) {
        case 1:
            [self setApplyButtonTitle:@"申领未开始" enble:NO];
            break;
        case 2:
            [self setApplyButtonTitle:@"立即申领" enble:YES];
            break;
        case 3:
            [self setApplyButtonTitle:@"申领已结束" enble:NO];
            break;
        case 4:
            [self setApplyButtonTitle:@"该票已申领完" enble:NO];
            break;
        default:
            [self setApplyButtonTitle:[NSString stringWithFormat:@"验证码：%@",_applyCode] enble:NO];
            break;
    }
    
}
- (void) setApplyButtonTitle:(NSString *)title enble:(BOOL)enble
{
    if (enble) {
        [_applyButton setBackgroundImage:[UIImage imageNamed:ECApplyCouponButtonBackGroundImageEnable] forState:UIControlStateNormal];
        [_applyButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_applyButton addTarget:self action:@selector(applyCoupon) forControlEvents:UIControlEventTouchUpInside];
    }else{
        [_applyButton setBackgroundImage:[UIImage imageNamed:ECApplyCouponButtonBackGroundImageDisable] forState:UIControlStateNormal];
        [_applyButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_applyButton removeTarget:self action:@selector(applyCoupon) forControlEvents:UIControlEventTouchUpInside];
    }
    [_applyButton setTitle:title forState:UIControlStateNormal];
}
- (void) applyCoupon
{
    NSDictionary* params = @{@"contentid":_itemId,@"method":@"activity.applycoupon"};
    NSString* notiName = [NSString randomString:0 maxLength:20 minLength:10];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applyCouponSuccessed:) name:[NSString stringWithFormat:@"%@.netRuqestSuccessed",notiName] object:nil];
    [ECCMController requestWithParams:params successedMessage:@"申领成功" faildMessage:@"申领失败，请稍后重新操作！" isNeedLogin:YES notiName:notiName];
}
- (void) applyCouponSuccessed:(NSNotification *)noti
{
    _applyCode = [[noti.userInfo objectForKey:@"Success"] objectForKey:@"code"];
    [self updateApplyState];
}
@end


@implementation ECSectionViewRoundRectButton

- (void) initContent
{
    self.title = [self.config objectForKey:@"title"];
}

- (void) initView
{
    [self setBackgroundColor:[UIColor clearColor]];
    
    UIImage* image = [UIImage imageNamed:@"jingan-35.png"];
    UILabel* button = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
    [button setCenter:CGPointMake(self.frame.size.width/2, self.frame.size.height/2)];
    
    [button setBackgroundColor:[UIColor colorWithPatternImage:image]];
    [self addSubview:button];
    
    button.text = self.title;
    button.textAlignment = NSTextAlignmentCenter;
    
}


@end