//
//  ECSectionViewCell.h
//  jinganledongtiyu
//
//  Created by cheng on 13-11-12.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ECSectionViewController.h"

#define TitleFont [UIFont systemFontOfSize:15]
#define SubTitleFont [UIFont systemFontOfSize:13]
#define SectionTitleFont [UIFont systemFontOfSize:17]
#define TextFieldFont [UIFont systemFontOfSize:13]

@interface ECSectionViewCell : UITableViewCell

@property (strong, nonatomic) NSString* action;//存储控件动作
@property (strong, nonatomic) NSDictionary* config;//存储控件配制信息
@property (strong, nonatomic) NSDictionary* dataSource;//存储数据， sectionViewController获取的全部数据，只充许引用，不可更改
@property (strong, nonatomic) NSString* ID;//存储请求id 通常为sectionViewController的 requestId
- (void) initAction;

/**
 *  初始化方法，sectionviewcontroller 根据配制文件，自动调用,不可重载
 */
- (id) initWithFrame:(CGRect)frame config:(NSDictionary *)config dataSource:(NSDictionary *)dataSource;

/**
 *  默认的用户单击事件，对自定义视图，实现了其它其他用户事件，可忽略该方法
 */
- (void) doAction:(NSDictionary *)params;

/**
 *  initView、initContent实现方法为空，
 *  继承该类，需实现这两个方法
 *  内部调用，不允许做为实例方法使用
 */

//- (void) initContent;
//- (void) initView;

/**
 *  初始化方法，sectionviewcontroller 自动调用,可根据需要重载
 */
- (id) initWithFrame_pravite:(CGRect)frame;

/**
 *  辅助方法
 */
- (NSString *) getContent:(NSString *)content;
-(id)getValue:(NSDictionary *)data forKey:(NSString *)key;

/**
 *
 */
- (UITableView *) getTableViewFor:(UIView *)view;
@end

/**
 *  ECSectionViewTextView
 */
@interface ECSectionViewTextView : ECSectionViewCell
@property (strong, nonatomic) NSString* content;
@property (strong, nonatomic) UILabel* textView;
@property (strong, nonatomic) UIColor* bgColor;
@end
/**
 *  ECSectionViewImageCover
 */
#import "ECImageContainer.h"
@interface ECSectionViewImageCover : ECSectionViewCell
@property (strong, nonatomic) NSString* imageUrl;
@property (strong, nonatomic) UIImage* image;
@property (strong, nonatomic) ECImageContainer* imageCover;
@property (strong, nonatomic) UIColor* bgColor;
@end
/**
 *  user info view
 */
@interface ECSectionUserInfo : ECSectionViewCell
@property (strong, nonatomic) ECImageContainer* header;
@property (strong, nonatomic) UILabel* userInfo;
@property (strong, nonatomic) UIButton* actionButton;
@property (strong, nonatomic) NSString* buttonAction;
@end

@interface ECCountDownView : ECSectionViewCell
@property (strong, nonatomic) NSDate* endTime;
@end

@interface ECApplyCouponButton : ECSectionViewCell
@property (strong, nonatomic) UIButton* applyButton;
@property (strong, nonatomic) NSString* applyCode;
@property (strong, nonatomic) NSString* itemId;
@end

/**
*   ECSectionViewRoundRectButton
*/
@interface ECSectionViewRoundRectButton : ECSectionViewCell
@property (strong, nonatomic) NSString* title;

@end
