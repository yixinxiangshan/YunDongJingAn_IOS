//
//  ECAuthenticationView.h
//  jinganledongtiyu
//
//  Created by cheng on 13-11-14.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSectionViewCell.h"
#import "AuthenticationManager.h"

@class Authentication;
/**
 *  邦定类型    authenticationType
 *  身份证         id_card_number
 *  身份证
 *  身份证
 *  身份证
 *  身份证
 */


@interface ECAuthenticationView : ECSectionViewCell
@property NSString* authenticationType;
@end

