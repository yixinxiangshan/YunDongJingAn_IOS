//
//  ECSectionViewTitleCell.m
//  jinganledongtiyu
//
//  Created by cheng on 13-11-13.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSectionViewTitleCell.h"

@interface ECSectionViewTitleCell ()
@property (strong, nonatomic) UILabel* titleLabel;
@end

@implementation ECSectionViewTitleCell

- (void) initContent
{
    self.title = [self getContent:@"title"];
    NSString* titleAlignment = [self.config objectForKey:@"titleAlignment"];
    if ([titleAlignment isEqualToString:@"center"]) {
        self.titleAlignment = NSTextAlignmentCenter;
    }else if ([titleAlignment isEqualToString:@"right"]){
        self.titleAlignment = NSTextAlignmentRight;
    }else{
        self.titleAlignment = NSTextAlignmentLeft;
    }
    
    NSLog(@"title : %@    ",self.title);
}


- (void) initView
{
    [self setBackgroundColor:[UIColor clearColor]];
    
    self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 22)];
    self.titleLabel.textAlignment = self.titleAlignment;
    [self.titleLabel setBackgroundColor:[UIColor clearColor]];
    
    self.titleLabel.text = self.title;
    
    [self addSubview:self.titleLabel];
    [self setFrame:self.titleLabel.frame];
}

@end
