//
//  ECSignUpItemText.h
//  jinganledongtiyu
//
//  Created by cheng on 13-11-26.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSignUpItem.h"

@interface ECSignUpItemText : ECSignUpItem <UITextFieldDelegate>

@end
