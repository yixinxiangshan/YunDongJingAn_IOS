//
//  ECSignUpItemHidden.m
//  jinganledongtiyu
//
//  Created by cheng on 13-12-18.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSignUpItemHidden.h"

@implementation ECSignUpItemHidden

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void) initContent
{
    [super initContent];
    self.value = [self.config objectForKey:@"default_value"];
}

- (void) initView
{
    [self setFrame:CGRectMake(0, 0, 320, 0)];
}

@end
