//
//  ECSignUpItem.m
//  jinganledongtiyu
//
//  Created by cheng on 13-11-26.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSignUpItem.h"

@implementation ECSignUpItem

- (id) initWithConfig:(NSDictionary *)config
{
    self = [super initWithFrame:CGRectMake(0, 0, 320, 55)];
    if (self) {
        self.config = config;
        [self initContent];
        [self initView];
    }
    
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
- (void) initContent
{
    self.title = [self.config objectForKey:@"text"];
    self.option = [self.config objectForKey:@"name"];
    
    self.value = [self.config objectForKey:@"default_value"];
    
    if (self.value.length == 0) {
        self.value = nil;
    }
}

- (void) initView
{
    UILabel* titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 80, 44)];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    titleLabel.textAlignment = NSTextAlignmentLeft;
    titleLabel.text = self.title;
    [titleLabel setCenter:CGPointMake(50, 27)];
    [self addSubview:titleLabel];
}


@end
