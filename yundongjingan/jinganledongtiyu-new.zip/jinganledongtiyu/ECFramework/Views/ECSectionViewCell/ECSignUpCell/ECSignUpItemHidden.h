//
//  ECSignUpItemHidden.h
//  jinganledongtiyu
//
//  Created by cheng on 13-12-18.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSignUpItem.h"

@interface ECSignUpItemHidden : ECSignUpItem

@end
