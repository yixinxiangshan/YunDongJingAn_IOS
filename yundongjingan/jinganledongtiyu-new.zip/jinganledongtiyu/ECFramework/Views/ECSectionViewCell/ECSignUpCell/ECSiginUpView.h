//
//  ECSginUpView.h
//  jinganledongtiyu
//
//  Created by cheng on 13-11-26.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSectionViewCell.h"


@interface ECSiginUpView : ECSectionViewCell
/**
 *  报名表表单
 */
@property (strong, nonatomic) NSArray* inputList;

@end


/**
 *  submit button
 */

@interface ECSignUpCommit : UIView

@end