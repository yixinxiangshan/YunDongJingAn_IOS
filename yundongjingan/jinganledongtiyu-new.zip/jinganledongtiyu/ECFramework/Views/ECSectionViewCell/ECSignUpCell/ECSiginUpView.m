//
//  ECSginUpView.m
//  jinganledongtiyu
//
//  Created by cheng on 13-11-26.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSiginUpView.h"
#import "NSStringExtends.h"
#import "ECSignUpItem.h"
#import "ECCMController.h"
#import "NSStringExtends.h"

@interface ECSiginUpView ()

/**
 *  报名表，记录输入信息
 */
@property (strong,nonatomic) NSMutableDictionary* signupForm;

//containerView
@property (strong, nonatomic) UITableView* containerView;

/**
 *  subViews
 */
@property (strong, nonatomic) NSMutableArray* formItemViews;

// commit button
@property (strong, nonatomic) ECSignUpCommit* commitButton;

/**
 *  commit data
 */
@property (strong, nonatomic) NSMutableDictionary* commitData;
@end

@implementation ECSiginUpView

- (void) initContent
{
    self.inputList = [self getValue:self.dataSource forKey:[self.config objectForKey:@"inputListKey"]];
}

- (void) initView
{
    if (![self.inputList isKindOfClass:[NSArray class]]) {
        return;
    }
    if (!self.formItemViews) {
        self.formItemViews = [NSMutableArray new];
    }
    [self.formItemViews removeLastObject];
    [self setBackgroundColor:[UIColor clearColor]];
    
    NSString* itemLayoutName ;
    Class class;
    for (NSDictionary* config in self.inputList) {
        itemLayoutName = [config objectForKey:@"default_layout"];
        itemLayoutName = [itemLayoutName upperFirstCharString];
        
        class = NSClassFromString([NSString stringWithFormat:@"ECSignUpItem%@",itemLayoutName]);
        
        ECSignUpItem* itemView = [[class alloc] initWithConfig:config];
        if (itemView) {
            [self.formItemViews addObject:itemView];
            [self addSubview:itemView];
        }
        
    }
    
    self.commitButton = [[ECSignUpCommit alloc] initWithFrame:CGRectMake(0, 0, 320, 66)];
    [self addSubview:self.commitButton];
    [self layoutSubviews];
}

#pragma mark -
- (void) layoutSubviews
{
    CGFloat viewHeight = 0;
    
    for (UIView *subView in self.formItemViews) {
        
        [subView setFrame:CGRectMake(0, viewHeight, subView.frame.size.width, subView.frame.size.height)];
        viewHeight += subView.frame.size.height;
    }
    
    [self.commitButton setFrame:CGRectMake(0, viewHeight, 320, self.commitButton.frame.size.height)];
    
    viewHeight += self.commitButton.frame.size.height;
    
    [self setFrame:CGRectMake(0, 0, 320, viewHeight)];
}

- (void) doAction:(NSDictionary *)params
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"resignFirstResponder" object:nil];
    
}


#pragma mark- commit
- (void) commitForm
{
    if (!self.commitData) {
        self.commitData = [NSMutableDictionary new];
    }
    
    for (ECSignUpItem* item in self.formItemViews) {
        
        if (!item.value || !item.value.length) {
            [self showAlertWith:[NSString stringWithFormat:@"%@,不能为空！",item.title]];
            return;
        }
        
        [self.commitData setObject:item.value forKey:item.option];
    }
    
    [self.commitData setObject:@"form/schemes/forms/create" forKey:@"method"];
    [self.commitData setObject:@"1.0" forKey:@"apiversion"];
    
//    [self.commitData setObject:self.ID forKey:@"scheme_id"];
    
    ECLog(@"%@ : %@",self.class,self.commitData);
    
//    return;
    
    NSString* notiName = [NSString randomString:0.5 maxLength:20 minLength:10];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(commitSuccessed:) name:[NSString stringWithFormat:@"%@.%@",notiName,ECCMNETREQUEST_SUCCESSED] object:nil];
    
    [ECCMController requestWithParams:self.commitData successedMessage:NO_SUCCESSALERT_MSSAGE faildMessage:@"报名失败，请重新操作！" isNeedLogin:YES notiName:notiName];

}
#pragma mark- 报名成功
- (void) commitSuccessed:(NSNotification *) noti
{
    [[[ECPopViewUtil currentViewController] navigationController] popViewControllerAnimated:YES];
    [self showAlertWith:@"报名成功！"];
}
- (void) showAlertWith:(NSString *)msg
{
    UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:nil message:msg delegate:nil cancelButtonTitle:@"确  定" otherButtonTitles:nil, nil];
    
    [alertView show];
}

@end


@implementation ECSignUpCommit

- (id) initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:CGRectMake(0, 0, 320, 66)];
    if (self) {
        [self setBackgroundColor:[UIColor clearColor]];
        
        UIImage* image = [UIImage imageNamed:@"jingan-35.png"];
        UILabel* button = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
        [button setCenter:CGPointMake(self.frame.size.width/2, self.frame.size.height/2)];
        
        [button setBackgroundColor:[UIColor colorWithPatternImage:image]];
        [self addSubview:button];
        
        button.text = @"提   交";
        button.textAlignment = NSTextAlignmentCenter;
        
        UITapGestureRecognizer* tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(commit)];
        [self addGestureRecognizer:tapGestureRecognizer];
    }
    return self;
}

#pragma mark- commit
- (void) commit
{
    UIView* commitResponder = [self queryCommitResponder:self];
    
    if (commitResponder) {
        [commitResponder performSelector:@selector(commitForm) withObject:nil afterDelay:0.0];
    }
}
- (UIView *) queryCommitResponder:(UIView *)view
{
    UIView* superview = [view superview];
    if (!superview) {
        return nil;
    }
    if ([superview respondsToSelector:@selector(commitForm)]) {
        return superview;
    }else{
        return [self queryCommitResponder:superview];
    }
}
@end