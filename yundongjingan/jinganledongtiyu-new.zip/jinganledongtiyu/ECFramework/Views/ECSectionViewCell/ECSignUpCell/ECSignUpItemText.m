//
//  ECSignUpItemText.m
//  jinganledongtiyu
//
//  Created by cheng on 13-11-26.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSignUpItemText.h"

@interface ECSignUpItemText ()

@property (strong, nonatomic) NSString* backGroundWords;

@end

@implementation ECSignUpItemText

- (void) initContent
{
    [super initContent];
    self.backGroundWords = [self.config objectForKey:@"background_wrods"];
}

- (void) initView
{
    [super initView];
    
    UITextField* inputField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 200, 44)];
    inputField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    inputField.delegate = self;
    inputField.placeholder = self.backGroundWords;
    inputField.returnKeyType = UIReturnKeyDone;
    [inputField setCenter:CGPointMake(197.5, 27)];
    [[NSNotificationCenter defaultCenter] addObserver:inputField selector:@selector(resignFirstResponder) name:@"resignFirstResponder" object:nil];
    
    [self addSubview:inputField];
    
    seperator
}
#pragma mark- UITextFieldDelegate
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    self.value = textField.text;
}
- (BOOL) textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

@end
