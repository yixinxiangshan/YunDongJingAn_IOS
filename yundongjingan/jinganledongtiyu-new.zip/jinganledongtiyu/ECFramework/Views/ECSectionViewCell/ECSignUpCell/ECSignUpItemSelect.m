//
//  ECSignUpItemSelect.m
//  jinganledongtiyu
//
//  Created by cheng on 13-11-26.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSignUpItemSelect.h"
#import "ECPopupSelView.h"
@interface ECSignUpItemSelect () <ECECPopupSelectedDelegate>

@property (strong, nonatomic) NSString* backGroundWords;

@property (strong, nonatomic) ECPopupSelView* popupSelView;

@property (strong, nonatomic) UITextField* resultLabel;

@end

@implementation ECSignUpItemSelect

- (void) initContent
{
    [super initContent];
    self.options = [[self.config objectForKey:@"selectlist"] objectForKey:@"options"];
    self.backGroundWords = [NSString stringWithFormat:@"请先择%@",[self.config objectForKey:@"background_wrods"]];
}

- (void) initView
{
    [super initView];
    
    self.resultLabel = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 160, 44)];
    self.resultLabel.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    self.resultLabel.placeholder = self.backGroundWords;
    self.resultLabel.enabled = NO;
    
    [self.resultLabel setCenter:CGPointMake(177.5, 27)];
    [[NSNotificationCenter defaultCenter] addObserver:self.resultLabel selector:@selector(resignFirstResponder) name:@"resignFirstResponder" object:nil];
    
    self.resultLabel.text = self.value;
    [self addSubview:self.resultLabel];
    
    UIImageView* moreImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"more.png"]];
    [moreImage setCenter:CGPointMake(300, 27.5)];
    
    [self addSubview:moreImage];

    seperator
    
    //popselector
    self.popupSelView = [[ECPopupSelView alloc] initWithArray:self.options];
    [self.popupSelView setTitle:self.title];
    self.popupSelView.selectedDelegate = self;
    
    //点击事件
    UITapGestureRecognizer* tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(popSelector)];
    [self addGestureRecognizer:tapGestureRecognizer];
}

#pragma mark -
- (void) popSelector
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"resignFirstResponder" object:nil];
    [self.popupSelView show];

}

#pragma mark - ECECPopupSelectedDelegate
- (void) popupSelView:(ECPopupSelView *)popupSelView didSelectItemAtIndex:(NSIndexPath *)indexPath
{
    self.value = [[self.options objectAtIndex:indexPath.row] objectForKey:@"value"];
    
    self.resultLabel.text = [[self.options objectAtIndex:indexPath.row] objectForKey:@"text"];
}
@end
