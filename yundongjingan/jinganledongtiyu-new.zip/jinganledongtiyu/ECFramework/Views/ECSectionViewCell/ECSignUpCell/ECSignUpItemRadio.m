//
//  ECSignUpItemRadio.m
//  jinganledongtiyu
//
//  Created by cheng on 13-11-26.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSignUpItemRadio.h"
#import "UIViewExtends.h"

@implementation ECSignUpItemRadio 

- (void) initContent
{
    [super initContent];
    self.options = [[self.config objectForKey:@"selectlist"] objectForKey:@"options"];
}

- (void) initView
{
    [super initView];
        
    Radio* radio = [[Radio alloc] initWithFrame:CGRectMake(0, 0, 225, 0) Config:self.options];
    radio.delegate = self;
    
    [self addSubview:radio];
    
    [self setFrame:CGRectMake(0, 0, 320, radio.frame.size.height > self.frame.size.height ? radio.frame.size.height : self.frame.size.height)];
    
    [radio setCenter:CGPointMake(197.5, self.frame.size.height/2.0)];
    
    seperator
}

#pragma mark- RadioDelegate
- (void) radio:(Radio *)radio didChangedItem:(RadioItem *)radioItem
{
    self.value = radioItem.value;
}

@end


//Radio

@interface Radio () <RadioItemDelegate>
@property (strong, nonatomic) NSMutableArray* radioItems;
@end
@implementation Radio

- (id) initWithFrame:(CGRect)frame Config:(NSArray *)config
{
    self = [super initWithFrame:frame];
    if (self) {
        self.config = config;
        [self initView];
    }
    return self;
}

#pragma mark-
- (void) initView
{
    if (!self.radioItems) {
        self.radioItems = [NSMutableArray new];
    }
    [self.radioItems removeAllObjects];
    [self removeAllSubViews];
    
    for (NSDictionary* config in self.config) {
        RadioItem* item = [[RadioItem alloc] initWithTitle:[config objectForKey:@"text"] value:[config valueForKey:@"value"]];
        item.delegate = self;
        
        [self.radioItems addObject:item];
        [self addSubview:item];
    }
    [self layoutSubviews];
}

#pragma mark -

- (void) layoutSubviews
{
    for (int i = 0 ; i < self.radioItems.count ; i ++) {
        UIView* view = [self.radioItems objectAtIndex:i];
        [view setCenter:CGPointMake(37 + 75 * (i%3), 22 + 44 * (i/3))];
    }
    
    [self setFrame:CGRectMake(self.frame.origin.x, self.frame.origin.y, 225, 44 * (self.radioItems.count / 3 + 1))];
}

#pragma mark- RadioItemDelegate

- (void) radioItemSelected:(RadioItem *)radioItem
{
    for (RadioItem* item in self.radioItems) {
        if (![radioItem isEqual:item] && item.isOn) {
            [item setIsOn:NO];
        }
    }
    
    if ([self.delegate respondsToSelector:@selector(radio:didChangedItem:)]) {
        [self.delegate radio:self didChangedItem:radioItem];
    }
}
@end


@interface RadioItem ()
@property (strong, nonatomic) UIImageView* radioButton;

@end
@implementation RadioItem

- (id) initWithTitle:(NSString *)title value:(NSString *)value
{
    self = [super init];
    if (self) {
        self.isOn = NO;
        self.title = title;
        self.value = value;
        
        [self initView];
        
        UITapGestureRecognizer* tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(radioItemSelected)];
        [self addGestureRecognizer:tapGestureRecognizer];
    }
    return self;
}

- (void) setIsOn:(BOOL)isOn
{
    _isOn = isOn;
    [self updateStatus];
}
#pragma mark -
- (void) initView
{
    UILabel* titleLabel = [[UILabel alloc] init];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    titleLabel.text = self.title;
    [titleLabel sizeToFit];
    
    if (titleLabel.frame.size.width > 40.0) {
        [titleLabel setWidth:40.0];
    }
    [titleLabel setCenter:CGPointMake(titleLabel.frame.size.width / 2.0, 22)];
    
    [self addSubview:titleLabel];
    
    self.radioButton = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"radio_off"]];
    [self.radioButton setCenter:CGPointMake(titleLabel.frame.size.width + 5 + self.radioButton.frame.size.width / 2.0, 22)];
    
    [self addSubview:self.radioButton];
    
    [self setFrame:CGRectMake(0, 0, self.radioButton.frame.size.width + 10 + titleLabel.frame.size.width, 44)];
}
- (void) updateStatus
{
    if (self.isOn) {
        [self.radioButton setImage:[UIImage imageNamed:@"radio_on"]];
    }else{
        [self.radioButton setImage:[UIImage imageNamed:@"radio_off"]];
    }
}
#pragma mark - delegate
- (void) radioItemSelected
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"resignFirstResponder" object:nil];
    self.isOn = !self.isOn;
    [self updateStatus];
    if ([self.delegate respondsToSelector:@selector(radioItemSelected:)]) {
        [self.delegate radioItemSelected:self];
    }
}
@end