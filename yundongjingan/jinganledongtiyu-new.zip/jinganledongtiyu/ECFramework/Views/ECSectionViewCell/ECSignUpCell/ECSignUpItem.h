//
//  ECSignUpItem.h
//  jinganledongtiyu
//
//  Created by cheng on 13-11-26.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import <UIKit/UIKit.h>
//分害线
#define seperator UIView* seperatorLine = [[UIView alloc] initWithFrame:CGRectMake(0, self.frame.size.height, 320, 1)];[seperatorLine setBackgroundColor:[UIColor lightGrayColor]];[self addSubview:seperatorLine];

@interface ECSignUpItem : UIView
@property (strong, nonatomic) NSDictionary* config;

@property (strong, nonatomic) NSString* title;
/**
 *  存储控件结果
 */
@property (strong, nonatomic) NSString* value;

@property (strong, nonatomic) NSString* option;

- (id) initWithConfig:(NSDictionary *)config;

/**
 *  初始化view
 */
- (void) initContent;
- (void) initView;
@end
