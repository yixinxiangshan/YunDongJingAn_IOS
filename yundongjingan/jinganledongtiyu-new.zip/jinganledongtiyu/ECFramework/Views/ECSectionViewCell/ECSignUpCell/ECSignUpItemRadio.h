//
//  ECSignUpItemRadio.h
//  jinganledongtiyu
//
//  Created by cheng on 13-11-26.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSignUpItem.h"

@protocol RadioDelegate;

@interface ECSignUpItemRadio : ECSignUpItem <RadioDelegate>

@property (strong, nonatomic) NSArray* options;
@end


/**
 *  Radio
 */

@protocol RadioItemDelegate;

@class RadioItem;

@interface Radio  : UIView

@property (strong, nonatomic) NSArray* config;

@property (strong, nonatomic) id<RadioDelegate> delegate;

- (id) initWithFrame:(CGRect)frame Config:(NSArray *)config;
@end


@protocol RadioDelegate <NSObject>

- (void) radio:(Radio *)radio didChangedItem:(RadioItem *)radioItem;

@end


/**
 *  RadioItem
 */

@interface RadioItem : UIView
@property (nonatomic, setter = setIsOn:) BOOL isOn;
@property (strong, nonatomic) NSString* title;
@property (strong, nonatomic) NSString* value;

@property (strong, nonatomic) id<RadioItemDelegate> delegate;

- (id) initWithTitle:(NSString *)title value:(NSString *)value;

@end

@protocol RadioItemDelegate <NSObject>


- (void) radioItemSelected:(RadioItem *)radioItem;

@end