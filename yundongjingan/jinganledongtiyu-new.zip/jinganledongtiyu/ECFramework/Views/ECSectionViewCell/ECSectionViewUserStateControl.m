//
//  ECSectionViewUserStateControl.m
//  jinganledongtiyu
//
//  Created by cheng on 13-11-21.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSectionViewUserStateControl.h"
#import "ECCMController.h"
#import "ECEventRouter.h"

@implementation ECSectionViewUserStateControl

- (id) initWithFrame_pravite:(CGRect)frame
{
    self = [super initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    
    return self;
}

- (void) initView
{
    self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    self.textLabel.font = [UIFont systemFontOfSize:15];
    // 注册监听
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateState) name:@"ECLoginController.loginSuccess" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateState) name:@"logoutCmd.logoutSuccess" object:nil];
    [self updateState];
    
}

- (void) updateState
{
    if ([[ECCMController shareInstance] hadLogin]) {
        self.textLabel.text = @"注销";
    }else{
        self.textLabel.text = @"登录/注册";
    }
}

- (void) doAction:(NSDictionary *)params
{
    if ([[ECCMController shareInstance] hadLogin]) {
        [[ECEventRouter shareInstance] doAction:@"eccm://logout"];
    }else{
        [[ECEventRouter shareInstance] doAction:@"ecct://login?configName=ECLoginConfig"];
    }
}
@end
