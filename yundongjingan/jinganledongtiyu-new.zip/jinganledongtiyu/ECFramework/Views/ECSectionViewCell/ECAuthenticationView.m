//
//  ECAuthenticationView.m
//  jinganledongtiyu
//
//  Created by cheng on 13-11-14.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECAuthenticationView.h"
#import "NSStringExtends.h"
#import "ECCMController.h"
#import "ECPopViewUtil.h"
#import "ECJsonParser.h"



@interface ECAuthenticationView ()
@property (strong,nonatomic) NSMutableArray* authentications;
@property (strong, nonatomic) UILabel* statusLabel;
@end

@implementation ECAuthenticationView

- (id) initWithFrame_pravite:(CGRect)frame
{
    
    self = [super initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    
    return self;
}

- (void) initContent
{
    self.authenticationType = [self.config objectForKey:@"authenticationType"];
    [[NSNotificationCenter defaultCenter] addObserver:self  selector:@selector(updateAuthenticationStatus:) name:@"AuthenticationManager.didUpdateAuthentication" object:nil];
//    NSLog(@"self.suthenticationType : %@",self.authenticationType);
}
- (void) initView
{
    
    self.textLabel.text = [self.config objectForKey:@"title"];
    self.textLabel.font = [UIFont systemFontOfSize:15];
    
    self.detailTextLabel.font = [UIFont systemFontOfSize:13];
    
    NSInteger status = [[[AuthenticationManager shareInstance] queryAuthenticationWithType:self.authenticationType] getStatus];
    if (status != 1) {
        [[AuthenticationManager shareInstance] updateAuthentication];
    }else{
        self.detailTextLabel.text = [AUTHENTICATIONSTATUS objectAtIndex:0];
    }
    self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
}

- (void) updateAuthenticationStatus:(NSNotification *)noti
{
    NSLog(@"AuthenticationManager.didUpdateAuthentication");
    self.detailTextLabel.text = [AUTHENTICATIONSTATUS objectAtIndex:[[[AuthenticationManager shareInstance] queryAuthenticationWithType:self.authenticationType] getStatus]];
    
}

#pragma mark-  override doAction
- (void) doAction:(NSDictionary *)params
{
    NSInteger status = [[[AuthenticationManager shareInstance] queryAuthenticationWithType:self.authenticationType] getStatus];
    if ( status == 2) {
        
        [ECPopViewUtil toast:@"工作人员正在审核，请耐心等待。" position:@"center"];
        return;
    }
    //已经过认证，则不做作何处理
    if (status == 1) {
        return;
    }
    
    if (![[ECCMController shareInstance] hadLogin]) {
        [[ECEventRouter shareInstance] doAction:@"ecct://login?configName=ECLoginConfig"];
        return;
    }
    
    [[ECEventRouter shareInstance] doAction:@"ecct://sectionview?configName=ECAuthenticateConfig" userInfo:@{@"navTitle":[self.config objectForKey:@"title"]}];
}

@end

