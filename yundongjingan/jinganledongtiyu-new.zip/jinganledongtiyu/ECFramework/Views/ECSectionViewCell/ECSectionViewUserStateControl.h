//
//  ECSectionViewUserStateControl.h
//  jinganledongtiyu
//
//  Created by cheng on 13-11-21.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSectionViewCell.h"

@interface ECSectionViewUserStateControl : ECSectionViewCell

@end
