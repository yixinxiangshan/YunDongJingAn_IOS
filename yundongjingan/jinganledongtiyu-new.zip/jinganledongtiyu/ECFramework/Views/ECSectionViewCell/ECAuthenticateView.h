//
//  ECAuthenticateView.h
//  jinganledongtiyu
//
//  Created by cheng on 13-11-14.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSectionViewCell.h"

@class AuthenticateData;

@interface ECAuthenticateView : ECSectionViewCell

/**
 *  需传入 inputForm
 *  
 */
@property (strong, nonatomic) NSArray* inputForm;

/**
 *  提交信息
 *
 */

- (void) submit;

@end

@interface ECAuthenticateViewCell : UIView
@property (strong, nonatomic) NSDictionary* config;

@property (strong, nonatomic) AuthenticateData* content;

- (id) initWithConfig:(NSDictionary *)config;

/**
 *   初始化视图
 */
- (void) initView;

@end

/**
 *   SubmitButton
 */

@interface SubmitButton : ECAuthenticateViewCell

@end

/**
*   TextInputView
*/

@interface TextInputView : ECAuthenticateViewCell <UITextFieldDelegate>

@property (strong, nonatomic) UITextField* inputField;

@end

/**
 *
 */
@interface ECAuthenticateViewCellTextLabel : ECAuthenticateViewCell

@end

/**
 *   ImageSeletView
 */

@interface ImageSeletView : ECAuthenticateViewCell

@property (strong, nonatomic) UIButton* selectedImage;
@property (strong, nonatomic) UILabel* selectButton;
@end


/**
 *   图片选择器，从底部弹出，选择相册图片或拍摄照片
 */
@protocol ImageSelectorDelegate;
@interface ImageSelector : UIView <UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@property (strong, nonatomic) id<ImageSelectorDelegate> delegate;


+ (id) shareInstance;
+ (void) popWithDelegate:(id)delegate;

@end

@protocol ImageSelectorDelegate <NSObject>

- (void) imageSelector:(ImageSelector *)selector didSelectImage:(UIImage *)image;

@end

/**
*   数据类型
*/
typedef NS_ENUM(NSInteger, AuthenticateDataType) {
    AuthenticateDataString,
    AuthenticateDataImage,
    AuthenticateDataImagePath
};
@interface AuthenticateData : NSObject

@property (nonatomic) AuthenticateDataType type;

@property (strong, nonatomic) id value;

+ (AuthenticateData *) initWithType:(AuthenticateDataType)type value:(id)value;
@end