//
//  ECSectionViewTitleCell.h
//  jinganledongtiyu
//
//  Created by cheng on 13-11-13.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECSectionViewCell.h"

@interface ECSectionViewTitleCell : ECSectionViewCell

/**
 *  配制：@{title:
 *         titleKey:
 *         titleAlignment:
 *          }
 */
@property (strong, nonatomic) NSString* title;

/**
 *  标题位置
 */
@property  NSTextAlignment titleAlignment;
@end
