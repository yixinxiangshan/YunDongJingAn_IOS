//
//  SinUpMenuItem.m
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-15.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "SinUpMenuItem.h"
#import "ECEventRouter.h"

@implementation SinUpMenuItem

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)doAction:(UIButton *)sender {
    
    
    NSMutableDictionary* params = [NSMutableDictionary new];
    [params addEntriesFromDictionary:self.requestParams];
    [params setValue:[NSString stringWithFormat:@"%i",sender.tag] forKey:@"tag"];
    
    NSLog(@"%@ doAction : %@ ,params : %@",self.class,[self.config valueForKey:@"action"],params);

    [[ECEventRouter shareInstance] doAction:[self.config valueForKey:@"action"] userInfo:params];
}

-(void) refreshView
{
    
    self.title.text = [self.config valueForKey:@"title"];
}


@end
