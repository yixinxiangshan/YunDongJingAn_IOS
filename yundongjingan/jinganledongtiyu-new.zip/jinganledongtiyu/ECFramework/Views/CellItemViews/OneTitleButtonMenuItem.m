//
//  OneTitleButtonMenuItem.m
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-8.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "OneTitleButtonMenuItem.h"
#import <QuartzCore/QuartzCore.h>
#import "ECEventRouter.h"

@implementation OneTitleButtonMenuItem
@synthesize viewContainer;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)doAction:(id)sender {
    NSString* action = [self.config valueForKey:@"action"];
    
    NSLog(@"%@ doAction : %@",self.class,action);
    
    [[ECEventRouter shareInstance] doAction:action userInfo:self.requestParams];
    
}

- (void)refreshView
{
    //设置圆角边框
    viewContainer.layer.cornerRadius = 5;
    viewContainer.layer.masksToBounds = YES;
    //设置边框及边框颜色
    viewContainer.layer.borderWidth = 2;
    viewContainer.layer.borderColor =[ [UIColor grayColor] CGColor];
    
    self.title.text = [self.config valueForKey:@"title"] ;
    //add GestureRecognizer
    UITapGestureRecognizer* singleGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doAction:)];
    [self.viewContainer addGestureRecognizer:singleGestureRecognizer];
    
    
}


@end
