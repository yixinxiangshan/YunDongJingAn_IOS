//
//  SectionMenuItem.h
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-2.
//  Copyright (c) 2013年 EC. All rights reserved.
//


//没有加入动作




#import <UIKit/UIKit.h>

@interface SectionMenuItem : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UIControl *sectionContainer;

@property (strong, nonatomic) NSDictionary* content;
@property (strong, nonatomic) NSArray* configs;
@property (strong, nonatomic) NSDictionary* config;
@property  BOOL isLocalSection;
@property (strong, nonatomic) NSDictionary* requestParams;


-(void) refreshSection;
//-(void) doAction:(id)sender;
@end

@interface mGestureRecognizer : UITapGestureRecognizer
@property (strong, nonatomic) NSString* action;
@property (strong, nonatomic) NSDictionary* param;

@end