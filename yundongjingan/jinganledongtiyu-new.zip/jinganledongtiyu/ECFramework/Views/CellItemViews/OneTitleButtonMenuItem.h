//
//  OneTitleButtonMenuItem.h
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-8.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OneTitleButtonMenuItem : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *viewContainer;
@property (weak, nonatomic) IBOutlet UILabel *title;

@property (strong, nonatomic) NSDictionary* config;
@property (strong, nonatomic) NSDictionary* requestParams;

-(void) refreshView;
@end
