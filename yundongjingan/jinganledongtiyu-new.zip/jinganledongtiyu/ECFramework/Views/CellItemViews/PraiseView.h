//
//  PraiseView.h
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-3.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ECToolComment.h"

@interface PraiseView : UIControl <ECToolCommentDelegate, UITextFieldDelegate>

@property (strong, nonatomic) NSString* requestId ;
@property (nonatomic, strong) ECToolComment* toolComment;

- (id)initWithFrame:(CGRect)frame andParams:(NSDictionary *)params;
-(void) show;

@end
