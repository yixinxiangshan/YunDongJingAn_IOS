//
//  ButtonMenuItem.m
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-1.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "ButtonMenuItem.h"
#import <QuartzCore/QuartzCore.h>
#import "ECEventRouter.h"

@implementation ButtonMenuItem
@synthesize cellContainer;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
           }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (void)doAction:(id)sender {
    NSString* action = [self.config valueForKey:@"action"];
    
    
    NSMutableDictionary* params = [NSMutableDictionary new];
    [params addEntriesFromDictionary:self.requestParams];
    [params setValue:[self.config valueForKey:@"label"] forKey:@"navTitle"];
    
    NSLog(@"%@ doAction : %@  userInfo :%@",self.class,action,params);
    
    [[ECEventRouter shareInstance] doAction:action userInfo:params];
    
}

- (void)refreshView
{
    //设置圆角边框
    cellContainer.layer.cornerRadius = 3;
    cellContainer.layer.masksToBounds = YES;
    //设置边框及边框颜色
    cellContainer.layer.borderWidth = 1;
    cellContainer.layer.borderColor =[ [UIColor grayColor] CGColor];
    
    //add GestureRecognizer
    UITapGestureRecognizer* singleGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doAction:)];
    [self.item addGestureRecognizer:singleGestureRecognizer];
    
    [self.message setText:[self.config valueForKey:@"label"]];

}

@end
