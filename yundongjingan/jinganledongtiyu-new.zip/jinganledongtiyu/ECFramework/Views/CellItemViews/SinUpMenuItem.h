//
//  SinUpMenuItem.h
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-15.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SinUpMenuItem : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *title;
- (IBAction)doAction:(UIButton *)sender;

@property (strong, nonatomic) NSDictionary* config ;
@property (strong, nonatomic) NSDictionary* requestParams;

-(void) refreshView;
@end
