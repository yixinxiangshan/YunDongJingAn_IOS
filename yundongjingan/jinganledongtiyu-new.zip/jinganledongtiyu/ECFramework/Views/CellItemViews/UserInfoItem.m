//
//  UserInfoItem.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-17.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "UserInfoItem.h"
#import "ECKeyChain.h"
#import "ECEventRouter.h"
#import "NSStringExtends.h"
#import "ECSpecRequest.h"

@implementation UserInfoItem

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)login:(UIButton *)sender {
    if ([sender.titleLabel.text isEqualToString:@"注销"]) {
        [ECKeyChain saveUserName:nil password:nil deviceID:[UIDevice UDID] accessToken:nil];
        [[ECSpecRequest shareInstance] getAccessToken];
        self.nickName.text = @"尚未登录";
        [self.loginButton setTitle:@"登录" forState:UIControlStateNormal];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"logoutCmd.logoutSuccess" object:nil userInfo:nil];
        return;
    }
    [[ECEventRouter shareInstance] doAction:@"ecct://login?configName=ECLoginConfig"];
}

- (void) initInfo
{
    [self getUserInfo];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getUserInfo) name:@"ECLoginController.loginSuccess" object:nil];
}
-(void) getUserInfo
{
    NSString* userName = [ECKeyChain userName];
    if (nil == userName || [@"" isEqualToString:userName]) {
    
//        [[ECEventRouter shareInstance] doAction:@"ecct://login?configName=ECLoginConfig"];
        
        return;
    }

    self.nickName.text = [ECKeyChain userName];
    [self.loginButton setTitle:@"注销" forState:UIControlStateNormal];
//    [self.faceImage setImage:[UIImage ]];
}

@end
