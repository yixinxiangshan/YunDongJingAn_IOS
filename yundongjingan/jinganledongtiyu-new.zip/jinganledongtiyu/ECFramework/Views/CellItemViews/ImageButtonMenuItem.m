//
//  ImageButtonMenuItem.m
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-1.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "ImageButtonMenuItem.h"
#import "ECEventRouter.h"
#import "ECCMController.h"

@implementation ImageButtonMenuItem

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void) refreshView
{
    //add GestureRecognizer
    UITapGestureRecognizer* singleGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doAction:)];
    [self.imageContainer addGestureRecognizer:singleGestureRecognizer];
    
    [self.imageContainer updateWithNormalImage:[UIImage imageNamed:[self.config valueForKey:@"image"]] hightedImage:nil];
    [self.message setText:[self.config valueForKey:@"label"]];
}
- (void)doAction:(id)sender {
    NSLog(@"%@ doAction : %@ ,params : %@",self.class,[self.config valueForKey:@"action"],self.requestParams);
    
    
    [[ECEventRouter shareInstance] doAction:[self.config valueForKey:@"action"] userInfo:self.requestParams];
    
    // 暂时直接调用，不走 EventRouter
}
@end
