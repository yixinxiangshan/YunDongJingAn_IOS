//
//  ImageButtonMenuItem.h
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-1.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ECImageContainer.h"

@interface ImageButtonMenuItem : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *message;
@property (weak, nonatomic) IBOutlet ECImageContainer *imageContainer;

@property (strong, nonatomic) NSDictionary* config ;
@property (strong, nonatomic) NSDictionary* requestParams;

-(void) refreshView;
@end
