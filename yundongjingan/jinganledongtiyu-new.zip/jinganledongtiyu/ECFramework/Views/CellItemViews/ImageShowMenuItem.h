//
//  ImageShowMenuItem.h
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-1.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ECImageContainer.h"

@interface ImageShowMenuItem : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UIScrollView *imageContainer;

@property (weak, nonatomic) NSString* content;

@property (strong, nonatomic) NSMutableArray* imageList;
@property (weak, nonatomic) NSString* image;

@property (strong, nonatomic) ECImageContainer* wholeImage;

-(void) refreshScrollView;
@end

