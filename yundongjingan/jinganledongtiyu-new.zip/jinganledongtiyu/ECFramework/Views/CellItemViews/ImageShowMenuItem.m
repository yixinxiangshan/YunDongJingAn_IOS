//
//  ImageShowMenuItem.m
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-1.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "ImageShowMenuItem.h"

#import "ECUriUtil.h"
#import <QuartzCore/QuartzCore.h>
#import "SectionMenuItem.h"

#define imageWidth 98
#define imageHeight 98

@implementation ImageShowMenuItem
@synthesize content;
@synthesize imageContainer;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void) refreshScrollView
{
    
    //设置圆角边框
    imageContainer.layer.cornerRadius = 5;
    imageContainer.layer.masksToBounds = YES;
    //设置边框及边框颜色
    imageContainer.layer.borderWidth = 2;
    imageContainer.layer.borderColor =[ [UIColor grayColor] CGColor];
    
    
    self.imageList = [[NSMutableArray alloc] init];
    [self imageListFromContent];
    for (int i = 0; i < self.imageList.count; i ++) {
        ECImageContainer* imageView = [[ECImageContainer alloc] initWithFrame:CGRectMake(10+(10+imageWidth)*i, 10, imageWidth, imageHeight)];
        
        NSString* imageuri = [ECUriUtil getSmallImageUrl:[self.imageList objectAtIndex:i]];
        [imageView updateWithNormalImageURI:imageuri];
        [imageView setClipsToBounds:YES];
        
        mGestureRecognizer* singleGestureRecognizer = [[mGestureRecognizer alloc] initWithTarget:self action:@selector(showImage:)];
        singleGestureRecognizer.action = [self.imageList objectAtIndex:i];
        
        [imageView addGestureRecognizer:singleGestureRecognizer];
        [self.imageContainer addSubview:imageView];
        
    }
   
}
-(void) imageListFromContent
{
    if (content == nil) {
        return ;
    }
    
    NSLog(@"%@ : %@",self.class,self.content);
    NSString *search = @".jpg";
    NSMutableString *mstr = [NSMutableString stringWithString:content];
    NSRange substr = [mstr rangeOfString:search];
    while (substr.location != NSNotFound) {
        
        substr.length += 7 ;
        substr.location -= 7 ;
        
        [self.imageList addObject:[mstr substringWithRange:substr]];
        substr = [mstr rangeOfString:search];
        [mstr replaceCharactersInRange:substr withString:@""];
        substr = [mstr rangeOfString:search];
    }

}

- (void) showImage:(mGestureRecognizer *)sender
{
    NSLog(@"%@ : %@",self.class,sender.action);
    
    self.wholeImage = [[ECImageContainer alloc] initWithFrame:[[self superview] frame]];
    [[self superview] addSubview:self.wholeImage];
    
    UITapGestureRecognizer* hidden = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hidden)];
    [self.wholeImage addGestureRecognizer:hidden];
    
    NSString* imageuri = [ECUriUtil getWholeImageUrl:sender.action];
    [self.wholeImage updateWithNormalImageURI:imageuri];
    [self.wholeImage setClipsToBounds:NO];

    
}
-(void) hidden
{
    [self.wholeImage removeFromSuperview];
}

@end
