//
//  PraiseView.m
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-3.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "PraiseView.h"
#import "ECKeyChain.h"
#import "ECNetRequest.h"
#import "ECBaseViewController.h"
#import "ECEventRouter.h"

@implementation PraiseView

- (id)initWithFrame:(CGRect)frame andParams:(NSDictionary *)params
{
    self = [super initWithFrame:frame];
    if (self) {
        self.requestId = [params valueForKey:@"id"];
        if (self.requestId == nil) {
            self.requestId = [params valueForKey:@"requestId"];
        }
        NSLog(@"RequestId : %@ in %@",self.requestId,params);
        [self setBackgroundColor:[UIColor colorWithRed:0.92 green:0.92 blue:0.92 alpha:0.3]];
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
        _toolComment = [[ECToolComment alloc] initWithFrame:CGRectMake(0, validHeight()-233, validWidth(), 44)];
        _toolComment.actionDelegate = self;
        _toolComment.commentText.delegate = self ;
        
        _toolComment.commentText.returnKeyType = UIReturnKeySend ;
//        _toolComment.commentButtonItem.title = @"确定" ;
        [self addSubview:_toolComment];
        
        UITapGestureRecognizer* tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismiss)];
        [self addGestureRecognizer:tapGestureRecognizer];
    }
    return self;
}
//监听键盘变化，调整视图
-(void)keyboardWillShow:(NSNotification*)notification{
    NSDictionary* info=[notification userInfo];
    CGSize kbSize=[[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    //在这里调整UI位置
    
    [_toolComment setFrame:CGRectMake(0, validHeight()+20 - kbSize.height, validWidth(), 44)];
}
-(void) show
{
    NSLog(@"%@  show ",self.class);
    [[[[[[UIApplication sharedApplication] windows] objectAtIndex:0] rootViewController] view] addSubview:self];
    [_toolComment.commentText becomeFirstResponder];
}

- (void) didSubmitButtonClicked:(ECToolComment*) toolComment{
    [self submitComment];
   }
#pragma mark - 网络请求成功
- (void)addCommentFindished:(FormDataRequest*)request{
    
    NSString* reponseString = [request responseString];
    if ([reponseString rangeOfString:@"\"error\""].location != NSNotFound || [reponseString rangeOfString:@"\"Error\""].location != NSNotFound) {
        [[ECSpecRequest shareInstance] showError:reponseString];
        NSLog(@"response error:%@",reponseString);
    }
    else if([reponseString rangeOfString:@"Success"].location != NSNotFound) {
        self.toolComment.commentText.text = @"";
        }
    
    
    id tempData = nil;
    //处理数据
    id obj = [ECJsonParser objectWithJsonData:request.responseData];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        tempData = [obj valueForKey:@"data"];
    }
//    NSString* commentMsg = @"";
//    if (nil != [tempData objectForKey:@"point_data"]) {
//        id loginDic = [tempData objectForKey:@"point_data"];
//        if (nil != [loginDic objectForKey:@"point_message"] && ![[loginDic objectForKey:@"point_message"] isEqualToString:@""]) {
//            commentMsg = [loginDic objectForKey:@"point_message"];
//        }
//    }
    NSString* commentMsg;
    if ([[tempData objectForKey:@"success"] boolValue]) {
        commentMsg = @"评论成功";
    }else{
        commentMsg = @"评论失败，请重新操作";
    }
    UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:nil
                                                        message:commentMsg
                                                       delegate:nil
                                              cancelButtonTitle:@"确定"
                                              otherButtonTitles:nil, nil];
    [alertView show];

    // 处理完成后 移除加载框
    [self removeLoading];
    
}

- (void)showLoading:(NSString*)message{
    if ([NetRequestManager networdEnabled]) {
        [ECPopViewUtil showLoading:message view:self];
    }
}
- (void)removeLoading{
    [ECLoadingBezelActivityView removeViewAnimated:YES];
}


- (BOOL) submitComment
{
    NSLog(@"submit commment");
    if (nil == [ECKeyChain userName] || [@"" isEqualToString:[ECKeyChain userName]]) {
        [[ECEventRouter shareInstance] doAction:@"ecct://login?configName=ECLoginConfig"];
        [self removeFromSuperview];
        return NO;
    }
    
    
    if (nil != _toolComment.commentText.text && ![@"" isEqualToString:_toolComment.commentText.text]) {
        //网络请求
        NSMutableDictionary* params = [NSMutableDictionary new];
        [params setObject:addComment() forKey:@"method"];
        [params setObject:@"1.0" forKey:@"apiversion"];
        [params setObject:self.requestId forKey:@"content_id"];
        [params setObject:@"2" forKey:@"typenum"];
        [params setObject:_toolComment.commentText.text forKey:@"content"];
        FormDataRequest* request = [FormDataRequest requestNetURI:API_URL
                                                           params:params
                                                         delegate:self
                                                 finishedSelector:@selector(addCommentFindished:)
                                                     failSelector:@selector(webRequestFailed:)];
        if (request) {
            [[NetRequestManager sharedInstances] addOperation:request];
            [self showLoading:nil];
        }
        
        [self removeFromSuperview];
        
    }else{
        UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:@"内容为空"
                                                            message:@"说点什么呗"
                                                           delegate:nil
                                                  cancelButtonTitle:@"确定"
                                                  otherButtonTitles:nil, nil];
        [alertView show];
    }
    
    return YES;

}
#pragma mark- dismiss
- (void) dismiss
{
    [self removeFromSuperview];
    
}

#pragma mark- UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self submitComment];
    return NO;
}
@end
