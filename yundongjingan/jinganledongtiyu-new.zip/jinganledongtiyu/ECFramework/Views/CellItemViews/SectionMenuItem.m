//
//  SectionMenuItem.m
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-2.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "SectionMenuItem.h"
#import<QuartzCore/QuartzCore.h>
#import "DisplayUtil.h"
#import "ECEventRouter.h"
#import "ECImageContainer.h"

@implementation SectionMenuItem
@synthesize sectionContainer;
@synthesize content;
@synthesize configs;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void) refreshSection
{
    NSLog(@"%@ : %@",self.class,self.content);
    
    //设置圆角边框
    sectionContainer.layer.cornerRadius = 8;
    sectionContainer.layer.masksToBounds = YES;
    //设置边框及边框颜色
    sectionContainer.layer.borderWidth = 2;
    sectionContainer.layer.borderColor =[ [UIColor grayColor] CGColor];
    
    int itemWidth = sectionContainer.frame.size.width ;
    int itemHeight = 44 ;
    
    int sectionHeight = 0 ;
    
    if (self.isLocalSection) {
        for (int i = 0 ; i < configs.count ; i ++) {
            
            
            NSDictionary* config = [configs objectAtIndex:i];
            
            if ((nil != [config valueForKey:@"type"]) && [[config valueForKey:@"type"] isEqual:@"twolinecell"]) {
                ECImageContainer* leftImage = [[ECImageContainer alloc] initWithFrame:CGRectMake(5, 5, 54, 54)];
                [leftImage updateWithNormalImage:[UIImage imageNamed:[config valueForKey:@"leftImage"]] hightedImage:nil];
                
                UILabel* titleLine = [[UILabel alloc] initWithFrame:CGRectMake(66, 0, itemWidth-66, 33)];
                UILabel* contentLine = [[UILabel alloc] initWithFrame:CGRectMake(66, 33, itemWidth-66, 33)];
                
                titleLine.text = @"当前账号";
                contentLine.text = @"尚未登录";
                //seprateLine
                UIView* seprateline = [[UIView alloc] initWithFrame:CGRectMake(0, 66, itemWidth, 1)];
                [seprateline setBackgroundColor:[UIColor grayColor]];
                
                NSString* title = [self getValue:self.content forKey:[config valueForKey:@"titleKey"]];
                if (nil != title && ![title isEqualToString:@""]) {
                    titleLine.text = title;
                }
                
                NSString* contents = [self getValue:self.content forKey:[config valueForKey:@"contentKey"]];
                if (nil != contents && ![contents isEqualToString:@""])
                {
                    contentLine.text = contents;
                }
               
                [leftImage updateWithNormalImageURI:[self getValue:self.content forKey:[config valueForKey:@"imageCover"]]];
                
                //item
                UIControl* item = [[UIControl alloc] initWithFrame:CGRectMake(0, sectionHeight, itemWidth, itemHeight)];
                [item addSubview:leftImage];
                [item addSubview:titleLine];
                [item addSubview:contentLine];
                [item addSubview:seprateline];
                
                //add GestureRecognizer
                mGestureRecognizer* singleGestureRecognizer = [[mGestureRecognizer alloc] initWithTarget:self action:@selector(doAction:)];
                singleGestureRecognizer.action = [NSString stringWithFormat:@"%@",[config valueForKey:@"action"]];
                singleGestureRecognizer.param = self.requestParams;
                [item addGestureRecognizer:singleGestureRecognizer];
                
                //add to container
                [sectionContainer addSubview:item];

                sectionHeight += 66 ;
                
                continue;
            }
            
//            NSLog(@"%@",config);
            //leftimage
            UIImageView* leftimage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:[config valueForKey:@"leftImage"]]];
            [leftimage setFrame:CGRectMake(5, 5, 33, 33)];
            //label
            
            UILabel* itemLabel ;
            
            if ((nil != [config valueForKey:@"leftImage"]) && ![[config valueForKey:@"leftImage"] isEqual:@""]) {
                itemLabel = [[UILabel alloc] initWithFrame:CGRectMake(44, 2, itemWidth - 64, itemHeight-4)];
            }else{
                itemLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 2, itemWidth - 64, itemHeight-4)];
            }
            
            if (![[config valueForKey:@"titleKey"] isEqual:@""]) {
                [itemLabel setText:[self getValue:content forKey:[config valueForKey:@"titleKey"]]];
//                [itemLabel setText:[content valueForKey:[config valueForKey:@"titleKey"]]];
            }else{
                [itemLabel setText:[config valueForKey:@"title"]];
            }
            
            //rightimage
            UIImageView* rightimage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"more.png"]];
            [rightimage setFrame:CGRectMake(itemWidth-30, 14, 10, 15)];
            //seprateLine
            UIView* seprateline = [[UIView alloc] initWithFrame:CGRectMake(0, itemHeight, itemWidth, 1)];
            [seprateline setBackgroundColor:[UIColor grayColor]];
            
            //item
            UIControl* item = [[UIControl alloc] initWithFrame:CGRectMake(0, sectionHeight, itemWidth, itemHeight)];
            [item addSubview:leftimage];
            [item addSubview:itemLabel];
            if (![[config valueForKey:@"action"] isEqual:@""]) {
                [item addSubview:rightimage];
            }
            [item addSubview:seprateline];
            
            //add GestureRecognizer
            mGestureRecognizer* singleGestureRecognizer = [[mGestureRecognizer alloc] initWithTarget:self action:@selector(doAction:)];
            singleGestureRecognizer.action = [NSString stringWithFormat:@"%@",[config valueForKey:@"action"]];
            singleGestureRecognizer.param = self.requestParams;
            [item addGestureRecognizer:singleGestureRecognizer];
            
            //add to container
            [sectionContainer addSubview:item];
            
            sectionHeight += 44 ;
        }
        [sectionContainer setFrame:CGRectMake(sectionContainer.frame.origin.x, sectionContainer.frame.origin.y, itemWidth, sectionHeight)];
   
    }else{
        if (![configs isKindOfClass:[NSArray class]]) {
            return;
        }
        for (int i = 0 ; i < configs.count ; i ++) {
            NSDictionary* config = [configs objectAtIndex:i];
            //label
            
            UILabel* itemLabel = [[UILabel alloc] initWithFrame:CGRectMake(11, 2, itemWidth - 64, itemHeight-4)];
            
                [itemLabel setText:[config valueForKey:[content valueForKey:@"titleKey"]]];
            
            //rightimage
            UIImageView* rightimage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"more.png"]];
            [rightimage setFrame:CGRectMake(itemWidth-30, 14, 10, 15)];
            //seprateLine
            UIView* seprateline = [[UIView alloc] initWithFrame:CGRectMake(0, itemHeight, itemWidth, 1)];
            [seprateline setBackgroundColor:[UIColor grayColor]];
            
            //item
            UIControl* item = [[UIControl alloc] initWithFrame:CGRectMake(0, i*itemHeight, itemWidth, itemHeight)];
            [item addSubview:itemLabel];
            if (![[content valueForKey:@"action"] isEqual:@""]) {
                [item addSubview:rightimage];
            }
            [item addSubview:seprateline];
            
            //add GestureRecognizer
            mGestureRecognizer* singleGestureRecognizer = [[mGestureRecognizer alloc] initWithTarget:self action:@selector(doAction:)];
            singleGestureRecognizer.action = [content valueForKey:@"action"];
            
            NSMutableDictionary* params = [NSMutableDictionary new];
            [params setObject:[NSString stringWithFormat:@"%@" ,[config valueForKey:[content valueForKey:@"idKey"]]] forKey:@"requestId"];
            [params setObject:itemLabel.text forKey:@"navTitle"];
            singleGestureRecognizer.param = params;
            
            [item addGestureRecognizer:singleGestureRecognizer];
            
            //add to container
            [sectionContainer addSubview:item];
        }
        [sectionContainer setFrame:CGRectMake(sectionContainer.frame.origin.x, sectionContainer.frame.origin.y, itemWidth, itemHeight*configs.count)];
    }
    
    [self setFrame:CGRectMake(0, 0, validWidth(), itemHeight*configs.count+50)];
    
}
- (void) doAction:(mGestureRecognizer *)sender
{
    NSLog(@"%@  : %@ \n userInfo : %@",self.class,sender.action,sender.param);
    [[ECEventRouter shareInstance] doAction:sender.action userInfo:sender.param];
}
-(id)getValue:(NSDictionary *)data forKey:(NSString *)key
{
    int location = [key rangeOfString:@"."].location;
    
    if (location == NSNotFound) {
        NSLog(@"value %@ fromkey : %@",[data valueForKey:key],key);
        return [data valueForKey:key];
    }else{
        NSString* forwardKey = [key substringToIndex:location];
        NSString* behandkey = [key substringFromIndex:location+1];
        //递归
        NSDictionary* subData = [data valueForKey:forwardKey];
        return [self getValue:subData forKey:behandkey];
    }
    return nil;
}

@end

@implementation mGestureRecognizer


@end
