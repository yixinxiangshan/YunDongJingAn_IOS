//
//  LabelMenuItem.m
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-1.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "LabelMenuItem.h"

@implementation LabelMenuItem

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

//-(void)layoutSubviews{
//    [super layoutSubviews];
//    [self.content sizeToFit];
//    [self setFrame:CGRectMake(0, 0, self.frame.size.width, self.title.frame.size.height+self.content.frame.size.height)];
//}
@end
