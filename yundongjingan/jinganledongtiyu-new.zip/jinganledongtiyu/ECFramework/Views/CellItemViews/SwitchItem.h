//
//  ChangerItem.h
//  jinganledongtiyu
//
//  Created by cww on 13-7-17.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SwitchItem : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *cellContainer;
@property (weak, nonatomic) IBOutlet UILabel *message;

@property (strong, nonatomic) NSDictionary* config;
@property (strong, nonatomic) NSDictionary* requestParams;

- (IBAction)switchChanged:(UISwitch *)sender;

- (void)refreshView;
@end
