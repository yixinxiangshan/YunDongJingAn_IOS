//
//  UserInfoItem.h
//  jinganledongtiyu
//
//  Created by cww on 13-7-17.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserInfoItem : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *faceImage;
@property (weak, nonatomic) IBOutlet UILabel *nickName;

@property (weak, nonatomic) IBOutlet UIButton *loginButton;
- (IBAction)login:(UIButton *)sender;
- (void) initInfo;
@end
