//
//  ChangerItem.m
//  jinganledongtiyu
//
//  Created by cww on 13-7-17.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "SwitchItem.h"
#import <QuartzCore/QuartzCore.h>
#import "ECEventRouter.h"

@implementation SwitchItem
@synthesize cellContainer;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)refreshView
{
    //设置圆角边框
    cellContainer.layer.cornerRadius = 3;
    cellContainer.layer.masksToBounds = YES;
    //设置边框及边框颜色
    cellContainer.layer.borderWidth = 1;
    cellContainer.layer.borderColor =[ [UIColor grayColor] CGColor];
    
    
    [self.message setText:[self.config valueForKey:@"label"]];
    
}

- (IBAction)switchChanged:(UISwitch *)sender {
    NSLog(@"%@ : switchChanged . Switcher's status %i",self.class,sender.on);
    
    NSMutableDictionary* params = [NSMutableDictionary new];
    [params addEntriesFromDictionary:self.requestParams];
    [params setValue:[NSString stringWithFormat:@"%i",sender.on] forKey:@"switcher"];
    [params setValue:[self.config valueForKey:@"label"] forKey:@"navTitle"];
    
    [[ECEventRouter shareInstance] doAction:[self.config valueForKey:@"action"] userInfo:params];
}
@end
