//
//  ECPopupSelView.h
//  JingAnWeekly
//
//  Created by EC on 3/22/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ECPopupSelView;

@protocol ECECPopupSelectedDelegate <NSObject>

@optional
- (void)selectedItemTitle:(NSString*)labelText;
- (void) popupSelView:(ECPopupSelView *)popupSelView didSelectItemAtIndex:(NSIndexPath *)indexPath;

@end

@interface ECPopupSelView : UIView <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView* tableView;
@property (nonatomic, strong) NSMutableArray* dataSource;
@property (nonatomic, strong) UILabel*     titleView;
@property (nonatomic, strong) UIControl*   overlayView;
@property (nonatomic, strong) id <ECECPopupSelectedDelegate> selectedDelegate;

- (id)initWithArray:(NSArray*)array;
- (void)show;
- (void)dismiss;
- (void)setTitle:(NSString *)title;

@end
