//
//  ECToolBar.m
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-11.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import "ECToolBar.h"
#import "ECEventRouter.h"
#import "KxMenu.h"
#import "DisplayUtil.h"

@interface ECToolBar ()
@property (nonatomic, strong) UIFont* textFont;
@property (nonatomic, strong) UIColor* textColor;
@end

@implementation ECToolBar

@synthesize textColor;
@synthesize textFont;

- (id)initWithFrame:(CGRect)frame menuFromServer:(NSArray *)menuFromServer localConfig:(NSArray *)localConfig
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setDefaultStyle];
        self.configs = localConfig;
        self.menuDataFromServer = menuFromServer;
        [self initMenu];
    }
    return self;
}

- (void) initMenu
{
    NSLog(@"%@ : initMenu  %i ",self.class,self.configs.count);
    CGFloat x = 0 ;
    for (int i  = 0 ; i < self.configs.count ; i ++) {
        NSDictionary* config = [self.configs objectAtIndex:i];
        
        UIButton* menuItem = [UIButton buttonWithType:UIButtonTypeCustom];
        [menuItem setFrame:CGRectMake(x, 0, [self menuItemWidth], 44)];
        [menuItem setTitleColor:textColor forState:UIControlStateNormal];
        [menuItem setFont:textFont];
        
        [menuItem setTitle:[config valueForKey:@"title"] forState:UIControlStateNormal] ;
        menuItem.tag = i ;
        
        [menuItem addTarget:self action:@selector(menuTouched:) forControlEvents:UIControlEventTouchUpInside];
        
        
        [self addSubview:menuItem];
        x += menuItem.frame.size.width;
    }
}
- (CGFloat) menuItemWidth
{
    if (self.configs.count <= 4) {
        return validWidth()/self.configs.count;
    }
    return validWidth()/4.0;
}
- (void) menuTouched:(UIButton *)sender
{
    NSDictionary* config = [self.configs objectAtIndex:sender.tag];
    
    if ([[config valueForKey:@"type"] isEqual:@"menuItem"]) {
        [self doAction:[config valueForKey:@"action"]];
        return;
    }
    [self popMenuList:sender];
   
}
-(void) popMenuList:(UIButton *)sender
{
     NSDictionary* menuconfig = [self.configs objectAtIndex:sender.tag];
    
    NSMutableArray* menuItems = [NSMutableArray new];
    
    if ([@"menu" isEqual: [menuconfig objectForKey:@"type"]]) {
        
        NSDictionary* configs = [menuconfig objectForKey:@"content"];
        
        
        for (NSDictionary *config in configs) {
            
            [menuItems addObject:[KxMenuItem menuItem:[config valueForKey:@"title"]
                                                image:nil
                                               target:self
                                                param:[config valueForKey:@"action"]
                                               action:@selector(getAction:)]];    //@select:()   action为点击后需要执行的动作
        }
    }
    else if ([@"menuFromeServer" isEqual: [menuconfig objectForKey:@"type"]]){
        if (self.menuDataFromServer == nil) {
            return;
        }
        NSDictionary* config = [menuconfig objectForKey:@"menuadapter"];
        for (NSDictionary* content in self.menuDataFromServer) {
            [menuItems addObject:[KxMenuItem menuItem:[content valueForKey:[config valueForKey:@"titleKey"]]
                                                image:nil
                                               target:self
                                                param:[NSString stringWithFormat:@"%@?%@=%@",[config valueForKey:@"action"],[config valueForKey:@"method"],[content valueForKey:[config valueForKey:@"idKey"]]]
                                               action:@selector(getAction:)]];
        }
    }
    [KxMenu showMenuInView:self.superview
                  fromRect:sender.frame
                 menuItems:menuItems];
}
-(void)getAction:(KxMenuItem *)sender
{
    [self doAction:sender.param];
}
-(void)doAction:(NSString *)action
{
    NSLog(@"%@ doAction : %@",self.class,action);
    if (action == nil || [action isEqual:@""]) {
        NSLog(@"%@ ERROR : action is null",self.class);
        return;
    }
    [[ECEventRouter shareInstance] doAction:action];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void) setDefaultStyle
{
    [self setBackgroundColor:[UIColor colorWithRed:0.91 green:0.96 blue:0.91 alpha:1.00]];
    textFont = [UIFont fontWithName:@"Courier" size:13];
    textColor = [UIColor colorWithRed:0.30 green:0.61 blue:0.36 alpha:1.00];
}
@end
