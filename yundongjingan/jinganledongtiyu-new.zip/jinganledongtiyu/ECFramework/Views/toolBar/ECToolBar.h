//
//  ECToolBar.h
//  XuHuiTiYuShengHuo
//
//  Created by cww on 13-7-11.
//  Copyright (c) 2013年 EC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ECToolBar : UIScrollView
@property  (strong, nonatomic) NSArray* configs;

@property (strong, nonatomic) NSArray* menuDataFromServer;

- (id)initWithFrame:(CGRect)frame menuFromServer:(NSArray *)menuFromServer localConfig:(NSArray *)localConfig;
@end
