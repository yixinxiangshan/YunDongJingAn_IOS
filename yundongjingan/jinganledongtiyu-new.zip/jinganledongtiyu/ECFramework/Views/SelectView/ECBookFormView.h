//
//  ECBookFormView.h
//  UINavigationControllerDemo
//
//  Created by cww on 13-9-23.
//  Copyright (c) 2013年 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>

#define ROW @"row"
#define COLUM @"colum"

@protocol ECBookFormViewDelegate;

@interface ECBookFormView : UIView <UIScrollViewDelegate>

@property (strong, nonatomic) id<ECBookFormViewDelegate> delegate;

- (void) setStatusLabels:(NSArray *)labelTitles markColor:(NSArray *)markColors;
- (void) setHorizontalLabels:(NSArray *) itemsTitle;
- (void) setVerticalLabels:(NSArray *) itemsTitle;

- (void) setStatus:(NSArray *)canBook;
@end

// object extends
@interface ECScrollView : UIScrollView
@property NSInteger subsCount;
@end

@interface ECBookFormItem : UIButton
@property (strong, nonatomic) NSString* horizontalLabel;
@property (strong, nonatomic) NSString* verticalLabel;
@property NSInteger ID;
@property (strong, nonatomic) NSString* label;
@property BOOL seclected;
@end

// delegate
@protocol ECBookFormViewDelegate <NSObject>

@optional
- (void) bookFormItemSelected:(ECBookFormItem *)item;
- (void) bookFormItemDeselected:(ECBookFormItem *)item;

@end