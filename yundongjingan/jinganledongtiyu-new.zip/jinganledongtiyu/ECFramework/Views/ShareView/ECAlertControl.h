//
//  ECAlertControl.h
//  jinganledongtiyu
//
//  Created by cheng on 14-2-19.
//  Copyright (c) 2014年 eCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ECAlertControl : UIControl

+ (void) showAlertViewWithXIBName:(NSString *)xibName;

+ (void) showAlertView:(UIView *)alertView;

+ (void) showAlertViewWithXIBName:(NSString *)xibName
                         observer:(id)observer
                        sureBlock:(void(^)(id observer))sureBlock
                      cancelBlock:(void(^)(id observer))cancelBlcok;
@end
