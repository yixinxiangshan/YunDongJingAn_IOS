//
//  ECAlertControl.m
//  jinganledongtiyu
//
//  Created by cheng on 14-2-19.
//  Copyright (c) 2014年 eCloud. All rights reserved.
//

#import "ECAlertControl.h"
#import <QuartzCore/QuartzCore.h>
#import "NSStringExtends.h"

@interface ECAlertControl ()

@property (nonatomic, weak) id observer;
@property (nonatomic, strong) void (^sureBlock)(id);
@property (nonatomic, strong) void (^cancelBlock)(id);

- (IBAction)cancel:(UIButton *)sender;

- (IBAction)sure:(id)sender;
@end
@implementation ECAlertControl

+ (id) instance
{
    static ECAlertControl *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    
    return instance;
}

+ (void) showAlertViewWithXIBName:(NSString *)xibName
{
    NSLog(@"xib name : %@",[xibName toCamel:YES]);
    UIView *alertView = [[[NSBundle mainBundle] loadNibNamed:[xibName toCamel:YES] owner:[ECAlertControl instance] options:nil] lastObject];
    [self showAlertView:alertView];
}

+ (void) showAlertView:(UIView *)alertView
{
    [[self instance] showAlertView:alertView];
}

+ (void) showAlertViewWithXIBName:(NSString *)xibName observer:(id)observer sureBlock:(void (^)(id))sureBlock cancelBlock:(void (^)(id))cancelBlcok
{
    NSLog(@"xib name : %@",[xibName toCamel:YES]);
    UIView *alertView = [[[NSBundle mainBundle] loadNibNamed:[xibName toCamel:YES] owner:[ECAlertControl instance] options:nil] lastObject];
    [[self instance] showAlertView:alertView observer:observer sureBlock:sureBlock cancelBlock:cancelBlcok];
}

#pragma mark- initDefault
- (id) init{
    self = [super initWithFrame:[[UIScreen mainScreen] bounds]];
    if (self) {
        [self setBackgroundColor:[[UIColor clearColor] colorWithAlphaComponent:0.0]];
    }
    return self;
}
- (void) showAlertView:(UIView *)view observer:(id)observer sureBlock:(void (^)(id))sureBlock cancelBlock:(void (^)(id))cancelBlcok
{
    self.observer = observer;
    self.sureBlock = sureBlock;
    self.cancelBlock = cancelBlcok;
    
    [self showAlertView:view];
}
- (void) showAlertView:(UIView *)view
{
    [view setCenter:self.center];
    [self addSubview:view];
    
    UIWindow *keywindow = [[UIApplication sharedApplication] keyWindow];
    [keywindow addSubview:self];
    
    view.transform = CGAffineTransformMakeScale(0, 0);
    [UIView animateWithDuration:0.3
                     animations:^{
                         [self setBackgroundColor:[[UIColor clearColor] colorWithAlphaComponent:0.7]];
                         view.transform = CGAffineTransformMakeScale(1, 1);
                     } completion:^(BOOL finished) {
                         __weak id SELF = self;
                         [self addTarget:SELF action:@selector(hide) forControlEvents:UIControlEventTouchUpInside];
                     }];
}

- (void) hide
{
    UIView *view = [[self subviews] lastObject];
    
    [UIView animateWithDuration:0.3
                     animations:^{
                         [self setBackgroundColor:[[UIColor clearColor] colorWithAlphaComponent:0]];
                         view.transform = CGAffineTransformMakeScale(0, 0);
                     } completion:^(BOOL finished) {
                         __weak id SELF = self;
                         [self addTarget:SELF action:@selector(hide) forControlEvents:UIControlEventTouchUpInside];
                         
                         [view removeFromSuperview];
                         [self removeFromSuperview];
                     }];
    self.observer = nil;
    self.cancelBlock = nil;
    self.sureBlock = nil;
}

- (IBAction)cancel:(UIButton *)sender {
    if (_cancelBlock) {
        _cancelBlock(_observer);
    }
    [self hide];
}

- (IBAction)sure:(id)sender {
    if (_sureBlock) {
        _sureBlock(_observer);
    }
    [self hide];
}
@end
