//
//  ECDetailView.h
//  JingAnWeekly
//
//  Created by EC on 3/18/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ECImageContainer.h"

@class ECDetail;
@protocol ECDetailDelegate <NSObject>
@optional
- (void) pressPraise:(ECDetail*)ecDetail;

- (void)touchedInside:(ECDetail*)ecDetail;

@end

@interface ECDetail : UIView <UIGestureRecognizerDelegate>

@property (strong, nonatomic) id <ECDetailDelegate> detailDelegate;

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UILabel *titleDetail;
@property (weak, nonatomic) IBOutlet ECImageContainer *imageContainer;
@property (weak, nonatomic) IBOutlet UILabel *content;
@property (weak, nonatomic) IBOutlet UIImageView *praiseButton;
@property (weak, nonatomic) IBOutlet UILabel *voteCount;
@property (weak, nonatomic) IBOutlet UIButton *shareButton;

- (void) setContents:(NSString *)contents;
- (IBAction)shareTo:(UIButton *)sender;

@end
