//
//  ECDetailView.m
//  JingAnWeekly
//
//  Created by EC on 3/18/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECDetail.h"

#define TEXTView_LINE_HEIGHT _content.font.pointSize*1.7

@implementation ECDetail

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [[NSBundle mainBundle] loadNibNamed:@"ECDetail" owner:self options:nil];
        [self addSubview:self.scrollView];
        [self.scrollView setFrame:self.frame];
        
        [self.scrollView addSubview:_praiseButton];
        [self.scrollView addSubview:self.titleDetail];
        [self.scrollView addSubview:self.imageContainer];
        [self.scrollView addSubview:self.content];
        [self.scrollView addSubview:self.voteCount];
        
//        self.content.editable = NO;
//        self.content.scrollEnabled = NO;
        [_praiseButton setUserInteractionEnabled:YES];
        UITapGestureRecognizer* singleTouch=[[UITapGestureRecognizer alloc] initWithTarget:self
                                                                                    action:@selector(praiseButtonClicked:)];
        [_praiseButton addGestureRecognizer:singleTouch];
        
        UITapGestureRecognizer* singleTouchView=[[UITapGestureRecognizer alloc] initWithTarget:self
                                                                                    action:@selector(touchedView:)];
        singleTouchView.delegate = self;
        
        [self addGestureRecognizer:singleTouchView];
        
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
- (void)praiseButtonClicked:(UITapGestureRecognizer*) sender{
    if (_detailDelegate && [_detailDelegate respondsToSelector:@selector(pressPraise:)]) {
        [_detailDelegate pressPraise:self];
    }
}

- (void)touchedView:(UITapGestureRecognizer*) sender{
    if (_detailDelegate && [_detailDelegate respondsToSelector:@selector(touchedInside:)]) {
        [_detailDelegate touchedInside:self];
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch{
    if ([touch.view isKindOfClass:[UIControl class]]) {
        // we touched a button, slider, or other UIControl
        return NO; // ignore the touch
    }
    return YES; // handle the touch
}


- (void) awakeFromNib{
    [super awakeFromNib];
    [self addSubview:self.scrollView];
    [self.scrollView addSubview:self.titleDetail];
    [self.scrollView addSubview:self.imageContainer];
    [self.scrollView addSubview:self.content];
}

- (IBAction)shareTo:(UIButton *)sender {
    
    
        
}

- (void) setContents:(NSString *)contents
{
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineHeightMultiple = TEXTView_LINE_HEIGHT;
    paragraphStyle.maximumLineHeight = TEXTView_LINE_HEIGHT;
    paragraphStyle.minimumLineHeight = TEXTView_LINE_HEIGHT;
    
    NSDictionary *ats = @{
                          NSFontAttributeName : _content.font,
                          NSParagraphStyleAttributeName : paragraphStyle,
                          };
    
    _content.attributedText = [[NSAttributedString alloc] initWithString:contents attributes:ats];
//    _content.text = contents;
    
    [_content sizeToFit];
    
//    CGSize size = [contents sizeWithAttributes:ats];
//    
//    CGFloat height = size.width * size.height / _content.frame.size.width;
//    [_content setFrame:CGRectMake(_content.frame.origin.x, _content.frame.origin.y, _content.frame.size.width, height)];
}
@end
