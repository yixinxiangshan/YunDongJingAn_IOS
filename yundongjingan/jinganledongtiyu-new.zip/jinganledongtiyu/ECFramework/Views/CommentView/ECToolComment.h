//
//  ECToolComment.h
//  JingAnWeekly
//
//  Created by EC on 3/18/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ECToolComment;

@protocol ECToolCommentDelegate <NSObject>

@optional
/**
 * called when the user submit the action
 */
- (void) didSubmitButtonClicked:(ECToolComment*) toolComment;

@end

@interface ECToolComment : UIToolbar

@property (nonatomic, strong) UIBarButtonItem* commentButtonItem;
@property (nonatomic, strong) UIBarButtonItem* commentTextItem;
@property (nonatomic, strong) UITextField* commentText;

@property (nonatomic, strong) id <ECToolCommentDelegate> actionDelegate;

@end
