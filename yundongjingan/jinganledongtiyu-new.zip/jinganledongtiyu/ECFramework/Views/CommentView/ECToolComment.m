//
//  ECToolComment.m
//  JingAnWeekly
//
//  Created by EC on 3/18/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECToolComment.h"
#import "Utils.h"
#import "UIColorExtends.h"

@implementation ECToolComment

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.commentText = [[UITextField alloc] initWithFrame:CGRectMake(8, 6, validWidth()-44-30, 32)];
        [self.commentText setBorderStyle:UITextBorderStyleRoundedRect];
        [self.commentText setPlaceholder:@"评论一下"];
        [self.commentText setReturnKeyType:UIReturnKeyDone];
        self.commentText.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        self.commentTextItem = [[UIBarButtonItem alloc] initWithCustomView:self.commentText];
        
        
        UIButton* commentButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        commentButton.frame = CGRectMake(validWidth()-44-30-16, 6,44, 32);
//        commentButton.titleLabel.text = @"评论";
        [commentButton setTitle:@"评论" forState:UIControlStateNormal];
        [commentButton addTarget:self action:@selector(submitComment:) forControlEvents:UIControlEventTouchUpInside];
        self.commentButtonItem = [[UIBarButtonItem alloc] initWithCustomView:commentButton];
//        self.commentButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"评论" style:UIBarButtonItemStyleDone target:self action:@selector(submitComment:)];
        self.commentButtonItem.tintColor = [UIColor colorWithHexString:@"#00595757"];
        self.commentButtonItem.tintColor = [UIColor colorWithRed:0.333 green:0.333 blue:0.333 alpha:1];

 
        self.items = [NSArray arrayWithObjects:_commentTextItem,_commentButtonItem,nil];
        self.translucent = YES;
        self.barStyle = UIBarStyleBlack;
    }
    return self;
}

- (IBAction)submitComment:(id)sender{
    if (_actionDelegate && [_actionDelegate respondsToSelector:@selector(didSubmitButtonClicked:)]) {
        [_actionDelegate didSubmitButtonClicked:self];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
