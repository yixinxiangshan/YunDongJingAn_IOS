//
//  ECDateSelector.h
//  jinganledongtiyu
//
//  Created by cheng on 13-10-8.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ECDateSelectorDelegate ;


@interface ECDateSelector : UIView
@property (strong, nonatomic) NSDate* startDate;
@property (strong, nonatomic) NSDate* endDate;
@property BOOL isWithWeekday;

@property (strong, nonatomic) NSDate* result;
@property (strong, nonatomic) id<ECDateSelectorDelegate> delegate;

- (void) setStartDate:(NSDate *)startDate endDate:(NSDate *)endDate;
@end

@protocol ECDateSelectorDelegate <NSObject>
- (void) dateSelector:(UIView *)dateSelector didSelectedDate:(NSDate *)date;
@end