//
//  ECBookListView.h
//  UINavigationControllerDemo
//
//  Created by cheng on 13-9-24.
//  Copyright (c) 2013年 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>

#define ItemName @"title"
#define ItemMessage @"message"

@protocol PopSelectorDelegate;
@protocol ECBookListViewDelegate;

@interface ECBookListView : UITableView

@property (strong, nonatomic) NSArray* configs;
@property (strong, nonatomic) id<ECBookListViewDelegate> bookDelegate;

- (id)initWithSuperView:(UIView *)superView frame:(CGRect)frame configs:(NSArray *)configs;
@end

/**
 *
 */
@interface ECBookListViewCell : UITableViewCell

@property (strong, nonatomic) NSDictionary* config;
@property (strong, nonatomic) UILabel* messageLabel;

+ (id) initWithConfig:(NSDictionary *)config reuseIdentifier:(NSString *)identifier;
- (void) setMessageLabelText:(NSString *)message;
@end
/**
 *
 */
@interface ECPopSelector : UIView <UIPickerViewDelegate,UIPickerViewDataSource>

@property (strong, nonatomic) UIPickerView* pickView;
@property (strong, nonatomic) NSArray* configs;
@property BOOL isDone;
@property (strong,nonatomic) UITapGestureRecognizer* doubleTouchToHide;
@property (strong, nonatomic) id<PopSelectorDelegate> selectDelegate;

- (ECPopSelector *) initWithFrame:(CGRect)frame Config:(NSArray *)config;

- (void) pop;
- (void) popWithCurrentRow:(NSInteger)row component:(NSInteger)compnent;
@end

/**
 *
 */
@protocol PopSelectorDelegate <NSObject>
@required
- (void) popSelector:(ECPopSelector *)popSelector didSelectRow:(NSInteger)row inComponent:(NSInteger)component;

@optional
- (void) popSelectorWillPopped:(ECPopSelector *)popSelector;
- (void) popSelectorDidPopped:(ECPopSelector *)popSelector;
- (void) popSelectorWillHidden:(ECPopSelector *)popselector;
- (void) popSelectorDidHidden:(ECPopSelector *)popSelector;
@end

/**
 *
 */
@protocol ECBookListViewDelegate <NSObject>

- (void) bookListView:(ECBookListView *)bookListView didChangedAtRow:(NSInteger)row withContentAtIndex:(NSInteger)index;
- (void) bookListView:(ECBookListView *)bookListView didChangedForItem:(NSString *)item withContent:(NSString *)content;

@end
/**
 *
 */

@interface ECBookListViewUtils : NSObject

+ (CGRect) frameOnRootView:(UIView *)view;
+ (CGRect) frameOnScrollView:(UIView *)view;

+ (UIViewController *) currentViewController:(UIView *)view;
+ (UIViewController *) currentViewController;
@end