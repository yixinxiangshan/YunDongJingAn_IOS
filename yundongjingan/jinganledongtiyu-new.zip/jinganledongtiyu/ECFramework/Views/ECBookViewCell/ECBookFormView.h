//
//  ECBookFormView.h
//  UINavigationControllerDemo
//
//  Created by cww on 13-9-23.
//  Copyright (c) 2013年 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>

#define ROW @"row"
#define COLUM @"colum"
#define ROWLABEL @"rowlabel"
#define COLUMLABEL @"columlabel"

@protocol ECBookFormViewDelegate;

@interface ECBookFormView : UIView <UIScrollViewDelegate>

@property (strong, nonatomic) id<ECBookFormViewDelegate> delegate;

- (void) setStatusLabels:(NSArray *)labelTitles markColor:(NSArray *)markColors;
- (void) setHorizontalLabels:(NSArray *) itemsTitle; //横向 标签
- (void) setVerticalLabels:(NSArray *) itemsTitle;  //纵向 标签

- (void) setStatus:(NSArray *)canBook;
@end

// object extends
@interface ECScrollView : UIScrollView
@property NSInteger subsCount;
@end

@interface ECBookFormItem : UIButton
@property (strong, nonatomic) NSString* horizontalLabel;
@property (strong, nonatomic) NSString* verticalLabel;
@property NSUInteger ID; //低 16 位表示 culum , 高 16 位表示 row
@property (strong, nonatomic) NSString* label;
@property BOOL seclected;
@property (strong, nonatomic) NSDictionary* config;

- (NSUInteger) row;
- (NSUInteger) colum;
@end

// delegate
@protocol ECBookFormViewDelegate <NSObject>

@optional
- (BOOL) bookFormItemSelected:(ECBookFormItem *)item;
- (BOOL) bookFormItemDeselected:(ECBookFormItem *)item;

@end