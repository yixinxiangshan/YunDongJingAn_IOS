//
//  ECBookFormView.m
//  UINavigationControllerDemo
//
//  Created by cww on 13-9-23.
//  Copyright (c) 2013年 ecloud. All rights reserved.
//

#import "ECBookFormView.h"

#define FormItemWidth 55
#define FormItemHeight 30
#define SelfMaxHeight 300

#define LabelTextFont [UIFont systemFontOfSize:13]

#define viewBackground [UIColor colorWithRed:0.93 green:0.94 blue:0.90 alpha:1.00]

#define ECButtonColorDefault [UIColor colorWithRed:0.75 green:0.75 blue:0.75 alpha:1.00]
#define ECButtonColorCanSelect [UIColor colorWithRed:0.74 green:0.87 blue:0.29 alpha:1.00]
#define ECButtonColorSelected [UIColor colorWithRed:0.85 green:0.22 blue:0.19 alpha:1.00]

#define MinimumZoomScale 0.7
#define MaximumZoomScale 1.0

@interface ECBookFormView () 

@property (strong, nonatomic) ECScrollView* statusLabel;
@property (strong, nonatomic) NSMutableArray* horLabels;
@property (strong, nonatomic) NSMutableArray* verLabels;
@property (strong, nonatomic) NSMutableArray* bookItems;

@property (strong, nonatomic) ECScrollView* horHeader;
@property (strong, nonatomic) ECScrollView* verHeader;
@property (strong, nonatomic) UIView* mainView;

@property (strong, nonatomic) NSMutableArray* statusLabelConfigs;

@property (strong, nonatomic) UIColor* itemColorCouldSelect;
@property (strong, nonatomic) UIColor* itemColorSelected;

@property BOOL flag;
typedef struct _ECPosition {
    NSUInteger row;
    NSUInteger colum;
} ECPosition;
@end

@implementation ECBookFormView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
//        self.backgroundView = [[UIView alloc] init];
        [self setBackgroundColor:[UIColor clearColor]];
    }
    return self;
}
- (void) itemSelected:(ECBookFormItem *)sender
{
    sender.seclected = !sender.seclected;
    if (sender.seclected) {
        if ([_delegate respondsToSelector:@selector(bookFormItemSelected:)]) {
            if ([_delegate bookFormItemSelected:sender]) {
                [self setbackGround:sender state:2];
            }
        }
    }else{
        if ([_delegate respondsToSelector:@selector(bookFormItemDeselected:)]) {
            if ([_delegate bookFormItemDeselected:sender]) {
                [self setbackGround:sender state:1];
            };
        }
    }
}
- (void) setStatusLabels:(NSArray *)labelTitles markColor:(NSArray *)markColors
{
    if (!labelTitles && labelTitles.count != 3) {
        labelTitles = [NSArray arrayWithObjects:@"已出售",@"可预订",@"我的预订", nil];
    }
    if (!markColors && markColors.count != 3) {
        markColors = [NSArray arrayWithObjects:ECButtonColorDefault,ECButtonColorCanSelect,ECButtonColorSelected, nil];
    }
    if (!_statusLabelConfigs) {
        _statusLabelConfigs = [NSMutableArray new];
    }
    [_statusLabelConfigs removeAllObjects];
    for (int i = 0; i < 3; i ++) {
        UIColor* color = nil;
        UIImage* image = nil;
        id temp = [markColors objectAtIndex:i];
        if ([temp isKindOfClass:[UIColor class]]) {
            color = temp;
        }else if ([temp isKindOfClass:[UIImage class]]){
            image = temp;
        }else if ([temp isKindOfClass:[NSString class]]){
            image = [UIImage imageNamed:temp];
        }
        if (!color && !image) {
            switch (i) {
                case 1:
                    color = ECButtonColorCanSelect;
                    break;
                case 2:
                    color = ECButtonColorSelected;
                    break;
                default:
                    color = ECButtonColorDefault;
                    break;
            }
        }
        color ?
            [_statusLabelConfigs addObject:[NSDictionary dictionaryWithObjectsAndKeys:[labelTitles objectAtIndex:i],@"title",color,@"color",[NSString stringWithFormat:@"%i",i], @"state", nil]]
        :
            [_statusLabelConfigs addObject:[NSDictionary dictionaryWithObjectsAndKeys:[labelTitles objectAtIndex:i],@"title",image, @"image",[NSString stringWithFormat:@"%i",i], @"state", nil]];
    }
    if (_statusLabel) {
        [_statusLabel removeFromSuperview];
        _statusLabel = nil;
    }
    
    [self initStatusLabel];
}
- (void) setHorizontalLabels:(NSArray *) itemsTitle
{
    
    if (!itemsTitle) {
        itemsTitle = [NSArray arrayWithObjects:@"01",@"02",@"03",@"04",@"05",@"06", nil];
    }
    if (_horHeader) {
        [_horHeader removeFromSuperview];
        _horHeader = nil;
    }
    
    [self initHorHeader:itemsTitle];
    [self initContentView:_verHeader.subsCount colum:_horHeader.subsCount];
}
- (void) setVerticalLabels:(NSArray *) itemsTitle
{
    if (!itemsTitle) {
        itemsTitle = [NSArray arrayWithObjects:@"01",@"02",@"03",@"04",@"05", nil];
    }
    if (_verHeader) {
        [_verHeader removeFromSuperview];
        _verHeader = nil;
    }
    
    [self initVerHeader:itemsTitle];
    [self initContentView:_verHeader.subsCount colum:_horHeader.subsCount];
}
- (void) setStatus:(NSArray *)canBook
{
    if (!canBook || ![canBook isKindOfClass:[NSArray class]]) {
        return;
    }
    ECPosition position ;
    for (NSMutableDictionary* item in canBook) {
        position.row = [item objectForKey:ROW] ?  [[item objectForKey:ROW] integerValue ] : [self locationWith:[item objectForKey:ROWLABEL] in:_verLabels];
        position.colum = [item objectForKey:COLUM] ?  [[item objectForKey:COLUM] integerValue ] : [self locationWith:[item objectForKey:COLUMLABEL] in:_horLabels];
        [self markFormItemCouldSelectedInPosition:position withConfig:item];
    }
}
- (void) markFormItemCouldSelectedInPosition:(ECPosition)position withConfig:(NSDictionary *)config
{
    if (position.row == NSUIntegerMax || position.colum == NSUIntegerMax) {
        return;
    }
    ECBookFormItem* bookItem = (ECBookFormItem *)[_bookItems objectAtIndex:position.row * _horLabels.count + position.colum];
    [self setbackGround:bookItem state:1];
    [bookItem addTarget:self action:@selector(itemSelected:) forControlEvents:UIControlEventTouchUpInside];
    bookItem.config = config;
}
- (NSUInteger) locationWith:(NSString *)label in:(NSArray *)labels
{
    for (UILabel* temp in labels) {
        if ([temp.text isEqualToString:label]) {
            return temp.tag;
        }
    }
    return NSUIntegerMax;
}
- (void) resizeHeader
{
    if (_flag) {
        _flag = NO;
        return;
    }
    _flag = YES;
    [_horHeader setContentSize:CGSizeMake(_mainView.frame.size.width, 00)];
    [_verHeader setContentSize:CGSizeMake(30, _mainView.frame.size.height)];
    
    CGFloat horItemWidth = _mainView.frame.size.width / _horLabels.count;
    CGFloat horItemLocation = 0;
    CGFloat verItemHeight = _mainView.frame.size.height / _verLabels.count;
    CGFloat verItemLocation = 0;
    
    for (int i = 0; i < _horLabels.count; i ++) {
        if (!_flag) {
            NSLog(@"break");
            break;
        }
        [(UILabel*)[_horLabels objectAtIndex:i] setFrame:CGRectMake(horItemLocation, 0, horItemWidth, 22)];
        horItemLocation += horItemWidth;
    }
    for (int i = 0; i < _verLabels.count; i ++) {
        if (!_flag) {
            NSLog(@"break");
            break;
        }
        [(UILabel *)[_verLabels objectAtIndex:i] setFrame:CGRectMake(0, verItemLocation, 30, verItemHeight)];
        verItemLocation += verItemHeight;
    }
    if (!_flag) {
        [self resizeHeader];
    }
    _flag = NO;
}
#pragma 

- (void) initContentView:(NSInteger)row colum:(NSInteger)colum
{
    if (!row || !colum) {
        return;
    }
    _mainView = [[UIView alloc] initWithFrame:CGRectMake(30, 66, _horHeader.frame.size.width, _verHeader.frame.size.height)];
    UIScrollView*  formView = [[ECScrollView alloc] initWithFrame:_mainView.frame];
    [formView setBackgroundColor:[UIColor whiteColor]];
    formView.showsHorizontalScrollIndicator = NO;
    formView.showsVerticalScrollIndicator = NO;
    formView.minimumZoomScale = MinimumZoomScale;
    formView.maximumZoomScale = MaximumZoomScale;
    formView.delegate = self;
    
    _bookItems = [NSMutableArray new];
    
    for (int i = 0; i < row; i ++) {
        for (int j = 0; j < colum; j ++) {
            ECBookFormItem* button = [[ECBookFormItem alloc] initWithFrame:CGRectMake(5 + ( FormItemWidth + 10) * j, 3 + ( FormItemHeight + 6 ) * i, FormItemWidth, FormItemHeight)];
            [self setbackGround:button state:0];
            button.verticalLabel = ((UILabel *)[_verLabels objectAtIndex:i]).text;
            button.horizontalLabel = ((UILabel *)[_horLabels objectAtIndex:j]).text;
            button.ID = (i << 16 ) + ( j & 0xffff );
            
            [_mainView addSubview:button];
            [_bookItems addObject:button];
        }
    }
    [_mainView setFrame:CGRectMake(0, 0, _horHeader.contentSize.width, _verHeader.contentSize.height)];
    [formView addSubview:_mainView];
    [formView setContentSize:CGSizeMake(_horHeader.contentSize.width, _verHeader.contentSize.height)];
    
    [self addSubview:formView];
    //frame 错误，应为 formView与statusLabel 的高度之和
//    [self setFrame:CGRectMake(0, 0, self.frame.size.width, 70 + _mainView.frame.size.height)];
    // 修正 frame 错误，by cww
    [self setFrame:CGRectMake(0, 0, self.frame.size.width,  70 + formView.frame.size.height)];
}

- (void) initVerHeader:(NSArray *)configs
{
    _verHeader = [[ECScrollView alloc] initWithFrame:CGRectMake(0, 66, 30, SelfMaxHeight - 66 < (FormItemHeight + 6) * configs.count ? SelfMaxHeight -66 : (FormItemHeight + 6) * configs.count)];
    [_verHeader setUserInteractionEnabled:NO];
    [_verHeader setBackgroundColor:[UIColor clearColor]];
    _verHeader.subsCount = configs.count;
    
    _verLabels = [NSMutableArray new];
    
    CGFloat verHeaherHeight = 3;
    NSInteger row = 0;
    while (row < configs.count) {
        UILabel* label = [[UILabel alloc] initWithFrame:CGRectMake(0, verHeaherHeight, 29, FormItemHeight)];
        [label setBackgroundColor:[UIColor clearColor]];
        [label setFont:LabelTextFont];
        label.textAlignment = NSTextAlignmentCenter;
        label.tag = row;
        
        [label setText:[configs objectAtIndex:row++]];
        [_verHeader addSubview:label];
        [_verLabels addObject:label];
        
        verHeaherHeight = 3 + (FormItemHeight + 6) * row;
    }
    UIView* devider = [[UIView alloc] initWithFrame:CGRectMake(29, 0, 1, configs.count * (FormItemHeight + 6))];
    [devider setBackgroundColor:[UIColor lightGrayColor]];
    [_verHeader addSubview:devider];
    
    [_verHeader setContentSize:CGSizeMake(30, configs.count * (FormItemHeight + 6))];
    [self addSubview:_verHeader];
}

- (void) initHorHeader:(NSArray *)configs
{
    _horHeader = [[ECScrollView alloc] initWithFrame:CGRectMake(30, 44, self.frame.size.width - 30, 22)];
    [_horHeader setUserInteractionEnabled:NO];
    [_horHeader setBackgroundColor:[UIColor clearColor]];
    _horHeader.subsCount = configs.count;
    
    _horLabels = [NSMutableArray new];
    CGFloat itemCenter = 5 + FormItemWidth / 2;
    NSInteger row = 0;
    while (row < configs.count)  {
        
        UILabel* label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, FormItemWidth, 22)];
        [label setBackgroundColor:[UIColor clearColor]];
        [label setFont:LabelTextFont];
        label.textAlignment = NSTextAlignmentCenter;
        label.tag = row;
        [label setText:[configs objectAtIndex:row++]];
        [label sizeToFit];
        [label setFrame:CGRectMake(itemCenter - label.frame.size.width / 2, 0, label.frame.size.width, 22)];
        [_horHeader addSubview:label];
        [_horLabels addObject:label];
        
        itemCenter += 10 + FormItemWidth;
    }
    [_horHeader setContentSize:CGSizeMake(itemCenter - 5 - FormItemWidth / 2, 22)];
    [self addSubview:_horHeader];
}
#pragma statu label
- (void)initStatusLabel
{
    if (!_statusLabelConfigs) {
        return;
    }
    NSMutableArray* statusLabels = [NSMutableArray new];
    NSInteger statusLabelWidth = 0 ;
    for (NSDictionary* item in _statusLabelConfigs) {
        UIView* statusLabel = [self statusLabelWithConfig:item];
        [statusLabels addObject:statusLabel];
        statusLabelWidth += statusLabel.frame.size.width;
    }
    
    UIScrollView* statusLabel = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 10, self.frame.size.width, 22)];
    
    CGFloat distance = (self.frame.size.width - statusLabelWidth) / (statusLabels.count + 1);
    distance = distance <= 10 ? 10 : distance;
    
    CGFloat ofSetY = distance;
    for (UIView* item in statusLabels ) {
        [item setFrame:CGRectMake(ofSetY, 0, item.frame.size.width, 22)];
        [statusLabel addSubview:item];
        ofSetY += distance + item.frame.size.width;
    }
    if (ofSetY > self.frame.size.width) {
        [statusLabel setContentSize:CGSizeMake(ofSetY, 00)];
    }
    [self addSubview:statusLabel];
}
- (UIView *) statusLabelWithConfig:(NSDictionary *)config
{
    UIView* statusLabel = [[UIView alloc] init];
    
    UILabel* titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 3, 66, 22)];
    [titleLabel setBackgroundColor:viewBackground];
    [titleLabel setFont:[UIFont systemFontOfSize:13]];
    [titleLabel setText:[config objectForKey:@"title"]];
    [titleLabel sizeToFit];
    [statusLabel addSubview:titleLabel];
    
    UIView* colorCard = [[UIView alloc] initWithFrame:CGRectMake(titleLabel.frame.size.width + 3, 0, 33, 22)];
    [self setbackGround:colorCard state:[[config valueForKey:@"state"] integerValue]];
    [statusLabel addSubview:colorCard];
    
    [statusLabel setFrame:CGRectMake(0, 0, titleLabel.frame.size.width + colorCard.frame.size.width, 22)];
    return statusLabel;
}

#pragma setBackground util
- (void) setbackGround:(UIView *)view state:(NSInteger)state
{
    UIColor* tempColor = [[_statusLabelConfigs objectAtIndex:state] objectForKey:@"color"];
    UIImage* tempImage = [self reSizeImage:[[_statusLabelConfigs objectAtIndex:state] objectForKey:@"image"] toSize:CGSizeMake(view.frame.size.width, view.frame.size.height)];
    if (tempColor) {
        [view setBackgroundColor:tempColor];
    }else if (tempImage){
        [view setBackgroundColor:[UIColor colorWithPatternImage:tempImage]];
    }
}
- (UIImage *)reSizeImage:(UIImage *)image toSize:(CGSize)reSize
{
    UIGraphicsBeginImageContext(CGSizeMake(reSize.width, reSize.height));
    [image drawInRect:CGRectMake(0, 0, reSize.width, reSize.height)];
    UIImage *reSizeImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return reSizeImage;
}
#pragma UIScrollView delegate
- (void) scrollViewDidScroll:(UIScrollView *)scrollView
{
    [_horHeader setContentOffset:CGPointMake(scrollView.contentOffset.x, 0)];
    [_verHeader setContentOffset:CGPointMake(0, scrollView.contentOffset.y)];
}
- (UIView *) viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return _mainView;
}
- (void) scrollViewDidZoom:(UIScrollView *)scrollView
{
    [self resizeHeader];
}

@end

@implementation ECScrollView

@end
@implementation ECBookFormItem
- (NSUInteger) row
{
    return ( self.ID - self.colum ) >> 16 ;
}
-(NSUInteger) colum
{
    return self.ID & 0xffff;
}
@end