//
//  ECDateSelector.m
//  jinganledongtiyu
//
//  Created by cheng on 13-10-8.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECDateSelector.h"
#import "KxMenu.h"

#define DefaultStartDate [NSDate date]
#define DefaultEndDate  [NSDate dateWithTimeIntervalSinceNow:7*24*3600]

@interface ECDateSelector ()

@property (strong, nonatomic) UILabel* dateLabel;
@property (strong, nonatomic) UIImageView* rightImageView;

@property (strong, nonatomic) NSMutableArray* dateItems;
@end

@implementation ECDateSelector

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
//        self.backgroundView = [[UIView alloc] init];
        [self setBackgroundColor:[UIColor colorWithRed:0.83 green:0.83 blue:0.83 alpha:1.00]];
        UIView* sepratorLine = [[UIView alloc] initWithFrame:CGRectMake(0, self.frame.size.height, self.frame.size.width, 1)];
        [sepratorLine setBackgroundColor:[UIColor colorWithRed:0.65 green:0.65 blue:0.65 alpha:1.00]];
        [self addSubview:sepratorLine];
        self.startDate = DefaultStartDate;
        self.endDate = DefaultEndDate;
        [self updateDateLabel];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void) initPopView
{
    NSInteger days = [self numberOfDaysBetweenStartDate:self.startDate andEndDate:self.endDate];
    self.dateItems = self.dateItems ? self.dateItems : [NSMutableArray new];
    for (int i = 0; i < days; i ++) {
        KxMenuItem* item = [KxMenuItem menuItem:[self formatStringForDate:[NSDate dateWithTimeIntervalSinceNow:86400 * i]]
                                          image:nil
                                         target:self
                                          param:nil
                                         action:@selector(dateSelected:)];
        item.tag = i;
        [self.dateItems addObject:item];
    }
}
- (void) setStartDate:(NSDate *)startDate endDate:(NSDate *)endDate
{
    self.startDate = startDate ? startDate : DefaultStartDate;
    self.endDate = endDate ? endDate : DefaultEndDate;
    
    self.result = self.startDate;
    [self initPopView];
}
- (void) popSelector
{
    if (!self.dateItems) {
        [self initPopView];
    }
    [KxMenu showMenuInView:[self superview] fromRect:self.frame menuItems:self.dateItems];
}
- (void) dateSelected:(KxMenuItem *)sender
{
    self.result = [ NSDate dateWithTimeIntervalSinceNow:86400 * sender.tag];
    [self updateDateLabel];
    if ([self.delegate respondsToSelector:@selector(dateSelector:didSelectedDate:)]) {
        [self.delegate dateSelector:self didSelectedDate:self.result];
    }
}
//update view
- (void) updateDateLabel
{
    if (!self.dateLabel) {
        self.dateLabel = [[UILabel alloc] init];
        [self.dateLabel setBackgroundColor:[UIColor clearColor]];
        [self.dateLabel setFont:[UIFont systemFontOfSize:15]];
        self.rightImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"drop.png"]];
        
        UITapGestureRecognizer* gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(popSelector)];
        [self addGestureRecognizer:gestureRecognizer];
        
        [self addSubview:self.dateLabel];
        [self addSubview:self.rightImageView];
    }
    self.dateLabel.text = [self dateLabelText];
    [self.dateLabel sizeToFit];
    // resize view
    [self.dateLabel setFrame:CGRectMake((self.frame.size.width - self.dateLabel.frame.size.width - self.rightImageView.frame.size.width)/2 - 1, (self.frame.size.height - self.dateLabel.frame.size.height)/2, self.dateLabel.frame.size.width, self.dateLabel.frame.size.height)];
    [self.rightImageView setFrame:CGRectMake(self.dateLabel.frame.origin.x + self.dateLabel.frame.size.width + 2, (self.frame.size.height - self.rightImageView.frame.size.height)/2, self.rightImageView.frame.size.width, self.rightImageView.frame.size.height)];
}
// date utils
- (NSString *) dateLabelText
{
    self.result = self.result ? self.result : DefaultStartDate;
    return [NSString stringWithFormat:@"%@ 周%@",[self stringFromDate:self.result],[self weekDayWithDate:self.result]];
}
- (NSString *) formatStringForDate:(NSDate *)date
{
    return [NSString stringWithFormat:@"%@ 周%@",[self stringFromDate:date],[self weekDayWithDate:date]];
}
- (NSDate *)dateFromString:(NSString *)dateString{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat: @"yyyy-MM-dd HH:mm:ss"];
    NSDate *destDate= [dateFormatter dateFromString:dateString];
    return destDate;
}
- (NSString *)stringFromDate:(NSDate *)date{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //zzz表示时区，zzz可以删除，这样返回的日期字符将不包含时区信息。
    [dateFormatter setDateFormat: @"MM月dd日 "];
    NSString *destDateString = [dateFormatter stringFromDate:date];
    return destDateString;
}
- (NSString *) weekDayWithDate:(NSDate *)date{
    NSCalendar *gregorian = [NSCalendar currentCalendar];
    NSDateComponents *weekDayComponents = [gregorian components:NSWeekdayCalendarUnit fromDate:date];
    NSInteger mDay = [weekDayComponents weekday];
    NSString *week=@"";
    switch (mDay) {
        case 0:{
            week=@"日";
            break;
        }
        case 1:{
            week=@"日";
            break;
        }
        case 2:{
            week=@"一";
            break;
        }
        case 3:{
            week=@"二";
            break;
        }
        case 4:{
            week=@"三";
            break;
        }
        case 5:{
            week=@"四";
            break;
        }
        case 6:{
            week=@"五";
            break;
        }
        case 7:{
            week=@"六";
            break;
        }
        default:{
            break;
        }
    };
    return week;
}
- (NSInteger) numberOfDaysBetweenStartDate:(NSDate *)startDate andEndDate:(NSDate *)endDate
{
    NSTimeInterval startDiff = [startDate timeIntervalSince1970];
    NSTimeInterval endDiff = [endDate timeIntervalSince1970];
    NSTimeInterval dateDiff = endDiff - startDiff;
    
    return (NSInteger)(dateDiff / 86400);
}
@end
