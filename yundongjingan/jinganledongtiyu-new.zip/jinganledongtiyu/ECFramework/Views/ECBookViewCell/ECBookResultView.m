//
//  ECBookResultView.m
//  jinganledongtiyu
//
//  Created by cheng on 13-10-9.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import "ECBookResultView.h"
#import "UIViewExtends.h"
#import "NSStringExtends.h"

@interface ECBookResultView ()
@property (strong, nonatomic) ECBookResultSummaryView* summaryView;
@end

@implementation ECBookResultView

- (id) initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setBackgroundColor:[UIColor clearColor]];
        _subViewLabels = [NSMutableArray new];
        _summaryView = [[ECBookResultSummaryView alloc] init];
        [_summaryView setBackgroundColor:[UIColor clearColor]];
        _labelAlignment = 0;
        [self updateSummaryView];
    }
    return self;
}
- (void) subViewWithLabel:(NSString *)labelText price:(CGFloat)price
{
    [self subViewWithLabel:labelText isAdd:YES price:price];
}
- (void) subViewWithLabel:(NSString *)labelText isAdd:(BOOL)isAdd price:(CGFloat)price
{
    ECBookResultViewItem* label = [[ECBookResultViewItem alloc] init];
    [label setTitle:labelText];
    label.price = price;
    
    if (!isAdd) {
        [_subViewLabels removeAllObjects];
    }
    [_subViewLabels addObject:label];
    [self updateSummaryView];
}
- (void) removeSubViewWithLabel:(NSString *)labelText
{
    NSString* labelTextTemp = [NSAttributedString attributedStringWithHtmlString:labelText defaultFont:nil].string;
    for (ECBookResultViewItem* label in _subViewLabels) {
        if ([label.text isEqualToString:labelTextTemp]) {
            [_subViewLabels removeObject:label];
            break;
        }
    }
    [self updateSummaryView];
}
- (void) subViewWithLabel:(NSString *)labelText tag:(NSInteger)tag
{
    ECBookResultViewItem* label = [[ECBookResultViewItem alloc] init];
    [label setTitle:labelText];
    label.tag = tag;
    [_subViewLabels addObject:label];
    [self updateSummaryView];
}
- (void) removeSubViewWithTag:(NSInteger)tag
{
    for (ECBookResultViewItem* label in _subViewLabels) {
        if (label.tag == tag) {
            [_subViewLabels removeObject:label];
            break;
        }
    }
    [self updateSummaryView];
}
- (void) updateSubViewWithConfig:(NSArray *)config
{
    self.labelAlignment = 1;
    [_subViewLabels removeAllObjects];
    for (NSString* labelText in config) {
        [self subViewWithLabel:labelText tag:0];
    }
}
- (void) updateSubViews
{
    [self removeAllSubViews];
    CGFloat height = 0;
    CGFloat width = self.frame.size.width/2;
    CGFloat labelHeight = 26;
    BOOL left = YES;
    for (ECBookResultViewItem * label in _subViewLabels) {
        [label setBackgroundColor:[UIColor clearColor]];
        [label setFont:[UIFont systemFontOfSize:13]];
        [label sizeToFit];
        switch (self.labelAlignment) {
            case 3:     //middle
                [label setFrame:CGRectMake(width-10 - label.frame.size.width/2, height, label.frame.size.width, labelHeight)];
                height += labelHeight;
                break;
            case 1: //left
                [label setFrame:CGRectMake(10, height, label.frame.size.width, labelHeight)];
                height += labelHeight;
                break;
            case 2:     //right
                [label setFrame:CGRectMake(width*2-20 - label.frame.size.width, height, label.frame.size.width, labelHeight)];
                height += labelHeight;
                break;
            default:    // free
                if (label.frame.size.width < width-10 && _subViewLabels.count != 1) {
                    [label setFrame:CGRectMake(width * !left + (width - label.frame.size.width)/2 + 10, height, width - 10, labelHeight)];
                    height += labelHeight * !left;
                    left = !left;
                }else{
                    if (!left) {
                        height += labelHeight * !left;
                        left = !left;
                    }
                    [label setFrame:CGRectMake((width*2 - label.frame.size.width)/2 + 10, height, width*2-20, labelHeight)];
                    height += labelHeight;
                }
                break;
        }
                [self addSubview:label];
    }
    if (!left) {
        height += labelHeight * !left;
        left = !left;
    }
    [_summaryView setFrame:CGRectMake((width*2 - _summaryView.frame.size.width)/2 , height, _summaryView.frame.size.width, 44)];
    [self addSubview:_summaryView];
    [self setFrame:CGRectMake(0, 0, self.frame.size.width, height + 55)];
    UIView* sepratorLine = [[UIView alloc] initWithFrame:CGRectMake(0, self.frame.size.height - 11, self.frame.size.width, 1)];
    [sepratorLine setBackgroundColor:[UIColor colorWithRed:0.87 green:0.87 blue:0.85 alpha:1.00]];
    [self addSubview:sepratorLine];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ECBookViewController.reloadSubViews" object:nil];
}
- (void) updateSummaryView
{
    if (_oldSummary) {
        _summaryView.summary = [NSAttributedString attributedStringWithHtmlString:[NSString stringWithFormat:@"总计：<font color = \"#FF0000\" size = \"15\">%.2f元</font><font color = \"black\" size = \"15\">/</font>",_summary] defaultFont:[UIFont systemFontOfSize:13]];
        _summaryView.oldSummary = [NSAttributedString attributedStringWithHtmlString:[NSString stringWithFormat:@"<font color = \"gray\" size = \"13\">%0.2f元</font>",_oldSummary] defaultFont:[UIFont systemFontOfSize:13]];
    }else{
        _summaryView.summary = [NSAttributedString attributedStringWithHtmlString:[NSString stringWithFormat:@"总计：<font color = \"#FF0000\" size = \"15\">%.2f元</font>",_summary] defaultFont:[UIFont systemFontOfSize:13]];
    }
    
    [_summaryView sizeToFit];
    [self updateSubViews];
}
- (CGFloat) totalPrice
{
    CGFloat totalPrice = 0;
    for (ECBookResultViewItem* item in _subViewLabels) {
        totalPrice += item.price;
    }
    _summary =totalPrice;
    return totalPrice;
}
- (void) setSummary:(CGFloat)summary
{
    _summary = summary;
    [self updateSummaryView];
}
- (void) setOldSummary:(CGFloat)oldSummary
{
    _oldSummary = oldSummary;
    [self updateSummaryView];
}
@end
@implementation ECBookResultViewItem
- (void) setTitle:(NSString *)title
{
    _title = title;
    self.attributedText = [NSAttributedString attributedStringWithHtmlString:_title defaultFont:self.font];
}
@end

#import "StrikeThroughLabel.h"
@interface ECBookResultSummaryView ()
@property (strong, nonatomic) UILabel* summaryLabel;
@property (strong, nonatomic) StrikeThroughLabel* oldSummaryLabel;
@end

@implementation ECBookResultSummaryView

- (id) init
{
    self = [super init];
    if (self) {
        _summaryLabel = [[UILabel alloc] init];
        [_summaryLabel setBackgroundColor:[UIColor clearColor]];
        
        _oldSummaryLabel = [[StrikeThroughLabel alloc] init];
        [_oldSummaryLabel setBackgroundColor:[UIColor clearColor]];
        _oldSummaryLabel.strikeThroughEnabled = YES;
        
        [self addSubview:_summaryLabel];
        [self addSubview:_oldSummaryLabel];
        
        [self setBackgroundColor:[UIColor whiteColor]];
    }
    return self;
}

- (void) setSummary:(NSAttributedString *)summary
{
    _summary = summary;
    _summaryLabel.attributedText = _summary;
}
- (void) setOldSummary:(NSAttributedString *)oldSummary
{
    _oldSummary = oldSummary;
    _oldSummaryLabel.attributedText = _oldSummary;
}

#pragma mark- override
- (void) sizeToFit
{
    [_summaryLabel sizeToFit];
    [_oldSummaryLabel sizeToFit];
    
    CGFloat height = _oldSummaryLabel.frame.size.height > _summaryLabel.frame.size.height ? _oldSummaryLabel.frame.size.height : _summaryLabel.frame.size.height;
    [self setFrame:CGRectMake(0, 0, _oldSummaryLabel.frame.size.width+_summaryLabel.frame.size.width, height)];
    
    [_summaryLabel setFrame:CGRectMake(0, self.frame.size.height - _summaryLabel.frame.size.height, _summaryLabel.frame.size.width, _summaryLabel.frame.size.height)];
    [_oldSummaryLabel setFrame:CGRectMake(_summaryLabel.frame.size.width, self.frame.size.height - _oldSummaryLabel.frame.size.height, _oldSummaryLabel.frame.size.width, _oldSummaryLabel.frame.size.height)];
}
@end