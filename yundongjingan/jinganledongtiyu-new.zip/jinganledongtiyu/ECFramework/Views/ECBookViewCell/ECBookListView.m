//
//  ECBookListView.m
//  UINavigationControllerDemo
//
//  Created by cheng on 13-9-24.
//  Copyright (c) 2013年 ecloud. All rights reserved.
//

#import "ECBookListView.h"
#import <QuartzCore/QuartzCore.h>
#import "DisplayUtil.h"
#import "Toast+UIView.h"

#define ViewBG [UIColor colorWithRed:0.93 green:0.94 blue:0.90 alpha:1.00]

#define MainSelectorCellBackground [UIColor whiteColor]

#define PopSelectorCellHeight 44.0
#define PopSelectorHeight 224.0
#define PopSelectorBasePosition [UIScreen mainScreen].bounds.size.height
#define MainSelectorCellHeight 44.0
#define AnimationDuration 0.2

@interface ECBookListView () <UITableViewDataSource,UITableViewDelegate,PopSelectorDelegate>

@property (strong, nonatomic) ECPopSelector* popSelector;

@property (strong, nonatomic) NSMutableDictionary* mainSelectoerCellQueue;

@property CGFloat translateDistance;
@property CGFloat maxHeight;
@end
@implementation ECBookListView

- (id)initWithSuperView:(UIView *)superView frame:(CGRect)frame configs:(NSArray *)configs
{
    self.maxHeight = [[ECBookListViewUtils currentViewController:superView] navigationController] && ![[ECBookListViewUtils currentViewController:superView] navigationController].navigationBarHidden ? PopSelectorBasePosition - PopSelectorHeight - 84 : PopSelectorBasePosition - PopSelectorHeight - 40;
    self = [super initWithFrame:CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, (self.maxHeight < MainSelectorCellHeight * configs.count + 20 ? self.maxHeight : MainSelectorCellHeight * configs.count) + 20) style:UITableViewStyleGrouped];
    if (self) {
        UIView* viewBG = [[UIView alloc] init];
        [viewBG setBackgroundColor:[UIColor clearColor]];
        if (IOS7_OR_LATER) {
            self.separatorInset = UIEdgeInsetsZero;
        }
//        [self setBackgroundColor:ViewBG];
        self.backgroundView = viewBG;
        _configs = configs;
        self.dataSource = self;
        self.delegate = self;
    }
    return self;
}
- (void) popSelector:(NSArray *)config withCurrent:(NSInteger)row
{
    if (!_popSelector) {
        _popSelector = [[ECPopSelector alloc] initWithFrame:(CGRect)self.frame Config:config];
        _popSelector.selectDelegate = self;
    }
    [_popSelector setConfigs:config];
    [_popSelector popWithCurrentRow:row component:0];
}
- (void) didChangedAtRow:(NSInteger)row withContentAtIndex:(NSInteger)index
{
    // delegate method one
    if ([self.bookDelegate respondsToSelector:@selector(bookListView:didChangedAtRow:withContentAtIndex:)]) {
        [self.bookDelegate bookListView:self didChangedAtRow:row withContentAtIndex:index];
    }
    // delegate method two
    if ([self.bookDelegate respondsToSelector:@selector(bookListView:didChangedForItem:withContent:)]) {
        ECBookListViewCell* cell = (ECBookListViewCell *)[self cellForRowAtIndexPath:[self indexPathForSelectedRow]];
        [self.bookDelegate bookListView:self didChangedForItem:cell.textLabel.text withContent:cell.messageLabel.text];
    }
}
- (void) setConfigs:(NSArray *)configs
{
    _configs = configs;
    [self reloadData];
    [self setFrame:CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, (self.maxHeight < MainSelectorCellHeight * configs.count ? self.maxHeight : MainSelectorCellHeight * configs.count) + 20)];
    // 默认选项
    for (int i = 0; i < configs.count; i ++) {
        [self didChangedAtRow:i withContentAtIndex:0];
    }
}
- (void) locationToFit
{
    CGRect frame = [ECBookListViewUtils frameOnRootView:self];
    _translateDistance = frame.origin.y + self.frame.size.height - ([UIScreen mainScreen].bounds.size.height - PopSelectorHeight);
    if (_translateDistance > 0) {
        [self translate:-_translateDistance];
    }
}
- (void) translate:(CGFloat)distance
{
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:AnimationDuration];
    CGAffineTransform moveTransform = CGAffineTransformMakeTranslation(0, distance);
    [self.layer setAffineTransform:moveTransform];
    [UIView commitAnimations];
}
#pragma UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _configs.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return MainSelectorCellHeight;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString* identifier = [NSString stringWithFormat:@"cell%i%i",indexPath.section,indexPath.row];
    if (!_mainSelectoerCellQueue) {
        _mainSelectoerCellQueue = [NSMutableDictionary new];
    }
    ECBookListViewCell *cell = [_mainSelectoerCellQueue objectForKey:identifier];
    if (!cell) {
        cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [ECBookListViewCell initWithConfig:[_configs objectAtIndex:indexPath.row] reuseIdentifier:identifier];
            [_mainSelectoerCellQueue setObject:cell forKey:identifier];
        }
    }
    [cell setConfig:[_configs objectAtIndex:indexPath.row]];
    return cell;
}
#pragma UITableViewDelegate
- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ECBookListViewCell* cell = (ECBookListViewCell *)[self cellForRowAtIndexPath:indexPath];
    
    [self popSelector:[cell.config objectForKey:ItemMessage] withCurrent:cell.tag];
}
#pragma PopSelectDelegate
- (void) popSelector:(ECPopSelector *)popSelector didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    ECBookListViewCell* cell = (ECBookListViewCell *)[self cellForRowAtIndexPath:[self indexPathForSelectedRow]];
    [cell setMessageLabelText:[[cell.config objectForKey:ItemMessage] objectAtIndex:row]] ;
    cell.tag = row;
    [self didChangedAtRow:[self indexPathForSelectedRow].row withContentAtIndex:row];
}
//调整位置
- (void) popSelectorWillPopped:(ECPopSelector *)popSelector
{
    [self locationToFit];
}
- (void) popSelectorWillHidden:(ECPopSelector *)popSelector
{
    [self translate:0.0];
}
@end

@implementation ECBookListViewCell

+ (id) initWithConfig:(NSDictionary *)config reuseIdentifier:(NSString *)identifier
{
    ECBookListViewCell* cell = [[ECBookListViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    [cell setFrame:CGRectMake(cell.frame.origin.x, cell.frame.origin.y, cell.frame.size.width, MainSelectorCellHeight)];
    cell.config = config;
    [cell initView];
    return cell;
}
- (void) setConfig:(NSDictionary *)config
{
    _config = config;
    [self initView];
}
- (void) initView
{
    self.textLabel.text = [_config objectForKey:ItemName];
    
    if (!self.messageLabel) {
        self.messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(130, 10, 0, MainSelectorCellHeight-20)];
        [self.messageLabel setBackgroundColor:[UIColor clearColor]];
        [self.messageLabel setFont:[UIFont systemFontOfSize:13]];
        [self.messageLabel setTextColor:[UIColor blueColor]];
        [self addSubview:self.messageLabel];
        self.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    }
    
    [self setMessageLabelText:[[_config objectForKey:ItemMessage] firstObject]];
}
- (void) setMessageLabelText:(NSString *)message
{
    self.messageLabel.text = message;
    [self.messageLabel sizeToFit];
    [self.messageLabel setFrame:CGRectMake(130, 10, self.messageLabel.frame.size.width, MainSelectorCellHeight-20)];
}
@end

@interface ECPopSelector ()

@property (nonatomic) BOOL isNeedHidden;
@end
@implementation ECPopSelector

- (ECPopSelector *) initWithFrame:(CGRect)frame Config:(NSArray *)config
{
    self = [super initWithFrame:CGRectMake(frame.origin.x, [[[ECBookListViewUtils currentViewController] view] frame].size.height, frame.size.width, PopSelectorHeight)];
    self.pickView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 44, self.frame.size.width, self.frame.size.height - 44)];
//    [self.pickView setBackgroundColor:[UIColor redColor]];
    self.configs = config;
    self.pickView.showsSelectionIndicator = YES;
    self.pickView.dataSource = self;
    self.pickView.delegate = self;
    
    [self addSubview:self.pickView];
    
//    if (!self.doubleTouchToHide) {
//        self.doubleTouchToHide = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hide)];
//        self.doubleTouchToHide.numberOfTapsRequired = 1;
//        [self addGestureRecognizer:self.doubleTouchToHide];
//    }
    //    [bar setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"picker_bg.png"]]];
    
    
    UIToolbar* bar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, 44)];
    bar.barStyle = UIBarButtonItemStyleBordered;
    UIBarButtonItem* barItemActive = [[UIBarButtonItem alloc] initWithTitle:@"确定" style:UIBarButtonItemStyleBordered target:self action:@selector(hide)];
    
    //创建一个空格 ，加入到array，用来将下面加入的按钮按照右边对齐
    UIBarButtonItem   *SpaceButton=[[UIBarButtonItem alloc]  initWithBarButtonSystemItem: UIBarButtonSystemItemFlexibleSpace     target:nil   action:nil];
    UIBarButtonItem* barItemCancel = [[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStyleBordered target:self action:@selector(hide)];
    
    
    NSArray* array = @[barItemCancel,SpaceButton,barItemActive];
    [bar setItems:array];
    [bar sizeToFit];
    
    if (IOS7_OR_LATER) {
        self.backgroundColor = [UIColor whiteColor];
        bar.barTintColor = [UIColor whiteColor];
    }else{
        barItemActive.tintColor = [UIColor colorWithRed:0.40 green:0.64 blue:0.78 alpha:0.3];
        barItemCancel.tintColor = [UIColor colorWithRed:0.40 green:0.64 blue:0.78 alpha:0.3];
    }
    
    [self addSubview:bar];

    
    

    return self;
}
- (void) pop
{
    
    [self popWithCurrentRow:0 component:0];
}
- (void) popWithCurrentRow:(NSInteger)row component:(NSInteger)compnent
{
    
    [self.pickView reloadAllComponents];
    [self.pickView selectRow:row inComponent:compnent animated:YES];
    [self pickerView:self.pickView didSelectRow:row inComponent:compnent];
    if ([self superview]) {
        return;
    }
    [[[ECBookListViewUtils currentViewController] view] addSubview:self];
    
    [self translate:-PopSelectorHeight willStartSelector:@selector(willPopped) didStopSelector:@selector(didPopped)];
}
- (void) willPopped
{
    if ([self.selectDelegate respondsToSelector:@selector(popSelectorWillPopped:)]) {
        [self.selectDelegate popSelectorWillPopped:self];
    }
}
- (void) didPopped
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(nScreenTouch:) name:[DisplayUtil slippingName:UIEventslippingDown] object:nil];
//    [self makeToast:@"快速下滑以隐藏"];
    if ([self.selectDelegate respondsToSelector:@selector(popSelectorDidPopped:)]) {
        [self.selectDelegate popSelectorDidPopped:self];
    }
}
- (void) hide
{
    [self hide:YES];
}
- (void) hide:(BOOL)done
{
    [self translate:0.0 willStartSelector:@selector(willHidden) didStopSelector:@selector(didHidden)];
    _isDone = done;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (void) willHidden
{
    if ([self.selectDelegate respondsToSelector:@selector(popSelectorWillHidden:)]) {
        [self.selectDelegate popSelectorWillHidden:self];
    }
}
- (void) didHidden
{
    [self removeFromSuperview];
    if (_isDone) {
        if ([self.selectDelegate respondsToSelector:@selector(popSelectorDidHidden:)]) {
            [self.selectDelegate popSelectorDidHidden:self];
        }
        return;
    }
    [self pop];
}
- (void) translate:(NSInteger)distance willStartSelector:(SEL)willStart didStopSelector:(SEL)didStop
{
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:AnimationDuration];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationWillStartSelector:willStart];
    [UIView setAnimationDidStopSelector:didStop];
    CGAffineTransform moveTransform = CGAffineTransformMakeTranslation(0, distance);
    [self.layer setAffineTransform:moveTransform];
    [UIView commitAnimations];
}
#pragma UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return self.configs.count;
}
#pragma UIPickerViewDelegate
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return (NSString *)[self.configs objectAtIndex:row];
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if ([self.selectDelegate respondsToSelector:@selector(popSelector:didSelectRow:inComponent:)]) {
        [self.selectDelegate popSelector:self didSelectRow:row inComponent:component];
    }
}
- (void) nScreenTouch:(NSNotification *)noti
{
    [self hide];
}
@end

@implementation ECBookListViewUtils

+ (CGRect) frameOnRootView:(UIView *)view
{
    CGRect frame = view.frame;
    CGRect superViewFrame;
    
    if ([view superview]) {
        if ([[view superview] isKindOfClass:[UIScrollView class]]) {
            frame = [ECBookListViewUtils frameOnScrollView:view];
        }
        superViewFrame = [ECBookListViewUtils frameOnRootView:[view superview]];
    }
    
    frame.origin.x += superViewFrame.origin.x;
    frame.origin.y += superViewFrame.origin.y;
    
    return frame;
}
+ (CGRect) frameOnScrollView:(UIView *)view
{
    CGRect frame = view.frame;
    UIScrollView* scrollView = (UIScrollView*)[view superview];
    frame.origin.x += scrollView.contentOffset.x;
    frame.origin.y += scrollView.contentOffset.y;
    
    return frame;
}
+ (UIViewController *) currentViewController:(UIView *)view
{
    id object = [view nextResponder];
    while (![object isKindOfClass:[UIViewController class]] &&  object != nil) {
        object = [object nextResponder];
    }
    return (UIViewController*)object;
}
+ (UIViewController *) currentViewController
{
    return [[[[[UIApplication sharedApplication] keyWindow] rootViewController] childViewControllers] lastObject];
}
@end