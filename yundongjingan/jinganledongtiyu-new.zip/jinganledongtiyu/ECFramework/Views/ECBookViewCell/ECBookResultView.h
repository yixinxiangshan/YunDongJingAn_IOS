//
//  ECBookResultView.h
//  jinganledongtiyu
//
//  Created by cheng on 13-10-9.
//  Copyright (c) 2013年 eCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ECBookResultView : UIView
@property (strong, nonatomic) NSMutableArray* subViewLabels;
@property NSInteger labelAlignment;// 1 : left , 2 : right , 3 : midddle , other : free
@property (nonatomic) CGFloat summary;
@property (nonatomic) CGFloat oldSummary;
- (void) subViewWithLabel:(NSString *)labelText price:(CGFloat)price;
- (void) subViewWithLabel:(NSString *)labelText isAdd:(BOOL)isAdd price:(CGFloat)price;
- (void) removeSubViewWithLabel:(NSString *)labelText;

- (void) subViewWithLabel:(NSString *)labelText tag:(NSInteger)tag;
- (void) removeSubViewWithTag:(NSInteger)tag;
- (void) updateSubViewWithConfig:(NSArray *)config;

- (CGFloat) totalPrice;
- (void) setSummary:(CGFloat)summary;

@end

@interface ECBookResultViewItem : UILabel
@property (strong, nonatomic) NSString* title;
@property CGFloat price;
@end



@interface ECBookResultSummaryView : UIView
@property (strong, nonatomic) NSAttributedString* summary;
@property (strong, nonatomic) NSAttributedString* oldSummary;

@end