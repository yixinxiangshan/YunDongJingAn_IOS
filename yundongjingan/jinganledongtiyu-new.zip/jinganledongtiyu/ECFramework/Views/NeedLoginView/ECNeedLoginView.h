//
//  ECNeedLoginView.h
//  JingAnWeekly
//
//  Created by EC on 3/21/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ECNeedLoginView : UIView

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIButton *needLogin;

@end
