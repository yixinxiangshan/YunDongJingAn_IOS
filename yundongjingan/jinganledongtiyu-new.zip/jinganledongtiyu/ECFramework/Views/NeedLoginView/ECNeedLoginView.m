//
//  ECNeedLoginView.m
//  JingAnWeekly
//
//  Created by EC on 3/21/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECNeedLoginView.h"

@implementation ECNeedLoginView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [[NSBundle mainBundle] loadNibNamed:@"ECNeedLoginView" owner:self options:nil];
        [self addSubview:_titleLabel];
        [self addSubview:_needLogin];
        [self setBackgroundColor:[UIColor whiteColor]];
        [_needLogin addTarget:self action:@selector(needLoginBtClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
- (void)needLoginBtClick:(id)sender{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ECNeedLogin.needLogin" object:nil userInfo:nil];
}
@end
