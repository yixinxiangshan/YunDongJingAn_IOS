//
//  UIImageExtends.h
//  ECMuse
//
//  Created by Alix on 11/29/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 * image 扩展
 */
@interface UIImage (Extends)
/**
 * 截取一部分
 */
- (UIImage*)imageInRect:(CGRect)rect;

/**
 * 截取一个不规则的四边形区域
 * @note 坐标原点在左下角(标准笛卡尔坐标)
 */
- (NSData*)imageDataFromBottomLeftPoint:(CGPoint)bl
                       bottomRightPoint:(CGPoint)br
                          topRightPoint:(CGPoint)tr
                                topLeft:(CGPoint)tl;

+ (UIImage*)ecImageNamed:(NSString *)name;

@end
