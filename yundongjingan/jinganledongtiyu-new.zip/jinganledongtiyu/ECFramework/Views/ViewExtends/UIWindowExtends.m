//
//  UIWindowExtends.m
//  ECViews
//
//  Created by Alix on 9/27/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "UIWindowExtends.h"

@implementation UIWindow (Extends)

#pragma mark - 
- (UIView*)findFirstResponder{
    return [self findFirstResponderInView:self];
}

#pragma mark - 
- (UIView*)findFirstResponderInView:(UIView *)view{
    if ([view isFirstResponder]) {
        return view;
    }
    
    for (UIView* subview in view.subviews) {
        if ([subview isFirstResponder]) {
            return subview;
        }
        
        UIView* firstResponder = [self findFirstResponderInView:subview];
        if (nil != firstResponder) {
            return firstResponder;
        }
    }
    
    
    return nil;

}
@end
