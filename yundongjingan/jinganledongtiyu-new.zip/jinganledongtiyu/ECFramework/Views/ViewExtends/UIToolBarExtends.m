//
//  UIToolBarExtends.m
//  ECViews
//
//  Created by Alix on 9/28/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "UIToolBarExtends.h"

@implementation UIToolbar (Extends)

#pragma mark -
- (UIBarButtonItem*)itemWithTag:(NSInteger)tag{
    for (UIBarButtonItem* view in self.items) {
        if (tag == view.tag) {
            return view;
        }
    }
    
    return nil;
}

- (void)replaceItemWithTag:(NSInteger)tag item:(UIBarButtonItem *)itm{
    UIBarButtonItem* barItem;
    for (int i=0; i<self.items.count; i++) {
        barItem = [self.items objectAtIndex:i];
        if (tag == barItem.tag) {
            NSMutableArray* array = [NSMutableArray arrayWithArray:self.items];
            [array replaceObjectAtIndex:i withObject:itm];
            
            self.items = array;
            
            return;
        }
    }
}

@end