//
//  ECAlertView.h
//  ECViews
//
//  Created by Alix on 9/26/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "AHAlertView.h"
#import "YIPopupTextView.h"

/**
 * 可自定义背景图片/按钮图片的alertView
 */
@interface ECAlertView : AHAlertView

@end

#pragma mark -
/**
 * 带有登录的AlertView, 可输入用户名和密码
 */
@interface ECSignUpAlert : AHAlertView <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>{
@private
    IBOutlet UITableView* _tableView;   // __weak Reference
}
// 用户名输入框
@property (nonatomic, strong, readonly) UITextField* usernameTF;
// password输入框
@property (nonatomic, strong, readonly) UITextField* passwordTF;

/**
 * 初始化
 * @param title : 要显示的标题
 */
- (id)initWithTitle:(NSString *)title;
@end

#pragma mark - 
/**
 * 类型于SinaWei的只可以发送文字的框
 */
@interface ECReplyAlert : YIPopupTextView
@end

