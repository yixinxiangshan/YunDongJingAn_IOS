//
//  UIImageViewExtends.m
//  ECViews
//
//  Created by Alix on 9/29/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "UIImageViewExtends.h"
#import "CALayerExtends.h"

@implementation UIImageView (Extends)

#pragma mark - 
+ (id)imageviewWithImage:(UIImage *)image{
    return [[self alloc] initWithImage:image];
}
+ (id)imageviewWithImage:(UIImage *)image hightlightedImage:(UIImage *)hightlightedImage{
    return [[self alloc] initWithImage:image
                      highlightedImage:hightlightedImage];
}

#pragma mark - 
+ (id)imageviewWithImageName:(NSString *)imageName{
    return [[self alloc] initWithImage:[UIImage imageNamed:imageName]];
}
+ (id)imageviewWithImageName:(NSString *)imageName hightlightedName:(NSString *)hightlightedName{
    return [[self alloc] initWithImage:[UIImage imageNamed:imageName]
                      highlightedImage:[UIImage imageNamed:hightlightedName]];
}

#pragma mark - 
- (id)initWithImageName:(NSString *)imagename{
    return [self initWithImage:[UIImage imageNamed:imagename]];
}
- (id)initWithImageName:(NSString *)imagename hightlightedName:(NSString *)hightlightedName{
    return [self initWithImage:[UIImage imageNamed:imagename]
              highlightedImage:[UIImage imageNamed:hightlightedName]];
}

#pragma mark -
+ (id)imageviewWithImageData:(NSData *)imageData{
    return [[self alloc] initWithImage:[UIImage imageWithData:imageData]];
}
+ (id)imageviewWithImageData:(NSData *)imageData hightlightedData:(NSData *)hightlightedData{
    return [[self alloc] initWithImage:[UIImage imageWithData:imageData]
                      highlightedImage:[UIImage imageWithData:hightlightedData]];
}

#pragma marka - 
- (id)initWithImageData:(NSData *)imageData{
    return [self initWithImage:[UIImage imageWithData:imageData]];
}
- (id)initWithImageData:(NSData *)imageData hightlightedData:(NSData *)hightlightedData{
    return [self initWithImage:[UIImage imageWithData:imageData]
              highlightedImage:[UIImage imageWithData:imageData]];
}

- (void)setImage:(UIImage *)image cornerRadius:(CGFloat)radius{
    [self setImage:image];
    [self setRoundCorners:radius];
}

#pragma mark - 设置圆角
- (void)setRoundCorners:(CGFloat)radius{
    CALayer* lay  = self.layer;//获取ImageView的层
    [lay setMasksToBounds:YES];
    [lay setCornerRadius:radius];//值越大，角度越圆
}
@end