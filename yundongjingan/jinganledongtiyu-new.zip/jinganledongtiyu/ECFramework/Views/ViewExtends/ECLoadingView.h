//
//  ECLoadingView.h
//  ECViews
//
//  Created by Alix on 9/26/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//  git://github.com/Dejal/DejalActivityView.git
//  https://github.com/Dejal/DejalActivityView
//  http://www.dejal.com/developer/?q=developer/dsactivityview


/**
 * 显示加载中的视图
 */

#import "ECRootView.h"
#import "DejalActivityView.h"

@interface ECLoadingView : DejalActivityView
@end

@interface ECLoadingKeyboardView : DejalKeyboardActivityView

@end

@interface ECLoadingWhiteView : DejalWhiteActivityView

@end

@interface ECLoadingBezelActivityView : DejalBezelActivityView

@end