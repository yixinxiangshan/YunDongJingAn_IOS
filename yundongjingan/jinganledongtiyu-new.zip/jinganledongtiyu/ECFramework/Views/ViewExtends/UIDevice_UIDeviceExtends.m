#import "UIDevice_UIDeviceExtends.h"

@implementation UIDevice (Extends)

// 是否高清
+ (BOOL)isRetina{
    static BOOL retValue = NO;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        UIScreen* screen = [UIScreen mainScreen];
        if ([screen respondsToSelector:@selector(scale)] && screen.scale == 2) {
            retValue = YES;
        }
    });
    return retValue;
}
// 是否i5
+ (BOOL)isIPhone5{
    static BOOL retValue = NO;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if ([self isRetina] && ([[UIDevice currentDevice].model hasPrefix:@"iPhone"] || [[UIDevice currentDevice].model hasPrefix:@"iPod"]) ) {
            CGSize size = [UIScreen mainScreen].bounds.size;
            if (((int)size.height) % 568 == 0 || ((int)size.width) % 568 == 0) {
                retValue = YES;
            }
        }
    });
    
    return retValue;
}

@end