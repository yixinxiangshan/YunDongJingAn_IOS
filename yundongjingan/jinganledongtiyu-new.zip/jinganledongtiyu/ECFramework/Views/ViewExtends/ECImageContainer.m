//
//  ECImageContainer.m
//  ECViews
//
//  Created by Alix on 10/19/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "ECImageContainer.h"
#import "UIViewExtends.h"
#import "ECWebImageDownloader.h"
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "UIImageViewExtends.h"

#define kHighlightedViewTag 2012

@interface ECImageContainer ( )
/**
 * 重新调整imageView/做到图片看着不变型
 */
- (void)resizeImageView;
@end

@implementation ECImageContainer

@synthesize imageView = _imageView;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self setUserInteractionEnabled:YES];
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(frame), CGRectGetHeight(frame))];
        [self addSubview:_imageView];
        [_imageView setBackgroundColor:[UIColor whiteColor]];
    
        self.showTouchedEffect = YES;
        self.touchedColor = [UIColor colorWithRed:.0 green:.0 blue:.0 alpha:.6];
        [self setClipsToBounds:YES];
        
    }
    return self;
}

#pragma mark -
- (void)setBackgroundColor:(UIColor *)backgroundColor{
    [super setBackgroundColor:backgroundColor];
    [_imageView setBackgroundColor:backgroundColor];
}
#pragma mark - dealloc
- (void)dealloc{
//    [_imageView release];
    if (_touchedColor) {
//        [_touchedColor release];
    }
    _imageURI = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
//    [super dealloc];
}

#pragma mark - 更新内容
- (void)updateWithNormalImage:(UIImage *)normalImage hightedImage:(UIImage *)hightlightedImage{
    if (normalImage) {
        [_imageView setImage:normalImage];
        
        [self resizeImageView];
    }
    
    if (hightlightedImage) {
        [_imageView setHighlightedImage:hightlightedImage];
    }
}
- (void)updateWithNormalImageURI:(NSString *)uri{
    if ([uri md5Hash] != _imageURI) {
        _imageURI = [uri md5Hash];
        UIImage* image = [[ECWebImageDownloader sharedInstance] getImageWithURI:uri];
        if (image) {
            [self updateWithNormalImage:image hightedImage:nil];
            return;
        } else {
            [[NSNotificationCenter defaultCenter] removeObserver:self];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(imageWasDownloaded:) name:_imageURI object:nil];
        }
    }
}
#pragma mark - 
- (void)imageWasDownloaded:(NSNotification*)noti{
    UIImage* image = [noti object];
    if (image) {
        [self updateWithNormalImage:image hightedImage:nil];
    }
}
#pragma mark - 适当缩放
- (void)resizeImageView{
    // 重新设置image容器大小
    CGFloat imageWidth = _imageView.image.size.width;
    CGFloat imageHeight = _imageView.image.size.height;
    CGFloat frameWidth = self.frame.size.width;
    CGFloat frameHeight = self.frame.size.height;
    
    CGRect frame = self.frame;
    
    CGFloat scaleWidth = frameWidth / imageWidth;
    CGFloat scaleHeight = frameHeight / imageHeight;
    CGFloat maxScale = scaleHeight < scaleWidth ? scaleWidth : scaleHeight;
    
    CGRect newFrame = CGRectMake(0, 0, imageWidth*maxScale, imageHeight*maxScale);     
    CGPoint oldCenter = CGPointMake(self.frame.size.width*.5, self.frame.size.height*.5);
    [_imageView setFrame:newFrame];
    [_imageView setCenter:oldCenter];
    
    self.frame = frame;
    [[NSNotificationCenter defaultCenter] postNotificationName:kImageContainerFrameChangedNoti object:self];
}
- (void)setNilImage{
    [_imageView setHighlightedImage:nil];
    [_imageView setImage:nil];
}
#pragma mark-
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    if (_imageView.highlightedImage) {
        [_imageView setHighlighted:YES];
        return;
    }
    if (self.showTouchedEffect) {
        UIView* view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame))];
        [view setTag:kHighlightedViewTag];
        [self addSubview:view];
        [view setBackgroundColor:self.touchedColor];
        view.alpha = 0.5f; // 官方建议少用alpha这个属性
//        [view release];
    }
}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    [_imageView setHighlighted:NO];
    if (self.showTouchedEffect) {
        [[self viewWithTag:kHighlightedViewTag] removeFromSuperview];
    }
    if (_delegate && [_delegate respondsToSelector:@selector(ecImageContainerWasClicked:)]) {
        CGPoint touchLocaiton = [[touches anyObject] locationInView:self.superview];
        if (CGRectContainsPoint(self.frame, touchLocaiton)) {
            [_delegate ecImageContainerWasClicked:self]; 
        }
        
    }
}
- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event{
    [_imageView setHighlighted:NO];
    if (self.showTouchedEffect) {
        [[self viewWithTag:kHighlightedViewTag] removeFromSuperview];
    }
}
#pragma mark - 
- (void)setImage:(UIImage *)image{
    if (image) {
        [_imageView setImage:image];
        [self resizeImageView];
    }
}

- (UIImage*)image{
    return  _imageView.image;
}
- (UIImage*)hightlightedImage{
    return _imageView.highlightedImage;
}
- (UIImageView*)imageView{
    return _imageView;
}
@end
