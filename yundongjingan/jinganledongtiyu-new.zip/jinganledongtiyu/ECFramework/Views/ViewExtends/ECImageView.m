//
//  ECImageView.m
//  ECViews
//
//  Created by Alix on 9/26/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "ECImageView.h"

@implementation ECImageView

@end
