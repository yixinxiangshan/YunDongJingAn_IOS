//
//  ECMultiScrollView.m
//  ECViews
//
//  Created by Alix on 10/8/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "ECMultiScrollView.h"
//#import "CALayerExtends.h"
#import "UIViewExtends.h"


@interface ECMultiScrollView ()

/**
 * 重新加载视图
 */
- (void)reloadDataBySwipeDirection:(UISwipeGestureRecognizerDirection)direction;

/**
 * 重新加载视图
 * @param animatied 是否作动画
 */
- (void)reloadDataWithAnimated:(BOOL)animated;
@end


@implementation ECMultiScrollView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        CGPoint center = CGPointMake(CGRectGetWidth(frame)*.5, CGRectGetHeight(frame)*.5);
        
        _previousView = [[UIView alloc] initWithFrame:frame];
        _currentView = [[UIView alloc] initWithFrame:frame];
        _nextView = [[UIView alloc] initWithFrame:frame];
        [self addSubview:_previousView];
        [self addSubview:_nextView];
        [self addSubview:_currentView];
        
        [self setClipsToBounds:YES];
        [_previousView setClipsToBounds:YES];
        [_currentView setClipsToBounds:YES];
        [_nextView setClipsToBounds:YES];
        [_previousView setCenter:center];
        [_nextView setCenter:center];
        [_currentView setCenter:center];
        
        [self bringSubviewToFront:_currentView];
        [self setUserInteractionEnabled:YES];
        
        _currentPageIndex = 0;
        
    }
    return self;
}
- (id)initWithFrame:(CGRect)frame direction:(ECMutiScrollViewDirection)direction{
    self = [self initWithFrame:frame];
    if (self) {
        _direction = direction;
        // 添加左划和右划
        UISwipeGestureRecognizer* swipeGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeGesture:)];
        [self addGestureRecognizer:swipeGesture];
        [swipeGesture setDirection:UISwipeGestureRecognizerDirectionLeft];
        
        
        [swipeGesture setDelaysTouchesEnded:YES];
        
        UISwipeGestureRecognizer* s2 = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeGesture:)];
        [self addGestureRecognizer:s2];
        [s2 setDirection:UISwipeGestureRecognizerDirectionRight];
        [s2 setDelaysTouchesEnded:YES];
        
        UISwipeGestureRecognizer* s3 = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeGesture:)];
        [self addGestureRecognizer:s3];
        [s3 setDelaysTouchesEnded:YES];
        [s3 setDirection:UISwipeGestureRecognizerDirectionUp];
        
        UISwipeGestureRecognizer* s4 = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeGesture:)];
        [self addGestureRecognizer:s4];
        [s4 setDelaysTouchesEnded:YES];
        [s4 setDirection:UISwipeGestureRecognizerDirectionDown];
        
        return self;
    }
    return nil;
}
#pragma mark -
- (void)setContentViewBackground:(UIColor *)color{
    [_previousView setBackgroundColor:color];
    [_currentView setBackgroundColor:color];
    [_nextView setBackgroundColor:color];
}
#pragma mark - 
- (void)setDatasource:(id<ECMultiScrollViewDataSource>)datasource{
    _datasource = datasource;
    [self reloadDataWithAnimated:NO];
}
#pragma mark - 
- (void)reloadData{
    if (_currentPageIndex <0) {
        _currentPageIndex = 0;
        return;
    } else {
        if (_datasource && [_datasource respondsToSelector:@selector(numberOfPagesinMultiScrollview:)]){
            NSUInteger pages = [_datasource numberOfPagesinMultiScrollview:self];
            if(_currentPageIndex >= pages  && pages > 0){
                _currentPageIndex = pages -1;
                return;
            }
        }
    }
    [self reloadDataWithAnimated:NO];
}
#pragma mark -
- (IBAction)handleSwipeGesture:(UISwipeGestureRecognizer*)sender{
    if (sender.state == UIGestureRecognizerStateEnded) {
        if (_direction == eMutileScrollviewLeftRight) {
            if (sender.direction == UISwipeGestureRecognizerDirectionLeft) {
                [self reloadDataBySwipeDirection:UISwipeGestureRecognizerDirectionLeft];
            } else if (sender.direction == UISwipeGestureRecognizerDirectionRight) {
                [self reloadDataBySwipeDirection:UISwipeGestureRecognizerDirectionRight];
            }
        } else if(_direction == eMutileScrollviewUpDown){
            if (sender.direction == UISwipeGestureRecognizerDirectionDown) {
                [self reloadDataBySwipeDirection:UISwipeGestureRecognizerDirectionDown];
            } else if (sender.direction == UISwipeGestureRecognizerDirectionUp) {
                [self reloadDataBySwipeDirection:UISwipeGestureRecognizerDirectionUp];
            }
        }
    } //else if(sender.state == UIGestureRecognizerStateCancelled) {
        
    //}
}
#pragma mark - 
- (void)reloadDataBySwipeDirection:(UISwipeGestureRecognizerDirection)direction{
    
    
    if (direction == UISwipeGestureRecognizerDirectionDown ||
        direction == UISwipeGestureRecognizerDirectionRight) {
        _currentPageIndex--;
    } else if(direction == UISwipeGestureRecognizerDirectionUp ||
              direction == UISwipeGestureRecognizerDirectionLeft){
        _currentPageIndex++;
    }
    
    if (_currentPageIndex <0) {
        _currentPageIndex = 0;
        return;
    } else {
        if (_datasource && [_datasource respondsToSelector:@selector(numberOfPagesinMultiScrollview:)]){
            NSUInteger pages = [_datasource numberOfPagesinMultiScrollview:self];
            if(_currentPageIndex >= pages  && pages > 0){
                _currentPageIndex = pages -1;
                return;
            }
        }
    }
    _swipeDirection = direction;
    // 作一个改变中心点的动画
    // 动画结束后重新加载视图
    // 交换变量&&3个视图的中心点
//    [self setUserInteractionEnabled:NO];
    CGFloat width = CGRectGetWidth(self.frame);
    CGFloat height = CGRectGetHeight(self.frame);
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.37f];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    if (_direction == eMutileScrollviewLeftRight) {
        if (direction == UISwipeGestureRecognizerDirectionLeft) {
            [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
            [_previousView setCenter:CGPointMake(_previousView.center.x-width, _previousView.center.y)];
            [_currentView setCenter:CGPointMake(_currentView.center.x-width, _currentView.center.y)];
            [_nextView setCenter:CGPointMake(_nextView.center.x-width, _nextView.center.y)];
        } else if(direction == UISwipeGestureRecognizerDirectionRight) {
            [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
            [_previousView setCenter:CGPointMake(_previousView.center.x+width, _previousView.center.y)];
            [_currentView setCenter:CGPointMake(_currentView.center.x+width, _currentView.center.y)];
            [_nextView setCenter:CGPointMake(_nextView.center.x+width, _nextView.center.y)];
        }
    } else if(_direction == eMutileScrollviewUpDown) {
        if(direction == UISwipeGestureRecognizerDirectionUp) {
            [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
            [_previousView setCenter:CGPointMake(_previousView.center.x, _previousView.center.y-height)];
            [_currentView setCenter:CGPointMake(_currentView.center.x, _currentView.center.y-height)];
            [_nextView setCenter:CGPointMake(_nextView.center.x, _nextView.center.y-height)];
        } else if(direction == UISwipeGestureRecognizerDirectionDown) {
            [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
            [_previousView setCenter:CGPointMake(_previousView.center.x, _previousView.center.y+height)];
            [_currentView setCenter:CGPointMake(_currentView.center.x, _currentView.center.y+height)];
            [_nextView setCenter:CGPointMake(_nextView.center.x, _nextView.center.y+height)];
        }
    }
    [UIView commitAnimations];
    if (_pageControl) {
        [self bringSubviewToFront:_pageControl];
        if (_datasource && [_datasource respondsToSelector:@selector(numberOfPagesinMultiScrollview:)]) {
            if (_showPageControl && [_datasource numberOfPagesinMultiScrollview:self] < 2) {
                [_pageControl setHidden:YES];
            } else if(_showPageControl) {
                [_pageControl setHidden:NO];
            } else {
                [_pageControl setHidden:YES];
            }
        }
    }
    
}
- (void)animationDidStop:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context{
    // 交换
    if (_swipeDirection == UISwipeGestureRecognizerDirectionUp) {
        UIView* tempView = _currentView;
        _currentView = _nextView;
        _nextView = _previousView;
        _previousView = tempView;
    } else if(_swipeDirection == UISwipeGestureRecognizerDirectionDown) {
        UIView* tempView = _currentView;
        _currentView = _previousView;
        _previousView = _nextView;
        _nextView = tempView;
    } else if(_swipeDirection == UISwipeGestureRecognizerDirectionLeft) {
        UIView* tempView = _currentView;
        _currentView = _nextView;
        _nextView = _previousView;
        _previousView = tempView;
    } else if(_swipeDirection == UISwipeGestureRecognizerDirectionRight) {
        UIView* tempView = _currentView;
        _currentView = _previousView;
        _previousView = _nextView;
        _nextView = tempView;
    }
    [self reloadDataWithAnimated:NO];
}
#pragma mark -
- (void)reloadDataWithAnimated:(BOOL)animated{
    if (_datasource && [_datasource respondsToSelector:@selector(viewInMultiScrollview:atIndex:)]) {
        UIView* view = [_datasource viewInMultiScrollview:self atIndex:(_currentPageIndex-1)];
        if (view) {
            [_previousView removeAllSubViews];
            [_previousView addSubview:view];
            [view setCenter:CGPointMake(CGRectGetWidth(_previousView.frame)*.5, CGRectGetHeight(_previousView.frame)*.5)];
        }
        
        view = [_datasource viewInMultiScrollview:self atIndex:_currentPageIndex];
        if (view) {
            [_currentView removeAllSubViews];
            [_currentView addSubview:view];
            [view setCenter:CGPointMake(CGRectGetWidth(_currentView.frame)*.5, CGRectGetHeight(_currentView.frame)*.5)];
        }
        
        view = [_datasource viewInMultiScrollview:self atIndex:(_currentPageIndex+1)];
        if (view) {
            [_nextView removeAllSubViews];
            [_nextView addSubview:view];
            [view setCenter:CGPointMake(CGRectGetWidth(_nextView.frame)*.5, CGRectGetHeight(_nextView.frame)*.5)];
        }
        
    }
    CGFloat width = CGRectGetWidth(self.frame);
    CGFloat height = CGRectGetHeight(self.frame);
    if (_direction == eMutileScrollviewLeftRight) {
        [_previousView setCenter:CGPointMake(-width*.5, height*.5)];
        [_currentView setCenter:CGPointMake(width*.5, height*.5)];
        [_nextView setCenter:CGPointMake(width*1.5, height*.5)];
    } else if(_direction == eMutileScrollviewUpDown) {
        [_previousView setCenter:CGPointMake(width*.5, -height*.5)];
        [_currentView setCenter:CGPointMake(width*.5, height*.5)];
        [_nextView setCenter:CGPointMake(width*.5, height*1.5)];
    }
    if (_showPageControl) {
        if (_pageControl != nil) {
            [_pageControl setHidden:NO];
            [_pageControl setCurrentPage:_currentPageIndex];
            [self bringSubviewToFront:_pageControl];
            
            if (_datasource && [_datasource respondsToSelector:@selector(numberOfPagesinMultiScrollview:)]) {
                if ([_datasource numberOfPagesinMultiScrollview:self] < 2) {
                    [_pageControl setHidden:YES];
                }
            }
        }
    } else {
        if (_pageControl) {
            [_pageControl setHidden:YES];
        }
    }
}
#pragma mark - 
- (void)setShowPageControl:(BOOL)showPageControl{
    _showPageControl = showPageControl;
    if (nil == _pageControl) {
        _pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame)*.25, 20)];
        [self addSubview:_pageControl];
        [_pageControl setUserInteractionEnabled:NO];
        if (_datasource && [_datasource respondsToSelector:@selector(numberOfPagesinMultiScrollview:)]) {
            if ([_datasource numberOfPagesinMultiScrollview:self] < 2) {
                [_pageControl setHidden:YES];
            }
        }
    }
    if (_datasource && [_datasource respondsToSelector:@selector(numberOfPagesinMultiScrollview:)]) {
        [_pageControl setNumberOfPages:[_datasource numberOfPagesinMultiScrollview:self]];
    }
    
    [_pageControl sizeToFit];
    if (CGRectGetWidth(_pageControl.frame) > CGRectGetWidth(self.frame)) {
        [_pageControl setFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(_pageControl.frame))];
    }
    [_pageControl setCenter:CGPointMake(CGRectGetWidth(self.frame)*0.5, CGRectGetHeight(_pageControl.frame)*0.5f)];
    [_pageControl setCurrentPage:_currentPageIndex];
}
//#pragma mark - 
//- (void)dealloc{
//    [_currentView release];
//    [_nextView release];
//    [_previousView release];
//    [_pageControl release];
//    
//    [super dealloc];
//}
@end
