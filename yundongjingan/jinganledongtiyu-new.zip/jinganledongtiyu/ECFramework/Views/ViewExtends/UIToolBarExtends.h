//
//  UIToolBarExtends.h
//  ECViews
//
//  Created by Alix on 9/28/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIToolbar (Extends)
- (UIBarButtonItem*)itemWithTag:(NSInteger)tag;

- (void)replaceItemWithTag:(NSInteger)tag item:(UIBarButtonItem*)itm;
@end
