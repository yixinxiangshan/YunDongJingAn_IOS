//
//  ECImageContainer.h
//  ECViews
//
//  Created by Alix on 10/19/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "ECRootView.h"
/**
 * 支持点击的图片容器
 * @remarks 用于大量图片浏览的,比如瀑布流/模仿按钮点击效果的demo
 * @remarks 图片不会变形,但有些会显示不出来
 */
@class ECImageContainer;
/**
 * 下载了图片后大小改变事件
 */
#define kImageContainerFrameChangedNoti @"com.ecloud.imagecontainer.framechangenoti" 
@protocol ECImageContainerDelegate <NSObject>

@optional
/**
 * 该视图被点击事件
 * @param   container 视图本身
 */
- (void)ecImageContainerWasClicked:(ECImageContainer*)container;

@end

@interface ECImageContainer : ECRootView {
@private
//    UIImageView* _imageView;    // 图片容器载体
    NSString*   _imageURI;      // 图片网络地址
}
@property (nonatomic, readonly) IBOutlet UIImageView* imageView;
@property (nonatomic, assign) BOOL showTouchedEffect;   // 是否显示点击效果 默认有(如果指定了高亮图片,此标记被忽略)
@property (nonatomic, retain, readwrite) UIColor*   touchedColor;   // 点击时图片上层的点击颜色,如果指定hightlightImage此颜色被忽略
@property (nonatomic, assign, readwrite) id<ECImageContainerDelegate>delegate; // 应用程序委托
@property (nonatomic, weak, readwrite) UIImage*    image;
@property (nonatomic, weak, readonly) UIImage*    hightlightedImage;
//@property (nonatomic, assign, readonly) UIImageView* imageview; // 图片容器载体

/**
 * 更新imageview 的图片
 * @param   normalImage 正常状态下的图片
 * @param   hightlightedImage   高亮时的图片
 * @remarks 高亮图片可以指定为nil,此时如果在点击时要显示高亮就用颜色代替
 */
- (void)updateWithNormalImage:(UIImage*)normalImage hightedImage:(UIImage*)hightlightedImage;

/**
 * 更新imageview的图片
 * @param   uri 图片网络地址
 */
- (void)updateWithNormalImageURI:(NSString*)uri;

/**
 * 什么都不显示
 */
- (void)setNilImage;

@end
