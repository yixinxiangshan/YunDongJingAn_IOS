//
//  ECCloseView.h
//  ECMuse
//
//  Created by Alix on 10/25/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import "ECRootView.h"


/**
 * 使用时把要显示的视图放到该视图
 * @note 只放1个视图(该类重写了addSubView方法)
 * @note 暂时只支持竖直方向
 */
@class ECCloseView;
@protocol ECCloseViewDelegate <NSObject>

/**
 * 关闭事件
 * @param closeView 视图
 */
@optional
- (void)ecCloseViewWasClosed:(ECCloseView*)closeView;


@end
@interface ECCloseView : ECRootView{
    UIButton*   _closeButton;           // 关闭按钮
    UIView*     _modalBackgroundView;   // 背景
    UIView*     _contentView;           // 要显示的view
    
}
@property (nonatomic, assign) id<ECCloseViewDelegate>delegate;
@property (nonatomic, assign) CGFloat edgeWidth;    // 四周边框距离
@property (nonatomic, assign) CGFloat padding;      // 四周白色间距
@property (nonatomic, assign) CGFloat lineWidth;    // 中间线宽
/**
 * 显示
 */
- (void)show;

/**
 * 关闭
 */
- (void)hide;

@end
