//
//  ECBadgeView.h
//  ECMuse
//
//  Created by Alix on 11/15/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import "ECRootView.h"
// 仿照UITabBarItem 的BadgeView实现

@interface ECBadgeView : ECRootView

@property (nonatomic, readwrite, copy) NSString*    badgeValue; // 要显示的内容
@property (nonatomic, readwrite, strong) UIFont*    font;       // 字体
@property (nonatomic, readwrite, strong) UIColor*   textColor;  // 文字颜色

@property (nonatomic, readwrite, strong) UIColor*   tintColor;  // 背景色
@property (nonatomic, readwrite, strong) UIColor*   shadowColor;    // 阴影颜色
@property (nonatomic, readwrite, assign) CGSize     shadowOffset;   // 阴影大小
@property (nonatomic, readwrite, assign) CGFloat    shadowBlur;     // 阴影模糊程度
@property (nonatomic, readwrite, assign) BOOL       showShadow;     // 是否显示
@end
