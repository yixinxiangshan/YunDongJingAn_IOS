//
//  ECAlertView.m
//  ECViews
//
//  Created by Alix on 9/26/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//
//  SignUpAlert git://github.com/digdog/DDAlertPrompt.git

#import "ECAlertView.h"
#import <QuartzCore/QuartzCore.h>
#import "Extends.h"



@implementation ECAlertView

@end


#pragma mark - 带有登录的AlertView
#pragma mark - 带有登录的AlertView

@interface ECSignUpAlert ()
@property (nonatomic, strong, readwrite) UITextField* usernameTF;
@property (nonatomic, strong, readwrite) UITextField* passwordTF;

/**
 * 创建tableView && textFields
 */
- (void)setupTableView;


@end

@implementation ECSignUpAlert

#pragma mark -
- (id)initWithTitle:(NSString *)title{
    self = [super initWithTitle:title message:@"\n\n\n\n"];
    if (self) {
        
        [self addSubview:self.usernameTF];
        [self addSubview:self.passwordTF];
        [self setupTableView];
        [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
        
        self.autoresizingMask = (UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin);
        
        return self;
    }
    return nil;
}

- (id)initWithTitle:(NSString *)title message:(NSString *)message{
    return [self initWithTitle:title];
}


#pragma mark -
- (void)layoutSubviews{
    [super layoutSubviews];
    [self setUserInteractionEnabled:YES];
    if (UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])) {
        _tableView.frame = CGRectMake(8.0f, 56.0f, 260.0f, 70.0f);
        [self setCenter:CGPointMake(self.center.x, self.center.y-100)];
    } else {
        _tableView.frame = CGRectMake(8.0f, 41.0f, 260.0f, 70.0f);
    }
}

#pragma mark -
- (void)setupTableView{
    _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.scrollEnabled = NO;
    _tableView.opaque = NO;
    _tableView.layer.cornerRadius = 3.0f;
    _tableView.editing = YES;
    _tableView.rowHeight = 35.0f;
    [self addSubview:_tableView];
}
#pragma mark -
- (void)dealloc{
    [_tableView setDataSource:nil];
    [_tableView setDelegate:nil];
    [[UIDevice currentDevice] endGeneratingDeviceOrientationNotifications];
    
//    [super dealloc];
}

#pragma mark -
#pragma mark Accessors

- (UITextField *)usernameTF{
    
	if (!_usernameTF) {
		_usernameTF = [[UITextField alloc] initWithFrame:CGRectMake(5.0f, 0.0f, 255.0f, 35.0f)];
		_usernameTF.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
		_usernameTF.clearButtonMode = UITextFieldViewModeWhileEditing;
        _usernameTF.returnKeyType = UIReturnKeyNext;
		_usernameTF.placeholder = ECLocalizedString(@"Nickname or Email", @"Nickname or Email");
        [_usernameTF setDelegate:self];
	}
	return _usernameTF;
}

- (UITextField *)passwordTF {
	
	if (!_passwordTF) {
		_passwordTF = [[UITextField alloc] initWithFrame:CGRectMake(5.0f, 0.0f, 255.0f, 35.0f)];
		_passwordTF.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
		_passwordTF.secureTextEntry = YES;
		_passwordTF.clearButtonMode = UITextFieldViewModeWhileEditing;
        _passwordTF.returnKeyType = UIReturnKeyDone;
		_passwordTF.placeholder = ECLocalizedString(@"Password", @"Password");
        [_passwordTF setDelegate:self];
	}
	return _passwordTF;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *AlertPromptCellIdentifier = @"ECSignUpAlertCell";
    
    UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:AlertPromptCellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:AlertPromptCellIdentifier];
    }
	
	if (![cell.contentView.subviews count]) {
		if (indexPath.row) {
			[cell.contentView addSubview:_passwordTF];
		} else {
			[cell.contentView addSubview:_usernameTF];
		}
	}
    
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath {
    return NO;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleNone;
}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    [_usernameTF resignFirstResponder];
    [_passwordTF resignFirstResponder];
    
}

#pragma mark -
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if ([_usernameTF isEqual:textField]) {
        [_passwordTF becomeFirstResponder];
    } else {
        [_usernameTF resignFirstResponder];
        [_passwordTF resignFirstResponder];
    }
    return YES;
}
@end


#pragma mark -
#pragma mark -
@implementation ECReplyAlert

@end