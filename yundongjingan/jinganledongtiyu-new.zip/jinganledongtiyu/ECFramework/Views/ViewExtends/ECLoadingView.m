//
//  ECLoadingView.m
//  ECViews
//
//  Created by Alix on 9/26/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "ECLoadingView.h"
#import <QuartzCore/QuartzCore.h>


@implementation ECLoadingView
@end


#pragma mark - 
@implementation ECLoadingKeyboardView
@end

#pragma mark -
@implementation ECLoadingWhiteView
@end

#pragma mark -
@implementation ECLoadingBezelActivityView
@end
