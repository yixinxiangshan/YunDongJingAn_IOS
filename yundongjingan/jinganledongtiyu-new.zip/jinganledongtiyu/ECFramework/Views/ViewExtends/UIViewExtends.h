//
//  UIViewExtends.h
//  ECViews
//
//  Created by Alix on 9/27/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 * orign/frame相关
 */
@interface UIView (Frame)

/**
 * 左上角y坐标
 */
@property (nonatomic, assign, readonly) CGFloat top;

/**
 * 左上角x坐标
 */
@property (nonatomic, assign, readonly) CGFloat left;


- (void)setOriginX:(CGFloat)x;
- (void)setOriginY:(CGFloat)y;
- (void)setOriginX:(CGFloat)x Y:(CGFloat)y;
- (void)setWidth:(CGFloat)width;
- (void)setHeight:(CGFloat)height;
- (void)setWidth:(CGFloat)width heignt:(CGFloat)heignt;


- (CGPoint)getOrigin;
- (CGFloat)getOriginX;
- (CGFloat)getOriginY;
- (CGFloat)getWidth;
- (CGFloat)getHeignt;
- (CGFloat)getCenterX;
- (CGFloat)getCenterY;
- (CGSize)getSize;
- (CGFloat)rightX;


/**
 * 应用程序的frame 
 */
+ (CGRect)applicationFrame;
@end

#pragma mark - 
/**
 * view相关
 */
@interface UIView (View)

/**
 * 删除所有视图
 */
- (void)removeAllSubViews;

@end

#pragma mark -
/**
 * controlelr相关
 */
@interface UIView (Controller)

/**
 * 返回视图的持有者
 */
- (UIViewController*)viewController;
@end
