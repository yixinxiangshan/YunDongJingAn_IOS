//
//  UINavigationBarExtends.m
//  ECViews
//
//  Created by Alix on 9/29/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "UINavigationBarExtends.h"

@interface UINavigationBar (TitleAttribute)
/**
 * 设置title属性
 */
- (void)setTitleTextAttribute:(id)titleTextAttributes forKey:(NSString*)key;
@end
@implementation UINavigationBar (TitleAttribute)
- (void)setTitleTextAttribute:(id)titleTextAttributes forKey:(NSString *)key{
    NSMutableDictionary* dict = [NSMutableDictionary dictionaryWithDictionary:self.titleTextAttributes];
    if (nil == dict) {
        dict = [NSMutableDictionary dictionary];
    }
    [dict setValue:titleTextAttributes forKey:key];
    self.titleTextAttributes = dict;
}
@end
#pragma mark -
@implementation UINavigationBar (Extends)
#pragma mark - 
- (UIFont*)titleFont{
    return [self.titleTextAttributes valueForKey:UITextAttributeFont];
}
- (void)setTitleFont:(UIFont *)titleFont{
    [self setTitleTextAttribute:titleFont
                          forKey:UITextAttributeFont];
}

#pragma mark - 
- (UIColor*)titleColor{
    return [self.titleTextAttributes valueForKey:UITextAttributeTextColor];
}
- (void)setTitleColor:(UIColor *)titleColor{
    [self setTitleTextAttribute:titleColor
                          forKey:UITextAttributeTextColor];
}

#pragma mark - 
- (UIColor*)titleShadowColor{
    return [self.titleTextAttributes valueForKey:UITextAttributeTextShadowColor];
}
- (void)setTitleShadowColor:(UIColor *)titleShadowColor{
    [self setTitleTextAttribute:titleShadowColor
                          forKey:UITextAttributeTextShadowColor];
}

#pragma mark - 
- (UIOffset)titleShadowOffset{
    return [[self.titleTextAttributes valueForKey:UITextAttributeTextShadowOffset] UIOffsetValue];
}
- (void)setTitleShadowOffset:(UIOffset)titleShadowOffset{
    [self setTitleTextAttribute:[NSValue valueWithUIOffset:titleShadowOffset]
                          forKey:UITextAttributeTextShadowOffset];
}
@end