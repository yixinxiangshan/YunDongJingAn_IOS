//
//  ECRootView.h
//  ECViews
//
//  Created by Alix on 9/26/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Extends.h"


@interface ECRootView : UIView

@end
