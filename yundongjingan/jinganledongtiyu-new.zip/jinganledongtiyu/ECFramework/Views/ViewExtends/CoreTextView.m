//
//  CoreTextView.m
//  ECMuse
//
//  Created by Alix on 11/21/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import "CoreTextView.h"
#import <CoreText/CoreText.h>
#import "Utils.h"
#define kPadding    10.0f
@interface CoreTextView ()
/**
 * 设置初始值
 */
- (void)initDefault;

/**
 * 重新计算高度
 * @notice 修改frame, orignPoint不变, width不变, height变化
 */
- (void)resetFrameHeight;
@end
@implementation CoreTextView

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initDefault];
        return self;
    }
    return nil;
}
- (void)awakeFromNib{
    [super awakeFromNib];
    [self initDefault];
}
- (id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initDefault];
        return self;
    }
    return nil;
}
#pragma mark - 设置初始值
- (void)initDefault{
    _font = [UIFont systemFontOfSize:14.0f];
    _color = [UIColor blackColor];
    _characterSpacing = 2.0f;
    _linesSapcing = 5.0f;
    _textAlignment = NSTextAlignmentJustified;
    [self setBackgroundColor:[UIColor whiteColor]];
}
#pragma mark - 更新显示
- (void)layoutSubviews{
    [self setNeedsDisplay];
}
- (void)setCharacterSpacing:(CGFloat)characterSpacing{
    if (characterSpacing >0 && characterSpacing != self.characterSpacing) {
        _characterSpacing = characterSpacing;
        [self resetFrameHeight];
        [self setNeedsDisplay];
    }
}
- (void)setLinesSapcing:(CGFloat)linesSapcing{
    if (linesSapcing > 0 && linesSapcing != self.linesSapcing) {
        _linesSapcing = linesSapcing;
        [self resetFrameHeight];
        [self setNeedsDisplay];
    }
}
- (void)setFont:(UIFont *)font{
    if (font && !([font.fontName isEqualToString:self.font.fontName] && (font.pointSize==self.font.pointSize) )) {
        _font = font;
        [self resetFrameHeight];
        [self setNeedsDisplay];
    }
}
- (void)setColor:(UIColor *)color{
    if (color && ![color isEqual:color]) {
        _color = color;
        [self setNeedsDisplay];
    }
}
- (void)setText:(NSString *)text{
    if (text && [text length] && ![text isEqualToString:self.text]) {
        _text = text;
        [self resetFrameHeight];
        [self setNeedsDisplay];
    }
}
- (void)setTextAlignment:(UITextAlignment)textAlignment{
    if (_textAlignment != textAlignment) {
        _textAlignment = textAlignment;
        [self setNeedsDisplay];
    }
}
#pragma mark - 显示
- (void)drawRect:(CGRect)rect{
    if (_text.length < 1) {
        return;
    }
    // 去掉空行
    NSString* showStr = _text;
    showStr = [showStr stringByReplacingOccurrencesOfString:@"\r\n" withString:@"\n"];
    
    // 设置attribute string
    NSMutableAttributedString* mutableAttrStr = [[NSMutableAttributedString alloc] initWithString:showStr];
    
    // 设置字体
    CTFontRef font = CTFontCreateWithName((__bridge CFStringRef)(self.font.fontName), self.font.pointSize, NULL);
    [mutableAttrStr addAttribute:(NSString*)kCTFontAttributeName value:(__bridge id)font range:NSMakeRange(0, mutableAttrStr.string.length)];
    
    // 设置字间距
    if (self.characterSpacing > 0) {
        int number = self.characterSpacing;
        CFNumberRef numberRef = CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt8Type, &number);
        [mutableAttrStr addAttribute:(NSString*)kCTKernAttributeName value:(__bridge id)numberRef range:NSMakeRange(0, mutableAttrStr.string.length)];
        CFRelease(numberRef);
    }
    
    // 设置文字颜色
    [mutableAttrStr addAttribute:(NSString*)kCTForegroundColorAttributeName value:(id)self.color.CGColor range:NSMakeRange(0, mutableAttrStr.string.length)];
    
    // 设置对齐方式(默认左对齐)
    CTTextAlignment alignment = kCTTextAlignmentJustified;
    switch (self.textAlignment) {
        case NSTextAlignmentCenter:
            alignment = kCTCenterTextAlignment;
            break;
        case NSTextAlignmentRight:
            alignment = kCTRightTextAlignment;
            break;
        case NSTextAlignmentJustified:
            alignment = kCTJustifiedTextAlignment;
            break;
        case NSTextAlignmentLeft:
            alignment = kCTLeftTextAlignment;
            break;
        case NSTextAlignmentNatural:
            alignment = kCTNaturalTextAlignment;
            break;
        default:
            alignment = kCTTextAlignmentJustified;
            break;
    }
    CTParagraphStyleSetting paragraphStyle;
    paragraphStyle.spec = kCTParagraphStyleSpecifierAlignment;
    paragraphStyle.valueSize = sizeof(alignment);
    paragraphStyle.value = &alignment;
    
    // 设置行间距
    CGFloat lineSpace = self.linesSapcing;
    CTParagraphStyleSetting lineParagraphStyle;
    lineParagraphStyle.spec = kCTParagraphStyleSpecifierLineSpacingAdjustment;
    lineParagraphStyle.valueSize = sizeof(lineSpace);
    lineParagraphStyle.value = &lineSpace;
    
    // 设置段间距 (默认5.0f, 不可更改)
    CGFloat paragraphSpacing = 5.0f;
    CTParagraphStyleSetting paragraphSpacingStyle;
    paragraphSpacingStyle.spec = kCTParagraphStyleSpecifierParagraphSpacing;
    paragraphSpacingStyle.valueSize = sizeof(paragraphSpacing);
    paragraphSpacingStyle.value = &paragraphSpacing;
    
    // 使用上面的设置
    CTParagraphStyleSetting settings[] = { paragraphStyle, lineParagraphStyle, paragraphSpacingStyle };
    CTParagraphStyleRef styles = CTParagraphStyleCreate(settings, sizeof(settings));
    [mutableAttrStr addAttribute:(NSString*)kCTParagraphStyleAttributeName value:(__bridge id)styles range:NSMakeRange(0, mutableAttrStr.string.length)];
    CFRelease(styles);
    
    // 排版
    CTFramesetterRef framesetter = CTFramesetterCreateWithAttributedString((__bridge CFAttributedStringRef)mutableAttrStr);
    CGMutablePathRef leftColumnPath = CGPathCreateMutable();
    CGPathAddRect(leftColumnPath, NULL ,CGRectMake(kPadding , -kPadding ,self.bounds.size.width-2*kPadding , self.bounds.size.height));
    CTFrameRef leftFrame = CTFramesetterCreateFrame(framesetter,CFRangeMake(0, 0), leftColumnPath , NULL);
    
    // 坐标变换
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetTextMatrix(context , CGAffineTransformIdentity);
    CGContextTranslateCTM(context , 0 ,self.bounds.size.height);
    CGContextScaleCTM(context, 1.0 ,-1.0);
    
    // 画文本
    CTFrameDraw(leftFrame,context);
    
    //释放
    CGPathRelease(leftColumnPath);
    CFRelease(framesetter);
    CFRelease(font);
    UIGraphicsPushContext(context);
}
#pragma mark - 修改本视图高度
// 原理: 每段分开
// ((每段长度 + 字符个数* 字符间距)  / 单行宽度 ) * (行高+行间距)  = 每段高度
// 把所有段 的高度+起来就是总的高度
- (void)resetFrameHeight{
    if (_text && [_text length]) {
        // 单行宽度
        int oneLineWidth = CGRectGetWidth(self.frame) - 2*kPadding;
        CGFloat totalHeihgt = 2*kPadding;
        
        NSString* showString = [_text stringByReplacingOccurrencesOfString:@"\r\n" withString:@"\n"];
        NSArray* stringsArray = [showString componentsSeparatedByString:@"\n"];
        CGSize size = CGSizeZero;
        int lines = 0;
        int width = 0.0f;
        if ([stringsArray count]) {
            ECLog(@"count %d", [stringsArray count]);
            for (NSString* str in stringsArray) {
                size = [str sizeWithFont:self.font];
                width = size.width + str.length*(_characterSpacing);
                lines = (width % oneLineWidth) ? (width / oneLineWidth +1) : (width / oneLineWidth); // 行数
                totalHeihgt += (size.height + _linesSapcing)*lines;
                totalHeihgt += (5.0f - _linesSapcing);    // 段间距
            }
            
            [self setFrame:CGRectMake(self.frame.origin.x, self.frame.origin.y, CGRectGetWidth(self.frame), totalHeihgt)];
            ECLog(@"Frame %@", NSStringFromCGRect(self.frame));
            if (_delegate && [_delegate respondsToSelector:@selector(CoreTextViewFrameWasChanged:)]) {
                [_delegate CoreTextViewFrameWasChanged:self];
            }
        }

    }
}
@end
