//
//  CALayerExtends.m
//  ECViews
//
//  Created by Alix on 9/28/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "CALayerExtends.h"

#define kECCALayerDefaultTranistionDuration  0.3f



@interface AnimationDelegate : NSObject

@property (readwrite, nonatomic, copy) void (^startBlock)();
@property (readwrite, nonatomic, copy) void (^stopBlock)(BOOL finished);

@end

#pragma mark - Category Implementation

@implementation AnimationDelegate

@synthesize startBlock;
@synthesize stopBlock;

#pragma mark - Protocol Implementations

#pragma mark - CAAnimation Methods (Informal)

- (void)animationDidStart:(CAAnimation *)animation
{
	if (self.startBlock != nil)
	{
		self.startBlock();
	}
}

- (void)animationDidStop:(CAAnimation *)animation finished:(BOOL)finished
{
	if (self.stopBlock != nil)
	{
		self.stopBlock(finished);
	}
}

@end

#pragma mark -



@implementation CALayer (Extends)

#pragma mark - 
#define kECCALayerExtendsTagKey    @"com.ecloudiot.calayerextends.key.tag"
- (void)setTag:(NSInteger)tag{
    [self setValue:[NSNumber numberWithInteger:tag] forKey:kECCALayerExtendsTagKey];
}

#pragma mark - 
- (CALayer*)layerWithTag:(NSInteger)tag{
    for (CALayer* layer in self.sublayers) {
        id value = [layer valueForKey:kECCALayerExtendsTagKey];
        if (value && [value isMemberOfClass:[NSNumber class]] && [value integerValue] == tag ) {
            return layer;
        }
    }
    return nil;
}
@end


#pragma mark - 
@implementation CALayer (Debug)

#pragma mark - 
- (NSString*)debugDescription{
    return [NSString stringWithFormat:@"<%@ (%@) frame:%@, bounds=%@ zAnchor=%.2f>",
            NSStringFromClass([self class]), self.name,
            NSStringFromCGRect(self.frame),
            NSStringFromCGRect(self.bounds),
            self.zPosition];
}
@end

#pragma mark - 
@implementation CALayer (Frame)

#pragma mark - 
- (CGPoint)frameOrigin{
    return self.frame.origin;
}
- (void)setFrameOrigin:(CGPoint)frameOrigin{
    self.frame = CGRectMake(frameOrigin.x, frameOrigin.y, self.frameWidth, self.frameHeight);
}
#pragma mark -
- (CGFloat)frameTop{
    return self.frame.origin.y;
}
- (void)setFrameTop:(CGFloat)frameTop{
    self.frame = CGRectMake(self.frameLeft, frameTop, self.frameWidth, self.frameHeight);
}
#pragma mark -
- (CGFloat)frameLeft{
    return self.frame.origin.x;
}
- (void)setFrameLeft:(CGFloat)frameLeft{
    self.frame = CGRectMake(frameLeft, self.frameTop, self.frameWidth, self.frameHeight);
}
#pragma mark -
- (CGFloat)frameWidth{
    return CGRectGetWidth(self.frame);
}
- (void)setFrameWidth:(CGFloat)frameWidth{
    self.frame = CGRectMake(self.frameLeft, self.frameTop, frameWidth, self.frameHeight);
}
#pragma mark -
- (CGFloat)frameHeight{
    return CGRectGetHeight(self.frame);
}
- (void)setFrameHeight:(CGFloat)frameHeight{
    self.frame = CGRectMake(self.frameLeft, self.frameTop, self.frameWidth, frameHeight);
}

#pragma mark - 
- (CGFloat)midX{
    return CGRectGetMidX(self.frame);
}
- (void)setMidX:(CGFloat)midX{
    self.frameLeft = (midX-self.frameWidth*.2);
}
#pragma mark - 
- (CGFloat)rightX{
    return CGRectGetMaxX(self.frame);
}

@end


#pragma mark -
#pragma mark - 
@implementation CALayer (Layer)
///
- (id)initWithFrame:(CGRect)frame{
    self = [super init];
    if (self) {
        self.frame = frame;
        return self;
    }
    return nil;
}
+ (id)layerWithFrame:(CGRect)frame{
    return [[self alloc] initWithFrame:frame];
}
@end

#pragma mark - 
@implementation CALayer (Animation)

#pragma mark - 
- (void)addFadeTransition{
    [self addFadeTransitionWithDuration:kECCALayerDefaultTranistionDuration];
}
- (void)addFadeTransitionWithDuration:(NSTimeInterval)duration{
    CATransition* transition = [CATransition animation];
    transition.type = kCATransitionFade;
    transition.duration = duration;
    [self addAnimation:transition forKey:kCATransition];
}

#pragma mark - 
- (void)addMoveInTransitionWithSubtype:(NSString *)subType{
    [self addMoveInTransitionWithSubtype:subType duration:kECCALayerDefaultTranistionDuration];
}
- (void)addMoveInTransitionWithSubtype:(NSString *)subType duration:(NSTimeInterval)duration{
    CATransition* transition = [CATransition animation];
    transition.type = kCATransitionMoveIn;
    transition.subtype = subType;
    transition.duration = duration;
    [self addAnimation:transition forKey:kCATransition];
}

#pragma mark - 
- (void)addPushTransitionWithSubtype:(NSString *)subtype{
    [self addPushTransitionWithSubtype:subtype duration:kECCALayerDefaultTranistionDuration];
}
- (void)addPushTransitionWithSubtype:(NSString *)subtype duration:(NSTimeInterval)duration{
    CATransition* transition = [CATransition animation];
    transition.type = kCATransitionPush;
    transition.subtype = subtype;
    transition.duration = duration;
    [self addAnimation:transition forKey:kCATransition];
}

#pragma mark - 
- (void)addRevealTransitionWithSubtype:(NSString *)subtype{
    [self addRevealTransitionWithSubtype:subtype duration:kECCALayerDefaultTranistionDuration];
}
- (void)addRevealTransitionWithSubtype:(NSString *)subtype duration:(NSTimeInterval)duration{
    CATransition* transition = [CATransition animation];
    transition.type = kCATransitionReveal;
    transition.subtype = subtype;
    transition.duration = duration;
    [self addAnimation:transition forKey:kCATransition];
}

#pragma mark - 
- (void)addAnimation:(CAAnimation *)anim{
    [self addAnimation:anim forKey:nil];
}

#pragma mark - 
- (void)addAnimation:(CAAnimation *)anim forKey:(NSString *)key startBlock:(void (^)(void))startBlock stopBlock:(void (^)(BOOL))stopBlock{
    AnimationDelegate* delegate = [AnimationDelegate new];
    delegate.stopBlock = stopBlock;
    delegate.startBlock = startBlock;
    anim.delegate = delegate;
    [self addAnimation:anim forKey:key];
}
- (void)addAnimation:(CAAnimation *)anim forKey:(NSString *)key stopBlock:(void (^)(BOOL))stopBlock{
    [self addAnimation:anim forKey:key startBlock:nil stopBlock:stopBlock];
}

#pragma mark - 
- (void)addRippleTransition{
    [self addRippleTransitionWithDuration:(2*kECCALayerDefaultTranistionDuration)];
}

- (void)addRippleTransitionWithDuration:(NSTimeInterval)duration{
        CATransition *animation = [CATransition animation];
        animation.duration = duration;
        animation.timingFunction = UIViewAnimationCurveEaseInOut;
        animation.fillMode = kCAFillModeRemoved;
        animation.endProgress = 1.0f;
        animation.removedOnCompletion = YES;
        animation.type = @"rippleEffect";
        [self addAnimation:animation forKey:nil];
}
@end