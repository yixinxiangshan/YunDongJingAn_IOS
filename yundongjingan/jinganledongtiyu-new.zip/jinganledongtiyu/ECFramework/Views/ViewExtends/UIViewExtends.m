//
//  UIViewExtends.m
//  ECViews
//
//  Created by Alix on 9/27/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "UIViewExtends.h"
#import <Foundation/Foundation.h>

/**
 * 基本的动画时间
 */
#define kECBasicAnimationsDuration .3f

@implementation UIView (Frame)

- (CGFloat)top{
    return self.frame.origin.y;
}

- (CGFloat)left{
    return self.frame.origin.x;
}

- (void)setOriginX:(CGFloat)x{
    self.frame = CGRectMake(x, self.frame.origin.y, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
}

- (void)setOriginY:(CGFloat)y{
    self.frame = CGRectMake(self.frame.origin.x, y, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
}

- (void)setOriginX:(CGFloat)x Y:(CGFloat)y{
    self.frame = CGRectMake(x, y, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
}
- (void)setWidth:(CGFloat)width{
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, width, CGRectGetHeight(self.frame));
}
- (void)setHeight:(CGFloat)height{
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, CGRectGetWidth(self.frame), height);
}
- (void)setWidth:(CGFloat)width heignt:(CGFloat)heignt{
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, width, heignt);
}

- (CGPoint)getOrigin{
    return self.frame.origin;
}

- (CGFloat)getOriginX{
    return self.frame.origin.x;
}

- (CGFloat)getOriginY{
    return self.frame.origin.y;
}

- (CGFloat)getWidth{
    return CGRectGetWidth(self.frame);
}

- (CGFloat)getHeignt{
    return CGRectGetHeight(self.frame);
}

- (CGFloat)getCenterX{
    return self.center.x;
}

- (CGFloat)getCenterY{
    return self.center.y;
}

- (CGSize)getSize{
    return self.frame.size;
}
- (CGFloat)rightX{
    return (self.frame.origin.x + CGRectGetWidth(self.frame));
}

+ (CGRect)applicationFrame{
    CGRect frame =  [UIScreen mainScreen].applicationFrame;
    frame.origin = CGPointZero;
    return frame;
}
@end

#pragma mark -
@implementation UIView (View)
- (void)removeAllSubViews{
    for (UIView* view in self.subviews) {
        [view removeFromSuperview];
    }
}
@end


#pragma mark - 
@implementation UIView (Controller)
- (UIViewController*)viewController{
    for (UIView* view = self.superview; view; view = view.superview) {
        UIResponder* nextResponder = [view nextResponder];;
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController*)nextResponder;
        }
    }
    return nil;
}
@end
