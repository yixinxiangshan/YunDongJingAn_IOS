//
//  ECBadgeView.m
//  ECMuse
//
//  Created by Alix on 11/15/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import "ECBadgeView.h"
#import "Utils.h"


#define kBadgeMininumWidth      30.0f   // 最小宽度
#define kBadgeHorizontalMargins 20.0f   // 水平边缘宽度
#define kBadgeVerticalMargins   10.0f   // 竖直边缘高度
#define kBadgeLineWidth         2.0f    // 线宽

@interface ECBadgeView (private)

/**
 * 设置默认值
 */
- (void)initDefault;

@end

@implementation ECBadgeView
#pragma mark - 默认值设置
- (void)initDefault{
    self.contentScaleFactor = [UIScreen mainScreen].scale;
    // 红色背景
    if (nil == self.tintColor) {
        self.tintColor = [UIColor redColor];
    }
    // 17号系统粗体
    if (nil == self.font) {
        self.font = [UIFont boldSystemFontOfSize:17.0f];
    }
    // 白色字体
    if (nil == self.textColor) {
        self.textColor = [UIColor whiteColor];
    }
    // 0.5透明度的白色阴影
    if (nil == self.shadowColor) {
        self.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.5f];
    }
    // 阴影大小(0, 3)
    if (CGSizeEqualToSize(self.shadowOffset, CGSizeZero)) {
        self.shadowOffset = CGSizeMake(0.0f, 3.0f);
    }
    
    if (0.0 == self.shadowBlur) {
        self.shadowBlur = 3.0f;
    }
    
    _showShadow = YES;
    
    [self setBackgroundColor:[UIColor clearColor]];
}
#pragma mark - 初始化
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // 设置初始值
        [self initDefault];
    }
    return self;
}
#pragma mark - 
- (void)setShowShadow:(BOOL)showShadow{
    _showShadow = showShadow;
    [self setNeedsDisplay];
}
#pragma mark - 从nib中设置
- (void)awakeFromNib{
    [super awakeFromNib];
    
    // 设置初始值
    [self initDefault];
}

#pragma mark - 改变大小时, 要保证当前的badge大小刚好能容下文本
- (CGSize)sizeThatFits:(CGSize)size{
    CGSize badgeSize = [self.badgeValue sizeWithFont:self.font];
    // 该view最小宽度为30.0  详见#define
    // 高度为字体高度+竖直的边缘高度
    CGSize retVal = CGSizeMake(MAX(kBadgeMininumWidth, badgeSize.width+kBadgeHorizontalMargins), badgeSize.height+kBadgeVerticalMargins);
    return retVal;
}
#pragma mark - 每更改一个影响显示效果的就draw一次
- (void)setBadgeValue:(NSString *)badgeValue{
    _badgeValue = badgeValue;
    // 更新显示
    [self setNeedsDisplay];
}
- (void)setFont:(UIFont *)font{
    _font = font;
    [self setNeedsDisplay];
}
- (void)setTextColor:(UIColor *)textColor{
    _textColor = textColor;
    [self setNeedsDisplay];
}
- (void)setTintColor:(UIColor *)tintColor{
    _tintColor = tintColor;
    [self setNeedsDisplay];
}
#pragma mark - 重写draw方法
- (void)drawRect:(CGRect)rect{
    // 获取图形上下文,保存状态
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSaveGState(context);
    
    // 画背景
    CGFloat minX = CGRectGetMinX(rect) + 4.0f;
    CGFloat minY = CGRectGetMinY(rect) + 3.5f;
    CGFloat maxX = CGRectGetMaxX(rect) - 5.0f;
    CGFloat maxY = CGRectGetMaxY(rect) - 6.5f;
    // 文字占用的size
    CGSize badgeSize = [self.badgeValue sizeWithFont:self.font];
    
    // 两边的半圆 孤度
    CGFloat radius = badgeSize.height / 2.0f;
    
    // 画框 先画背景， 再画上下边， 再画弧
    CGContextBeginPath(context);
    CGContextSetFillColorWithColor(context, self.tintColor.CGColor);
    // 右
    CGContextAddArc(context, maxX-radius, minY+radius, radius, M_PI + M_PI/2.f, 0.0f, 0.0f);
    // 下
    CGContextAddArc(context, maxX-radius, maxY-radius, radius, 0.0f, M_PI/2.f, 0.0f);
    // 左
    CGContextAddArc(context, minX+radius, maxY-radius, radius, M_PI/2.f, M_PI, 0.0f);
    // 上
    CGContextAddArc(context, minX+radius, minY+radius, radius, M_PI, M_PI + M_PI/2.f, 0.0f);
    // 设置阴影颜色并填充
    CGContextSetShadowWithColor(context, self.shadowOffset, self.shadowBlur, self.shadowColor.CGColor);
    CGContextFillPath(context);
    
    CGContextRestoreGState(context);
    CGContextSaveGState(context);
    if (_showShadow == YES) {
        ECLog(@"_showShadow");
        // 画高光
        CGContextBeginPath(context);
        CGContextAddArc(context, maxX-radius, minY+radius, radius, M_PI+M_PI/2.f, 0.0f, 0.0f);
        CGContextAddArc(context, minX+radius, minY+radius, radius, M_PI, M_PI+M_PI/2.f, 0.0f);
        CGContextAddRect(context, CGRectMake(minX-kBadgeLineWidth, minY + radius-kBadgeLineWidth, CGRectGetWidth(rect) - radius + 2.0f*kBadgeLineWidth,
                                             CGRectGetMidY(rect)+radius+kBadgeLineWidth*2.0f));
        CGContextClip(context);
        
        //  shadow
        CGFloat locations[] = { 0.0f, 1.0f };    // 类似于纸张的左下角和右上角
        CGFloat components[] = {
            1.f, 1.f, 1.f, 0.8f,    // 颜色1 有点灰
            1.f, 1.f, 1.f, 0.0f };  // 白色透明
        
        CGColorSpaceRef cspace;
        CGGradientRef gradient;
        cspace = CGColorSpaceCreateDeviceRGB();
        gradient = CGGradientCreateWithColorComponents (cspace, components, locations, 2);
        
        CGPoint sPoint, ePoint;
        sPoint.x = 0.0f;
        sPoint.y = 4.0f;
        ePoint.x = 0.0f;
        ePoint.y = CGRectGetMidY(rect) - 2.0f;
        CGContextDrawLinearGradient (context, gradient, sPoint, ePoint, 0.0f);
        
        CGColorSpaceRelease(cspace);
        CGGradientRelease(gradient);
    }
    
    CGContextRestoreGState(context);
    CGContextSaveGState(context);
    
    // 画边框
    CGContextBeginPath(context);
    CGContextSetLineWidth(context, kBadgeLineWidth);
    CGContextSetStrokeColorWithColor(context, [[UIColor whiteColor] CGColor]);
    // 右
    CGContextAddArc(context, maxX-radius, minY+radius, radius, M_PI + M_PI/2.f, 0.0f, 0.0f);
    // 下
    CGContextAddArc(context, maxX-radius, maxY-radius, radius, 0.0f, M_PI/2.f, 0.0f);
    // 左
    CGContextAddArc(context, minX+radius, maxY-radius, radius, M_PI/2.f, M_PI, 0.0f);
    // 上
    CGContextAddArc(context, minX+radius, minY+radius, radius, M_PI, M_PI + M_PI/2.f, 0.0f);
    CGContextClosePath(context);
    CGContextStrokePath(context);
    
    // 画文字
    [self.textColor set];
    CGPoint badgePoint = CGPointMake((CGRectGetWidth(rect)-badgeSize.width)*0.5f, (CGRectGetHeight(rect)-badgeSize.height)*0.5f - kBadgeLineWidth );
    [self.badgeValue drawAtPoint:badgePoint withFont:self.font];
    
    // 恢复
    CGContextRestoreGState(context);
}
@end
