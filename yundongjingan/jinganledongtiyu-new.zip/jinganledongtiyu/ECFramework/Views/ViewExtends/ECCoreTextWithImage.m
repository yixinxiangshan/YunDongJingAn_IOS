//
//  ECCoreTextWithImage.m
//  ECMuse
//
//  Created by Alix on 11/23/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import "ECCoreTextWithImage.h"
#import "Extends.h"

@implementation ECCoreTextWithImage

@end
