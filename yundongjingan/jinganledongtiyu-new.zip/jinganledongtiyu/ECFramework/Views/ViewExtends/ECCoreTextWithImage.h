//
//  ECCoreTextWithImage.h
//  ECMuse
//
//  Created by Alix on 11/23/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import "ECRootView.h"
#import "CoreTextView.h"
#import "ECImageContainer.h"
/**
 * 图片类
 */
//@interface ImageDescription : NSObject
//@property (nonatomic, strong) NSString* description; // 图片描述
//@property (nonatomic, strong) NSString* uri;         // 图片地址
//@end

@interface ECCoreTextWithImage : ECRootView <ECImageContainerDelegate>{
    
}
//@property (nonatomic, strong) NSArray* images;  // 图片数组
//
///**
// * 字体
// */
//- (UIFont*)font;
//- (void)setFont:(UIFont*)font;
///**
// * 颜色
// */
//- (UIColor*)color;
//- (void)setColor:(UIColor*)color;
//
///**
// * 文本
// */
//- (NSString*)text;
//- (void)setText:(NSString*)text;
//
//- (id)initWithFrame:(CGRect)frame imageContainerHeight:(CGFloat)imageContainerHeight;
@end
