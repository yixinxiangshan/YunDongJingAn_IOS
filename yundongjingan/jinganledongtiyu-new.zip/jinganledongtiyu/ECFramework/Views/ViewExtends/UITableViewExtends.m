//
//  UITableViewExtends.m
//  ECViews
//
//  Created by Alix on 9/28/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "UITableViewExtends.h"
#import "UIWindowExtends.h"

@implementation UIScrollView (Extends)
#pragma mark - 
- (void)scrollToTop:(BOOL)animated{
    [self setContentOffset:CGPointZero animated:animated];
}
@end

@implementation UITableView (Extends)

#pragma mark - 
- (void)scrollToBottom:(BOOL)animated{
    NSUInteger sections = [self numberOfSections];
    if (sections > 0) {
        NSUInteger rows = [self numberOfRowsInSection:0];
        if (rows) {
            NSUInteger ii[2] = {0, rows -1};
            NSIndexPath* indexPath = [NSIndexPath indexPathWithIndexes:ii length:2];
            
            [self scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:animated];
        }
    }
}

#pragma mark - 
- (void)scrollToFirstRow:(BOOL)animated{
    if ([self numberOfSections]) {
        if ([self numberOfRowsInSection:0]) {
            NSIndexPath* indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
            [self scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:animated];
        }
    }
}

#pragma mark - 
- (void)scrollToLastRow:(BOOL)animated{
    NSInteger sections = [self numberOfSections]-1;
    if (sections >= 0) {
        NSUInteger rows = [self numberOfRowsInSection:sections];
        if (rows) {
            NSUInteger ii[2] = {0, rows -1};
            NSIndexPath* indexPath = [NSIndexPath indexPathWithIndexes:ii length:2];
            
            [self scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:animated];
        }
    }
}

@end