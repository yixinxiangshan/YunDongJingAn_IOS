//
//  UIWindowExtends.h
//  ECViews
//
//  Created by Alix on 9/27/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWindow (Extends)

/**
 * 找到第1个响应视图
 */
- (UIView*)findFirstResponder;

/**
 * 找到某个视图的第1响应视图
 */
- (UIView*)findFirstResponderInView:(UIView*)view;
@end
