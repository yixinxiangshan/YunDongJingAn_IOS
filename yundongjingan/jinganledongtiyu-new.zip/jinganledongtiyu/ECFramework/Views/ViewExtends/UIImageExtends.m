//
//  UIImageExtends.m
//  ECMuse
//
//  Created by Alix on 11/29/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import "UIImageExtends.h"
#import "Extends.h"
#import "ECViews.h"
#import "Utils.h"

@implementation UIImage (Extends)

- (UIImage*)imageInRect:(CGRect)rect{
    CGImageRef ref = CGImageCreateWithImageInRect(self.CGImage, rect);
    UIImage* retImage = [UIImage imageWithCGImage:ref];
    CFRelease((__bridge CFTypeRef)(retImage));
    
    return retImage;
}
#pragma mark -
- (NSData*)imageDataFromBottomLeftPoint:(CGPoint)bl
                       bottomRightPoint:(CGPoint)br
                          topRightPoint:(CGPoint)tr
                                topLeft:(CGPoint)tl;{
    CGSize size = self.size;
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(NULL, size.width, size.height, 8, 4 * size.width, colorSpace, kCGImageAlphaPremultipliedFirst);
    CGRect rect = CGRectMake(0, 0, size.width, size.height);
    CGColorRef fillColor = [[UIColor whiteColor] CGColor];
    CGContextSetFillColor(context, CGColorGetComponents(fillColor));
    
    CGContextMoveToPoint(context, bl.x, bl.y);
    CGContextAddLineToPoint(context, br.x, br.y);
    CGContextAddLineToPoint(context, tr.x, tr.y);
    CGContextAddLineToPoint(context, tl.x, tl.y);
    CGContextAddLineToPoint(context, bl.x, bl.y);
    CGContextClosePath(context);
    CGContextClip(context);
    
    CGContextDrawImage(context, rect, self.CGImage);
    
    
    CGContextTranslateCTM(context, 0, size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    
    CGImageRef imageMasked = CGBitmapContextCreateImage(context);
    CGContextRelease(context);
    UIImage *newImage = [UIImage imageWithCGImage:imageMasked];
    CGImageRelease(imageMasked);
    
    return UIImagePNGRepresentation(newImage);
}

#pragma mark - 
+ (UIImage*)ecImageNamed:(NSString *)name{
    NSString* imagePath = [self pathForResource:name];
    if (imagePath && [[NSFileManager defaultManager] fileExistsAtPath:imagePath]) {
        ECLog(@"imagePath:%@", imagePath);
        NSData* data = [NSData dataWithContentsOfFile:imagePath];
        if (data) {
            UIImage* image = [UIImage imageWithData:data scale:[UIScreen mainScreen].scale];
            if (image) {
                return image;
            }
        }
    }
    return nil;
}

+ (NSString*)pathForResource:(NSString*)resourceName{
    NSString* fileName = [resourceName stringByDeletingPathExtension];
    NSString* extendsName = [resourceName pathExtension];
    if (!fileName) {
        return nil;
    }
    if ([UIDevice isIPhone5]) {
        if (fileName && ![fileName hasSuffix:@"568h@2x"]) {
            fileName = [NSString stringWithFormat:@"%@568h@2x",fileName];
        }
        NSString* path = [[NSBundle mainBundle] pathForResource:fileName ofType:extendsName];
        if(path && [[NSFileManager defaultManager] fileExistsAtPath:path]){
            return path;
        }
    }
    if ([UIDevice isRetina]) {
        if (fileName && ![fileName hasSuffix:@"@2x"]) {
            fileName = [NSString stringWithFormat:@"%@@2x",fileName];
        }
        NSString* path = [[NSBundle mainBundle] pathForResource:fileName ofType:extendsName];
        if(path && [[NSFileManager defaultManager] fileExistsAtPath:path]){
            return path;
        }
    }
    return [[NSBundle mainBundle] pathForResource:resourceName ofType:nil];
}
@end
