//
//  UITableViewExtends.h
//  ECViews
//
//  Created by Alix on 9/28/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UIScrollView (Extends)

/**
 * 移动到原点
 */
- (void)scrollToTop:(BOOL)animated;
@end

@interface UITableView (Extends)

/**
 * 移动到最下面1行
 */
- (void)scrollToLastRow:(BOOL)animated;

/**
 * 移动到首行
 */
- (void)scrollToFirstRow:(BOOL)animated;

/**
 * 移动到下面
 */
- (void)scrollToBottom:(BOOL)animated;

@end
