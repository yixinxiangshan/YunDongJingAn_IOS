//
//  UIWebViewExtends.h
//  ECViews
//
//  Created by Alix on 9/28/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//  three20

#import <UIKit/UIKit.h>

@interface UIWebView (Extends)
/**
 * Gets the frame of a DOM element in the page.
 *
 * @query A JavaScript expression that evaluates to a single DOM element.
 */
- (CGRect)frameOfElement:(NSString*)query;

@end
