//
//  UINavigationBarExtends.h
//  ECViews
//
//  Created by Alix on 9/29/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 * 有关Title的字体属性设置
 * @notice 
 */
@interface UINavigationBar (Extends)
@property (nonatomic, strong, readwrite) UIFont*    titleFont  NS_AVAILABLE_IOS(5_0) UI_APPEARANCE_SELECTOR;  // 标题字体
@property (nonatomic, strong, readwrite) UIColor*   titleColor NS_AVAILABLE_IOS(5_0) UI_APPEARANCE_SELECTOR; // 标题颜色
@property (nonatomic, strong, readwrite) UIColor*   titleShadowColor NS_AVAILABLE_IOS(5_0) UI_APPEARANCE_SELECTOR;   // 阴影字体
@property (nonatomic, assign, readwrite) UIOffset   titleShadowOffset NS_AVAILABLE_IOS(5_0) UI_APPEARANCE_SELECTOR;  // 阴影大小
@end
