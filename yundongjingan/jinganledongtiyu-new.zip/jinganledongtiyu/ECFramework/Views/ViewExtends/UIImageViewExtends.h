//
//  UIImageViewExtends.h
//  ECViews
//
//  Created by Alix on 9/29/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (Extends)

/**
 * @return 指定图片的imageView
 * @param image  
 *      显示的图片
 * @param hightlightedIamge  
 *      高亮时图片
 */
+ (id)imageviewWithImage:(UIImage*)image;
+ (id)imageviewWithImage:(UIImage *)image hightlightedImage:(UIImage*)hightlightedImage;

/**
 * @return 指定图片名称的imageView 图片要在本地存在
 * @param imageName  
 *      正常状态下的图片名称
 */
+ (id)imageviewWithImageName:(NSString*)imageName;
/**
 * @return 指定图片名称的imageView 图片要在本地存在
 * @param imageName  
 *      正常状态下的图片名称
 * @param hightlightedName  
 *      高亮时的图片名称
 */
+ (id)imageviewWithImageName:(NSString*)imageName hightlightedName:(NSString*)hightlightedName;

/**
 * @return 用图片名称初始化的imageView
 * @param imageName  
 *      正常时图片名称
 */
- (id)initWithImageName:(NSString*)imagename;
/**
 * @return 用图片名称初始化的imageView
 * @param imageName  
 *      正常时图片名称
 * @param hightlightedName  
 *      高亮时图片名称
 */
- (id)initWithImageName:(NSString *)imagename hightlightedName:(NSString*)hightlightedName;

/**
 * @return 指定填充图片数据的imageView
 * @param imageData  
 *      正常时图片data
 */
+ (id)imageviewWithImageData:(NSData*)imageData;
/**
 * @return 指定填充图片数据的imageView
 * @param imageData  
 *      正常时图片data
 * @param hightlightData  
 *      高亮时图片data
 */
+ (id)imageviewWithImageData:(NSData *)imageData hightlightedData:(NSData*)hightlightedData;

/**
 * @return 指定图片数据初始化
 * @param imageData  
 *      正常时图片data
 */
- (id)initWithImageData:(NSData*)imageData;
/**
 * @return 指定图片数据初始化
 * @param imageData  
 *      正常时图片data
 * @param hightlightedData  
 *      高亮时图片data
 */
- (id)initWithImageData:(NSData *)imageData hightlightedData:(NSData*)hightlightedData;
/**
 * 设置图片并设置圆角
 */
- (void)setImage:(UIImage *)image cornerRadius:(CGFloat)radius;
/**
 * 设置圆角
 */
- (void)setRoundCorners:(CGFloat)radius;
@end
