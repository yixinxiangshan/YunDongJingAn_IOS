//
//  UINavigationController+Category.m
//  QCRL_NEW
//
//  Created by Guanglu Kang on 6/2/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import "UINavigationController+Category.h"
#import "UIColorExtends.h"

@implementation UINavigationBar (UINavigationBarCategory)

- (UIImage *)barBackground{
    return [UIImage imageNamed:kUINavigationBarImage];  
}  

- (void)didMoveToSuperview{  
    //iOS5 only  
    if ([self respondsToSelector:@selector(setBackgroundImage:forBarMetrics:)] && kUINavigationBarImage && kUINavigationBarImage.length){
        [self setBackgroundImage:[self barBackground] forBarMetrics:UIBarMetricsDefault];  
    }  
}  

//this doesn't work on iOS5 but is needed for iOS4 and earlier  
- (void)drawRect:(CGRect)rect{
    if ([[UIDevice currentDevice].systemVersion floatValue] < 5.0) {
        [[self barBackground] drawInRect:rect];  
    }
}

@end

#pragma mark - 
@implementation UINavigationController (Rotate)
- (BOOL)shouldAutorotate{
    if ([self.viewControllers count]) {
        return [self.visibleViewController shouldAutorotate];
    }
    return NO;
}
- (NSUInteger)supportedInterfaceOrientations{
    if ([self.viewControllers count]) {
        return [self.visibleViewController supportedInterfaceOrientations];
    }
    return UIInterfaceOrientationMaskAll;
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if (!kUINavigationBarImage|| (kUINavigationBarImage.length < 5 && [[UIDevice currentDevice].systemVersion floatValue] >= 5.0)) {
            [self.navigationBar setTintColor:[UIColor colorWithHex:0x275575]];
    }
}
@end