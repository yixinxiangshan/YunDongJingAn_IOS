//
//  UINavigationController+Category.h
//  QCRL_NEW
//
//  Created by Guanglu Kang on 6/2/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>
// UINavigationBar 背景图片
#define kUINavigationBarImage   @"maintitle.png"

@interface UINavigationBar (UINavigationBarCategory)
@end

#pragma mark - 方向问题
@interface UINavigationController (Rotate)
@end
