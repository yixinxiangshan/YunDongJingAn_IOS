//
//  ECMultiScrollView.h
//  ECViews
//
//  Created by Alix on 10/8/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 * 1个scrollView上显示多个视图
 * scrollView上有3个视图(在划动的时候修改3个视图的center&&内容) 
 */

typedef enum tagECMultiScrollViewDirection : NSUInteger{
    eMutileScrollviewLeftRight = 0,
    eMutileScrollviewUpDown
}ECMutiScrollViewDirection;

@class ECMultiScrollView;

@protocol ECMultiScrollViewDataSource <NSObject>

@required
- (NSUInteger)numberOfPagesinMultiScrollview:(ECMultiScrollView*)multiScrollView;

@required
- (UIView*)viewInMultiScrollview:(ECMultiScrollView*)multiScrollView atIndex:(NSInteger)index;

@end


@interface ECMultiScrollView : UIView {
@private
    NSInteger _currentPageIndex;   // 当前显示的是第几页
    UISwipeGestureRecognizerDirection _swipeDirection;
    UIPageControl* _pageControl;    // 分页控件
}
@property (nonatomic, strong, readonly) UIView*       previousView;   // 上一页
@property (nonatomic, strong, readonly) UIView*       currentView;    // 当前页
@property (nonatomic, strong, readonly) UIView*       nextView;       // 下一页
@property (nonatomic, assign) ECMutiScrollViewDirection direction;    // 滑动的方向(只能选其中的1种)
@property (nonatomic, assign, readwrite) id<ECMultiScrollViewDataSource> datasource;
@property (nonatomic, assign, readwrite) BOOL showPageControl;      // 是否显示分页控件

/**
 * 修改视图的背景颜色
 * @param color 要设置的背景色
 */
- (void)setContentViewBackground:(UIColor*)color;

/**
 * 初始化
 * @param frame 大小
 * @param direction 滑动方向
 */
- (id)initWithFrame:(CGRect)frame direction:(ECMutiScrollViewDirection)direction;

/**
 * 重新加载数据
 */
- (void)reloadData;
@end
