//
//  ECCloseView.m
//  ECMuse
//
//  Created by Alix on 10/25/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import "ECCloseView.h"
#import <QuartzCore/QuartzCore.h>
#import "UIViewExtends.h"

static CGFloat  kBorderGray[4] = { 0.3f, 0.3f, 0.3f, 0.8f};  // 边框颜色1
static CGFloat  kBorderWhite[4] = { 1.0f, 1.0f, 1.0f, 1.0f}; // 边框颜色2
#define kTransitionDuration  0.3f    // 动画时长
#define kPadding 0.0f    // 四周白色边距
#define kEdgeBorderWidth 10.0f // 四周宽度
#define kLineWidth  1.0f    // 线宽
#define kCornerRadius   8.0f    // 圆角



@interface ECCloseView ()
- (void)addRoundedRectToPath:(CGContextRef)context rect:(CGRect)rect radius:(float)radius;

- (void)drawRect:(CGRect)rect fill:(const CGFloat*)fillColors radius:(CGFloat)radius;

- (void)strokeLines:(CGRect)rect stroke:(const CGFloat*)strokeColor;


- (CGAffineTransform)transformForOrientation;

- (void)sizeToFitOrientation:(BOOL)transform;

@end

@implementation ECCloseView

#pragma mark - Drawing

- (void)addRoundedRectToPath:(CGContextRef)context rect:(CGRect)rect radius:(float)radius
{
    CGContextBeginPath(context);
    CGContextSaveGState(context);
    
    if (radius == 0)
    {
        CGContextTranslateCTM(context, CGRectGetMinX(rect), CGRectGetMinY(rect));
        CGContextAddRect(context, rect);
    }
    else
    {
        rect = CGRectOffset(CGRectInset(rect, 0.5, 0.5), 0.5, 0.5);
        CGContextTranslateCTM(context, CGRectGetMinX(rect)-0.5, CGRectGetMinY(rect)-0.5);
        CGContextScaleCTM(context, radius, radius);
        float fw = CGRectGetWidth(rect) / radius;
        float fh = CGRectGetHeight(rect) / radius;
        
        CGContextMoveToPoint(context, fw, fh/2);
        CGContextAddArcToPoint(context, fw, fh, fw/2, fh, 1);
        CGContextAddArcToPoint(context, 0, fh, 0, fh/2, 1);
        CGContextAddArcToPoint(context, 0, 0, fw/2, 0, 1);
        CGContextAddArcToPoint(context, fw, 0, fw, fh/2, 1);
    }
    
    CGContextClosePath(context);
    CGContextRestoreGState(context);
}

- (void)drawRect:(CGRect)rect fill:(const CGFloat*)fillColors radius:(CGFloat)radius
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
    
    if (fillColors)
    {
        CGContextSaveGState(context);
        CGContextSetFillColor(context, fillColors);
        if (radius)
        {
            [self addRoundedRectToPath:context rect:rect radius:radius];
            CGContextFillPath(context);
        }
        else
        {
            CGContextFillRect(context, rect);
        }
        CGContextRestoreGState(context);
    }
    
    CGColorSpaceRelease(space);
}

- (void)strokeLines:(CGRect)rect stroke:(const CGFloat*)strokeColor
{
    if (_lineWidth < 1.0f) {
        return;
    }
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
    
    CGContextSaveGState(context);
    CGContextSetStrokeColorSpace(context, space);
    CGContextSetStrokeColor(context, strokeColor);
    CGContextSetLineWidth(context, _lineWidth);
    
    {
        CGPoint points[] = {{rect.origin.x+0.5, rect.origin.y-0.5},
            {rect.origin.x+rect.size.width, rect.origin.y-0.5}};
        CGContextStrokeLineSegments(context, points, 2);
    }
    {
        CGPoint points[] = {{rect.origin.x+0.5, rect.origin.y+rect.size.height-0.5},
            {rect.origin.x+rect.size.width-0.5, rect.origin.y+rect.size.height-0.5}};
        CGContextStrokeLineSegments(context, points, 2);
    }
    {
        CGPoint points[] = {{rect.origin.x+rect.size.width-0.5, rect.origin.y},
            {rect.origin.x+rect.size.width-0.5, rect.origin.y+rect.size.height}};
        CGContextStrokeLineSegments(context, points, 2);
    }
    {
        CGPoint points[] = {{rect.origin.x+0.5, rect.origin.y},
            {rect.origin.x+0.5, rect.origin.y+rect.size.height}};
        CGContextStrokeLineSegments(context, points, 2);
    }
    
    CGContextRestoreGState(context);
    
    CGColorSpaceRelease(space);
}

- (void)drawRect:(CGRect)rect
{
    [self drawRect:rect fill:kBorderGray radius:kCornerRadius];
    CGRect rect2 = _contentView.frame;
    CGRect contentRect = CGRectMake(
                                ceil(rect2.origin.x-kLineWidth), ceil(rect2.origin.y-kLineWidth),
                                rect2.size.width+kLineWidth*2, rect2.size.height+(kLineWidth*2));
    
    [self strokeLines:contentRect stroke:kBorderWhite];
}
#pragma mark - Initial
- (id)init{
    self = [super init];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.autoresizesSubviews = YES;
        self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        self.contentMode = UIViewContentModeRedraw;
       
        self.layer.cornerRadius = kCornerRadius;
        
        _edgeWidth = kEdgeBorderWidth;
        _padding = kPadding;
        _lineWidth = kLineWidth;

        UIImage* closeImage = [UIImage imageNamed:@"ECloudIOT.bundle/Images/close.png"];
        UIColor* color = [UIColor colorWithRed:167.0/255 green:184.0/255 blue:216.0/255 alpha:1];
        _closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_closeButton setImage:closeImage forState:UIControlStateNormal];
        [_closeButton setTitleColor:color forState:UIControlStateNormal];
        [_closeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
        [_closeButton addTarget:self action:@selector(cancel)
              forControlEvents:UIControlEventTouchUpInside];
        _closeButton.titleLabel.font = [UIFont boldSystemFontOfSize:12];
        _closeButton.showsTouchWhenHighlighted = YES;
        _closeButton.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleBottomMargin;
        [self addSubview:_closeButton];
        
        _modalBackgroundView = [[UIView alloc] init];
        return self;
    }
    return nil;
}
#pragma mark - dealloc
- (void)dealloc{
//    [_modalBackgroundView release],
    _modalBackgroundView = nil;
//    [super dealloc];
}

- (CGAffineTransform)transformForOrientation
{
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    if (orientation == UIInterfaceOrientationLandscapeLeft)
    {
        return CGAffineTransformMakeRotation(M_PI*1.5);
    }
    else if (orientation == UIInterfaceOrientationLandscapeRight)
    {
        return CGAffineTransformMakeRotation(M_PI/2);
    }
    else if (orientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        return CGAffineTransformMakeRotation(-M_PI);
    }
    else
    {
        return CGAffineTransformIdentity;
    }
}
#pragma mark - UIDeviceOrientationDidChangeNotification Methods

- (void)sizeToFitOrientation:(BOOL)transform
{
    if (transform)
    {
        self.transform = CGAffineTransformIdentity;
    }
    
    CGRect frame = [UIScreen mainScreen].applicationFrame;
    CGPoint center = CGPointMake(frame.origin.x + ceil(frame.size.width/2),
                                 frame.origin.y + ceil(frame.size.height/2));
    
    CGFloat scaleFactor = (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) ? 0.6f : 1.0f;
    
    CGFloat width = floor(scaleFactor * frame.size.width) - _padding * 2;
    CGFloat height = floor(scaleFactor * frame.size.height) - _padding * 2;
    
    self.frame = CGRectMake(_padding, _padding, width, height);
    self.center = center;
    
    if (transform)
    {
        self.transform = [self transformForOrientation];
    }
}
#pragma mark - Observers
#pragma mark - Animation

- (void)bounce1AnimationStopped
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:kTransitionDuration/2];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(bounce2AnimationStopped)];
    self.transform = CGAffineTransformScale([self transformForOrientation], 0.9, 0.9);
    [UIView commitAnimations];
}

- (void)bounce2AnimationStopped
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:kTransitionDuration/2];
    self.transform = [self transformForOrientation];
    [UIView commitAnimations];
}

#pragma mark Obeservers

- (void)show
{
    [self sizeToFitOrientation:NO];
    
    [_closeButton sizeToFit];
    
    UIWindow* window = [UIApplication sharedApplication].keyWindow;
    if (!window)
    {
        window = [[UIApplication sharedApplication].windows objectAtIndex:0];
    }
    _modalBackgroundView.frame = window.frame;
    [_modalBackgroundView addSubview:self];
    [window addSubview:_modalBackgroundView];
//    // 按钮放右边
//    _closeButton.frame = CGRectMake(CGRectGetWidth(self.frame)-CGRectGetWidth(_closeButton.frame)-1, 1, CGRectGetWidth(_closeButton.frame), CGRectGetHeight(_closeButton.frame));
    
    if (kEdgeBorderWidth < _edgeWidth  && _edgeWidth > CGRectGetHeight(_closeButton.frame)*0.5f && _lineWidth >= 1.0f) {
        // 重心设置中心点
        CGFloat x = self.frame.size.width-_edgeWidth;
        CGFloat y = _edgeWidth;
        [_closeButton setCenter:CGPointMake(x, y)];
    } else {
        [_closeButton setCenter:CGPointMake([_contentView rightX], _contentView.top+_contentView.layer.cornerRadius*0.25f)];
    }
    
    self.transform = CGAffineTransformScale([self transformForOrientation], 0.001, 0.001);
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:kTransitionDuration/1.5];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(bounce1AnimationStopped)];
    self.transform = CGAffineTransformScale([self transformForOrientation], 1.1, 1.1);
    [UIView commitAnimations];
}

- (void)_hide
{
    if (_delegate && [_delegate respondsToSelector:@selector(ecCloseViewWasClosed:)]) {
        [_delegate ecCloseViewWasClosed:self];
    }
    [self removeFromSuperview];
    [_modalBackgroundView removeFromSuperview];
    
}

- (void)hide
{
    
    [self performSelectorOnMainThread:@selector(_hide) withObject:nil waitUntilDone:NO];
}

- (void)cancel
{
    [self hide];
}
#pragma mark - 
- (void)addSubview:(UIView *)view{
    [super addSubview:view];
    // 关闭按钮移到中前面
    [self bringSubviewToFront:_closeButton];
    _contentView = view;
    // 视图左右居中, y中心点在padding+线上面的高度+线的高度+视图高度的1半
    UIWindow* window = [UIApplication sharedApplication].keyWindow;
    if (!window)
    {
        window = [[UIApplication sharedApplication].windows objectAtIndex:0];
    }
    CGSize size = window.bounds.size;
    if ((size.height - 100) > CGRectGetHeight(view.frame)) {
        [view setCenter:CGPointMake(size.width*0.5f, CGRectGetHeight(view.frame)*0.5f + 70.0f)];
    } else {
        [view setCenter:CGPointMake(size.width*0.5f, CGRectGetHeight(view.frame)*0.5f + 30.0f)];
    }

}
#pragma mark - 忽略底层事件 
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{}
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{}
- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event{}
@end
