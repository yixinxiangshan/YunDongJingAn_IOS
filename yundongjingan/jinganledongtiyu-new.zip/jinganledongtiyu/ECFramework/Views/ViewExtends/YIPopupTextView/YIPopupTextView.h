//
//  YIPopupTextView.h
//  YIPopupTextView
//
//  Created by Yasuhiro Inami on 12/02/01.
//  Copyright (c) 2012 Yasuhiro Inami. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@class SSTextView;
@class YIPopupTextView;

@protocol YIPopupTextViewDelegate <UITextViewDelegate>
@optional
- (void)popupTextView:(YIPopupTextView*)textView willDismissWithText:(NSString*)text;
- (void)popupTextView:(YIPopupTextView*)textView didDismissWithText:(NSString*)text;
@end

/**
 @brief UITextView subclass that adds placeholder support like
 UITextField has.
 */
@interface SSTextView : UITextView {
	
@private
	
	NSString *_placeholder;
	UIColor *_placeholderColor;

	BOOL _shouldDrawPlaceholder;
}

/**
 @brief The string that is displayed when there is no other text in the text view.
 
 The default value is nil.
 */
@property (nonatomic, retain) NSString *placeholder;

/**
 @brief The color of the placeholder.
 
 The default is [UIColor lightGrayColor].
 */
@property (nonatomic, retain) UIColor *placeholderColor;

@end

@interface YIPopupTextView : SSTextView

@property (nonatomic, assign) id <YIPopupTextViewDelegate> delegate;
@property (nonatomic, assign) BOOL showCloseButton;             // default = YES
@property (nonatomic, assign) BOOL caretShiftGestureEnabled;    // default = NO

- (id)initWithPlaceHolder:(NSString*)placeHolder maxCount:(NSUInteger)maxCount;
- (void)showInView:(UIView*)view;
- (void)dismiss;

@end

