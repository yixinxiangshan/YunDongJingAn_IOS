//
//  CoreTextView.h
//  ECMuse
//
//  Created by Alix on 11/21/12.
//  Copyright (c) 2012 ECloudSuperman. All rights reserved.
//

#import "ECRootView.h"
@protocol CoreTextViewDelegate;
@interface CoreTextView : ECRootView
@property (nonatomic, strong) NSString* text;   // 要显示的字符串
@property (nonatomic, assign) CGFloat   characterSpacing;   // 字间距
@property (nonatomic, assign) CGFloat   linesSapcing;       // 行间距
@property (nonatomic, strong) UIFont*   font;               // 字体
@property (nonatomic, strong) UIColor*  color;              // 文字颜色
@property (nonatomic, assign) UITextAlignment textAlignment;    // 对齐方式
@property (nonatomic, assign) id<CoreTextViewDelegate>delegate;
@end

@protocol CoreTextViewDelegate <NSObject>

@optional
/**
 * frame 改变后事件
 */
- (void)CoreTextViewFrameWasChanged:(CoreTextView*)coreTextView;
@end
