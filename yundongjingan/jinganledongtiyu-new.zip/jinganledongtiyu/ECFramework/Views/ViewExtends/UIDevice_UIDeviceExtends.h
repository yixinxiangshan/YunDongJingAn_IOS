//
//  UIDevice_UIDeviceExtends.h
//  HealthyClub
//
//  Created by Alix on 1/30/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIDevice (Extends)
// 是否高清
+ (BOOL)isRetina;
// 是否i5
+ (BOOL)isIPhone5;
@end
