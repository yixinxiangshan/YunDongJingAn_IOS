//
//  CALayerExtends.h
//  ECViews
//
//  Created by Alix on 9/28/12.
//  Copyright (c) 2012 ecloud. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>

@interface CALayer (Extends)

/**
 * 设置1个tag值
 */
- (void)setTag:(NSInteger)tag;

/**
 * 根据tag值获取Layer
 */
- (CALayer*)layerWithTag:(NSInteger)tag;
@end


@interface CALayer (Debug)

/**
 * 调试信息 : 输出Class/name/frame/bounds/anchor
 */
- (NSString*)debugDescription;

@end


#pragma mark - 
@interface CALayer (Frame)
@property (nonatomic, assign, readwrite) CGPoint frameOrigin;   // 左上角
@property (nonatomic, assign, readwrite) CGFloat frameTop;      // 上边距
@property (nonatomic, assign, readwrite) CGFloat frameLeft;     // 左边距
@property (nonatomic, assign, readwrite) CGFloat frameWidth;    // 宽
@property (nonatomic, assign, readwrite) CGFloat frameHeight;   // 高


@property (nonatomic, assign, readwrite) CGFloat midX;
@property (nonatomic, assign, readonly) CGFloat rightX;

@end


#pragma mark - 
@interface CALayer (Layer)

/**
 * 根据frame大小创建layer
 */
+ (id)layerWithFrame:(CGRect)frame;
- (id)initWithFrame:(CGRect)frame;

@end


#pragma mark - 
/**
 * 动画相关
 */
@interface CALayer (Animation)

/**
 * 默认渐变动画
 */
- (void)addFadeTransition;

/**
 * 指定动画时间的渐变动画
 * @param duration : 动画持续时长
 */
- (void)addFadeTransitionWithDuration:(NSTimeInterval)duration;

/**
 * moveIn动画
 * @param subtype : 动画子类型, 上下左右
 * @param duration : 动画持续时间
 */
- (void)addMoveInTransitionWithSubtype:(NSString*)subType;
- (void)addMoveInTransitionWithSubtype:(NSString *)subType duration:(NSTimeInterval)duration;


/**
 * push动画
 * @param subtype : 动画子类型
 * @param duration : 动画持续时间
 */
- (void)addPushTransitionWithSubtype:(NSString*)subtype;
- (void)addPushTransitionWithSubtype:(NSString *)subtype duration:(NSTimeInterval)duration;

/**
 * reveal动画
 * @param subtype : 动画子类型
 * @param duration : 动画持续时间
 */
- (void)addRevealTransitionWithSubtype:(NSString*)subtype;
- (void)addRevealTransitionWithSubtype:(NSString *)subtype duration:(NSTimeInterval)duration;

/**
 * 添加1个动画
 * @param animation :   动画
 */
- (void)addAnimation:(CAAnimation *)anim;

/**
 * 水波动画
 */
- (void)addRippleTransition;
- (void)addRippleTransitionWithDuration:(NSTimeInterval)duration;

/**
 * 添加1个动画
 * @param animation : animation 
 * @param key  : key
 * @param startBlock : 开始时函式
 * @param stopBlock : 结束时函数
 */
- (void)addAnimation:(CAAnimation *)anim forKey:(NSString *)key stopBlock:(void(^)(BOOL finished))stopBlock;
- (void)addAnimation:(CAAnimation *)anim forKey:(NSString *)key startBlock:(void(^)(void))startBlock stopBlock:(void (^)(BOOL))stopBlock;
@end