//
//  ECAccountController.m
//  JingAnWeekly
//
//  Created by EC on 3/26/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECAccountController.h"

@interface ECAccountController ()

@end

@implementation ECAccountController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showContentView) name:@"logoutCmd.logoutSuccess" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showContentView) name:@"ECLoginController.loginSuccess" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getUserInfo) name:@"userInfo.refreshUserPoint" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getAccessToken) name:@"getAccessToken" object:nil];
    
    [super viewDidLoad];
    [self showContentView];
//    [self getUserInfo];
    
}

- (void) viewWillAppear:(BOOL)animated{
    
}

- (void)handleRequestData:(NSData*)data{
    [super handleRequestData:data];
    if (nil != self.dataDic && nil != [self.dataDic objectForKey:@"dataList"] && [[self.dataDic objectForKey:@"dataList"] isNSxxxClass:[NSArray class]]) {
        _tableDataSource = [NSMutableArray arrayWithArray:[self.dataDic objectForKey:@"dataList"]];
    }
}
# pragma mark - 获取用户信息
- (void) getUserInfo{
    if (_isLogin) {
        //获取用户信息
        //网络数据
        if (nil != [self.query objectForKey:@"requestId"]) {
            self.requestId = [self.query objectForKey:@"requestId"];
        }
        
        NSDictionary* netDataRelevant = [self.configs objectForKey:@"netDataRelevant"];
        if (nil != [netDataRelevant objectForKey:@"requestId"] && ![@"" isEqualToString:[netDataRelevant objectForKey:@"requestId"]]) {
            self.requestId = [netDataRelevant objectForKey:@"requestId"];
        }
        self.requestIdKey = [netDataRelevant objectForKey:@"requestIdKey"];
        self.method = [netDataRelevant objectForKey:@"method"];
        
        if (nil==self.method || [@"" isEqualToString:self.method]) {
            ECLog(@"%@ configs error: method is null!",NSStringFromClass([self class]));
        }
        
        
        //网络请求
        NSMutableDictionary* params = [NSMutableDictionary new];
        if (nil != self.requestId && nil != self.requestIdKey) {
            [params setObject:self.requestId forKey:self.requestIdKey];
        }
        if ( nil != self.method) {
            [params setObject:self.method forKey:@"method"];
        }
        
        FormDataRequest* request = [FormDataRequest requestNetURI:API_URL
                                                           params:params
                                                         delegate:self
                                                 finishedSelector:@selector(getUserInfoFinished:)
                                                     failSelector:@selector(webRequestFailed:)];
        if (request) {
            [[NetRequestManager sharedInstances] addOperation:request];
            //        [self showLoading:nil];
        }

    }
}

- (void)getUserInfoFinished:(FormDataRequest*)request{
    NSString* reponseString = [request responseString];
    ECLog(@"responseString:%@",reponseString);
    if ([reponseString rangeOfString:@"\"error\""].location != NSNotFound || [reponseString rangeOfString:@"\"Error\""].location != NSNotFound) {
        [[ECSpecRequest shareInstance] showError:reponseString];
        NSLog(@"response error:%@",reponseString);
    }
    else{
        id tempData = nil;
        id obj = [ECJsonParser objectWithJsonData:[request responseData]];
        if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
            tempData = [obj valueForKey:@"data"];
        }
        
        if (tempData && [tempData isNSxxxClass:[NSDictionary class]]) {
            _myInfo = [tempData objectForKey:@"MyInfo"];
        }
        NSString* userPoint = nil;
        if (nil != _myInfo && [_myInfo isNSxxxClass:[NSDictionary class]]) {
            userPoint = [NSString stringWithFormat:@"%@",[_myInfo objectForKey:@"integral"]];
        }
        if (nil != userPoint && ![userPoint isEqualToString:@""]) {
            for (int i=0;i<_tableDataSource.count;i++) {
                NSMutableDictionary* item = [NSMutableDictionary dictionaryWithDictionary:[_tableDataSource objectAtIndex:i]];
                if ([[item objectForKey:@"title"] rangeOfString:@"我的积分"].location != NSNotFound) {
                    [item setObject:[NSString stringWithFormat:@"我的积分(%@)",userPoint] forKey:@"title"];
                    [_tableDataSource replaceObjectAtIndex:i withObject:item];
                    break;
                }
            }
        }
        [_tableView reloadData];

    }
    // 处理完成后 移除加载框
//    [self removeLoading];
}


- (void) showContentView{
    NSString* userName = [ECKeyChain userName];
    if (nil == userName || [@"" isEqualToString:userName]) {
        _isLogin = NO;
    }else{
        _isLogin = YES;
    }
    
    if (nil == _scrollView) {
        _scrollView= [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, validWidth(), validHeight())];
        _loginView = [[UIView alloc] initWithFrame:CGRectMake(10, 20, validWidth()-20, 44)];
        _label1 = [[UILabel alloc] initWithFrame:CGRectMake(8, 8, 88, 28)];
        _label2 = [[UILabel alloc] initWithFrame:CGRectMake(96, 8, 176, 28)];
        _label1.text = @"当前账号";
        [_loginView addSubview:_label1];
        [_loginView addSubview:_label2];
        [_label1 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:17]];
        [_label2 setTextAlignment:NSTextAlignmentRight];
        [_label2 setFont:[UIFont systemFontOfSize:14]];
        [DisplayUtil setShadowAndCorlor:_loginView];
        [_scrollView addSubview:_loginView];
        
        CGFloat buttonY = _loginView.frame.origin.y + _loginView.frame.size.height+20;
        self.button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [self.button setFrame:CGRectMake(20, buttonY, validWidth()-40, 44)];
        
        [self.button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.button setBackgroundImage:[UIImage imageNamed:@"LoginBt.png"] forState:UIControlStateNormal];
        [self.button setBackgroundImage:[UIImage imageNamed:@"LoginBtSelect.png"] forState:UIControlStateHighlighted];
        [self.button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        [_scrollView addSubview:self.button];
        [self.view addSubview:_scrollView];
        
    }
    
   
    if (_isLogin) {
        NSString* userName = [ECKeyChain userName];
        _label2.text = userName;
        [self addPointInfo];
        [_tableView setHidden:NO];
        CGFloat buttonY = _tableView.frame.origin.y + _tableView.frame.size.height+20;
        [self.button setFrame:CGRectMake(20, buttonY, validWidth()-40, 44)];
        [self.button setTitle:@"注  销" forState:UIControlStateNormal];
        //刷新 积分
        [self getUserInfo];
    }else{
        _label2.text = @"尚未登录";
        [_tableView setHidden:YES];
         CGFloat buttonY = _loginView.frame.origin.y + _loginView.frame.size.height+20;
        [self.button setFrame:CGRectMake(20, buttonY, validWidth()-40, 44)];
        [self.button setTitle:@"登  录" forState:UIControlStateNormal];
    }

}

- (void) addPointInfo{
    if (nil == _tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, validWidth(), 44.0f * _tableDataSource.count + 20.0f) style:UITableViewStyleGrouped];
//        [_tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundView = nil;
        [_tableView setBackgroundColor:[UIColor clearColor]];
        [_tableView setScrollEnabled:NO];
        _tableView.separatorColor = [UIColor colorWithHexString:@"#BEBEBE"];
    }
    if (nil != _scrollView) {
        [_scrollView addSubview:_tableView];
    }
}

- (void)buttonClick:(id)sender{
    if (_isLogin) {
        [[NSNotificationCenter defaultCenter] postNotificationName:[NSString stringWithFormat:@"%@.%@.needLogout",self.instanceName,NSStringFromClass([self class])] object:nil userInfo:nil];
        
        [self showLoading:nil];
        double delayInSeconds = 0.5;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            [self removeLoading];
        });
        

    }else{
        [[NSNotificationCenter defaultCenter] postNotificationName:[NSString stringWithFormat:@"%@.%@.needLogin",self.instanceName,NSStringFromClass([self class])] object:nil userInfo:nil];
    }
}

- (void) logoutCmd:(NSDictionary*) params{
    [ECKeyChain saveUserName:nil password:nil deviceID:[UIDevice UDID] accessToken:nil];
//    NSLog(@"logOut message : %@  Token: %@",[UIDevice UDID],[ECKeyChain accessToken]);
//    [self showContentView];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"logoutCmd.logoutSuccess" object:nil userInfo:nil];
//    [[NSNotificationCenter defaultCenter] postNotificationName:@"getAccessToken" object:nil userInfo:nil];
    [[ECSpecRequest shareInstance] getAccessToken];
//    ECLog(@"%@",[NSString stringWithFormat:@"%@.logoutSuccess",NSStringFromSelector(_cmd)]);
}

#pragma mark - Table view data source

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    return [_tableDataSource count];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    NSDictionary* item = [_tableDataSource objectAtIndex:indexPath.row];
    // Configure the cell...
    cell.textLabel.text = [NSString stringWithFormat:@"%@",[item objectForKey:[self.configs objectForKey:@"titleKey"]]];

    cell.selectionStyle = UITableViewCellSelectionStyleGray;
    [cell setBackgroundColor:[UIColor clearColor]];
    if (indexPath.row != 0) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return cell;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString* cellTitle ;
    NSString* tag = @"";
    
    NSMutableDictionary* params = [NSMutableDictionary new];
    
    NSDictionary* dataItem = [_tableDataSource objectAtIndex:indexPath.row];
    // gen params pass to next ctrl
    cellTitle = [dataItem objectForKey:[self.configs objectForKey:@"titleKey"]];
    [params setObject:[dataItem objectForKey:[self.configs objectForKey:@"contentIdKey"]] forKey:@"requestId"];
    
    [params setObject:cellTitle forKey:@"navTitle"];
    
    NSURL *PlistURL = [[NSBundle mainBundle] URLForResource:@"SpeEventTagConfig" withExtension:@"plist"];
    NSDictionary* speEventTag =  [NSDictionary dictionaryWithContentsOfURL:PlistURL];
    NSEnumerator* enumerator = [speEventTag keyEnumerator];
    for (NSString *key in enumerator) {
        if ([cellTitle rangeOfString:key].location != NSNotFound) {
            tag = [speEventTag objectForKey:key];
        }
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:[NSString stringWithFormat:@"%@.%@.itemClick%@",self.instanceName,NSStringFromClass([self class]),tag] object:nil userInfo:params];
}
#pragma mark - 获取token
- (void)getAccessToken{
    
    [[ECSpecRequest shareInstance] getAccessToken];
//    if (![NetRequestManager networdEnabled]) {
//        //  TODO : 没有网络退出程序
//        [self exitApp];
//        ECLog(@"获取token失败!!!");
//        return;
//    }
//    NSLog(@"获取token");
//    NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"new_user", @"grant_type",[UIDevice UDID], @"devicenumber",tokenMethod(),@"method",[ECKeyChain apiKey],@"client_id", nil];
//    
//    FormDataRequest* request = [FormDataRequest requestNetURI:TOKEN_URL
//                                                       params:params
//                                                     delegate:self
//                                             finishedSelector:@selector(tokenReuestFinished:)
//                                                 failSelector:@selector(tokenRequestFailed:)];
//    if (request) {
//        [[NetRequestManager sharedInstances] addOperation:request];
//    }
    
}

#pragma mark - token获取成功 及失败
- (void)tokenReuestFinished:(FormDataRequest*)request{
    NSString* responseString = request.responseString;
    ECLog(@"token response: %@", responseString);
    if ([responseString rangeOfString:@"\"error\""].location != NSNotFound || [responseString rangeOfString:@"\"Error\""].location != NSNotFound) {
        [[ECSpecRequest shareInstance] showError:responseString];
        return;
    }
    id obj = [ECJsonParser objectWithJsonString:[request responseString]];
    if (obj && [obj isNSxxxClass:[NSDictionary class]]) {
        if ([obj valueForKey:@"access_token"]) {
            [ECKeyChain saveUserName:[ECKeyChain userName] password:[ECKeyChain password] deviceID:[UIDevice UDID]
                         accessToken:[obj valueForKey:@"access_token"]];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"logoutCmd.logoutSuccess" object:nil userInfo:nil];
            return;
        }
    }
    // 拿不到后面就没法继续了
        [self exitApp];
}
- (void) tokenRequestFailed:(FormDataRequest*)request{
    ECLog(@"获取token失败!!!");
    [self exitApp];
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
