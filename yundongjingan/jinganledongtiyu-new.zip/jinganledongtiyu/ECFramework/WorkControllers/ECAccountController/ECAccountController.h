//
//  ECAccountController.h
//  JingAnWeekly
//
//  Created by EC on 3/26/13.
//  Copyright (c) 2013 ecloud. All rights reserved.
//

#import "ECDetailViewController.h"

@interface ECAccountController : ECDetailViewController <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, assign) BOOL isLogin;
@property (nonatomic, strong) UIScrollView* scrollView;
@property (nonatomic, strong) UIView* loginView;
@property (nonatomic, strong) UIButton* button;
@property (nonatomic, strong) UILabel* label1;
@property (nonatomic, strong) UILabel* label2;
@property (nonatomic, strong) UITableView* tableView;
@property (nonatomic, strong) NSMutableArray* tableDataSource;
@property (nonatomic, strong) NSDictionary* myInfo;

@end
